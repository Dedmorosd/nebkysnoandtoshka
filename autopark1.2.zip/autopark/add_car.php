<?php
// Включаем показ ошибок для отладки (потом можно убрать)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Запускаем сессию
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'db.php'; 

$message = '';

if (isset($_POST['add_btn'])) {
    // Получаем данные из формы (названия в квадратных скобках должны совпадать с name="..." в HTML)
    $brand = trim($_POST['brand'] ?? '');
    $model = trim($_POST['model'] ?? '');
    $plate_number = trim($_POST['plate_number'] ?? ''); // Исправлено на plate_number
    $year = trim($_POST['year'] ?? '');
    $status = trim($_POST['status'] ?? 'available');

    if (empty($brand) || empty($model) || empty($plate_number)) {
        $message = "<div style='color:red; padding:10px; background:#ffe6e6; border-radius:5px; margin-bottom:15px;'>Заполните марку, модель и номер!</div>";
    } else {
        // ВАЖНО: Названия колонок точно совпадают со скриншотом структуры БД
        $sql = "INSERT INTO cars (brand, model, plate_number, year, status) VALUES (?, ?, ?, ?, ?)";
        
        if ($stmt = $conn->prepare($sql)) {
            // Типы данных: s=string (строка), i=integer (число)
            // brand(s), model(s), plate_number(s), year(i), status(s)
            $stmt->bind_param("sssis", $brand, $model, $plate_number, $year, $status);
            
            if ($stmt->execute()) {
                $message = "<div style='color:green; padding:10px; background:#e6ffe6; border-radius:5px; margin-bottom:15px;'>
                                ✅ Автомобиль <b>$brand $model</b> успешно добавлен!<br>
                                <a href='index.php' style='color: #007bff;'>Вернуться на главную</a>
                            </div>";
            } else {
                $message = "<div style='color:red; padding:10px; background:#ffe6e6; border-radius:5px;'>Ошибка SQL: " . $stmt->error . "</div>";
            }
            $stmt->close();
        } else {
            $message = "<div style='color:red; padding:10px; background:#ffe6e6; border-radius:5px;'>Ошибка подготовки запроса: " . $conn->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавить автомобиль</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); width: 400px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #333; font-weight: bold; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; margin-top: 10px; font-weight: bold; }
        button:hover { background: #218838; }
        .back-link { display: block; text-align: center; margin-top: 15px; text-decoration: none; color: #007bff; font-size: 14px; }
    </style>
</head>
<body>
    <div class="box">
        <h2 style="text-align:center; margin-top:0;">Добавление авто</h2>
        <?= $message ?>
        <form method="POST">
            <div class="form-group">
                <label>Марка *</label>
                <input type="text" name="brand" placeholder="Например: Toyota" required>
            </div>
            
            <div class="form-group">
                <label>Модель *</label>
                <input type="text" name="model" placeholder="Например: Camry" required>
            </div>
            
            <div class="form-group">
                <label>Гос. номер *</label>
                <!-- Атрибут name теперь plate_number -->
                <input type="text" name="plate_number" placeholder="Например: А123БВ77" required>
            </div>

            <div class="form-group">
                <label>Год выпуска</label>
                <input type="number" name="year" placeholder="Например: 2020" min="1900" max="2025">
            </div>
            
            <div class="form-group">
                <label>Статус</label>
                <!-- Значения (value) теперь на английском, как в вашей БД (enum) -->
                <select name="status">
                    <option value="available">Свободен (available)</option>
                    <option value="on_trip">В рейсе (on_trip)</option>
                    <option value="repair">На ремонте (repair)</option>
                </select>
            </div>

            <button type="submit" name="add_btn">Сохранить в базу</button>
        </form>
        
        <a href="index.php" class="back-link">← Назад к списку автомобилей</a>
    </div>
</body>
</html>