<?php
// index.php
session_start(); // Запускаем сессию

// Подключаем базу данных
require 'db.php';

// Проверка: если пользователь не вошел, отправляем на страницу логина
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Получаем данные из таблицы cars
$sql = "SELECT * FROM cars";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Автопарк - Главная</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; }
        .navbar { background: #333; color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; }
        .container { padding: 20px; max-width: 1000px; margin: 0 auto; }
        table { width: 100%; border-collapse: collapse; background: white; margin-top: 20px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background: #007bff; color: white; }
        .btn { padding: 8px 15px; background: #28a745; color: white; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>

<div class="navbar">
    <div><b>Автопарк КВН</b></div>
    <div>
        Привет, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!
        <a href="logout.php" style="color: #ff6b6b;">Выйти</a>
    </div>
</div>

<div class="container">
    <h1>Список автомобилей</h1>
    <a href="add_car.php" class="btn">Добавить автомобиль</a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Марка</th>
                <th>Модель</th>
                <th>Номер</th>
                <th>Статус</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                // Выводим данные каждой машины
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['brand']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['model']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['license_plate']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>В базе пока нет машин</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>