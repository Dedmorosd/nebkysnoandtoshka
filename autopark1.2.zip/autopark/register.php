<?php
// register.php
require 'db.php';

$message = '';

if (isset($_POST['register_btn'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($password !== $confirm) {
        $message = "<p style='color:red'>Пароли не совпадают!</p>";
    } else {
        // Проверка на существующий email
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "<p style='color:red'>Этот Email уже занят.</p>";
        } else {
            // Хешируем пароль и сохраняем
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            // ВНИМАНИЕ: Проверьте названия колонок в вашей БД (full_name, email, password)
            $insert = $conn->prepare("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)");
            $insert->bind_param("sss", $full_name, $email, $hashed_password);
            
            if ($insert->execute()) {
                $message = "<p style='color:green'>Успешно! <a href='login.php'>Войдите</a>.</p>";
            } else {
                $message = "<p style='color:red'>Ошибка: " . $insert->error . "</p>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <style>
        body { font-family: Arial; background: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); width: 300px; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="box">
        <h2 style="text-align:center;">Регистрация</h2>
        <?= $message ?>
        <form method="POST">
            <input type="text" name="full_name" placeholder="Ваше Имя" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <input type="password" name="confirm_password" placeholder="Повторите пароль" required>
            <button type="submit" name="register_btn">Зарегистрироваться</button>
        </form>
        <p style="text-align:center; margin-top:15px; font-size:14px;">Есть аккаунт? <a href="login.php">Войти</a></p>
    </div>
</body>
</html> 
