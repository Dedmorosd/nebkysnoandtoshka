<?php
// logout.php
session_start();
session_destroy(); // Уничтожаем сессию
header("Location: login.php"); // Кидаем на страницу входа
exit;
?>