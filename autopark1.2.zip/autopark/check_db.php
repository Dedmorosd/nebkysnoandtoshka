<?php
require 'db.php'; // Подключаем вашу базу

echo "<h2>Структура таблицы 'cars'</h2>";
echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
echo "<tr><th>Название колонки (Field)</th><th>Тип (Type)</th></tr>";

// Запрашиваем информацию о колонках
$result = $conn->query("DESCRIBE cars");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td><b>" . $row['Field'] . "</b></td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='2'>Ошибка: Таблица 'cars' не найдена или нет доступа.</td></tr>";
}
echo "</table>";
?>