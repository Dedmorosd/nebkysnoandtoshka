<?php
// login.php
session_start();

// --- НАСТРОЙКИ МАСТЕР-ДОСТУПА ---
// Введите здесь логин и пароль, под которыми хотите заходить как админ
$admin_login = "admin";
$admin_password = "12345"; 
// --------------------------------

$error = '';

if (isset($_POST['login_btn'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // 1. ПРОВЕРКА НА АДМИНИСТРАТОРА (Мастер-вход)
    if ($email === $admin_login && $password === $admin_password) {
        $_SESSION['user_id'] = 999; // Даем фейковый ID
        $_SESSION['user_name'] = "Главный Администратор";
        $_SESSION['role'] = "admin";
        
        header("Location: index.php"); // Перекидываем на главную
        exit;
    } 
    else {
        // 2. ПРОВЕРКА ОБЫЧНЫХ ПОЛЬЗОВАТЕЛЕЙ ИЗ БАЗЫ
        // Подключаем БД только здесь, чтобы если она не работает, админ все равно мог зайти
        if (file_exists('db.php')) {
            require 'db.php';
            
            $stmt = $conn->prepare("SELECT id, full_name, password FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['full_name'];
                    $_SESSION['role'] = "user";
                    header("Location: index.php");
                    exit;
                } else {
                    $error = "Неверный пароль!";
                }
            } else {
                $error = "Пользователь не найден!";
            }
        } else {
            $error = "Ошибка: Файл db.php не найден, а данные мастер-входа неверны.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход в систему</title>
    <style>
        body { font-family: Arial; background: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); width: 300px; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #218838; }
        .info { font-size: 12px; color: #666; margin-top: 15px; text-align: center; background: #eee; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="box">
        <h2 style="text-align:center;">Вход</h2>
        <?php if($error) echo "<p style='color:red;text-align:center;'>$error</p>"; ?>
        
        <form method="POST">
            <input type="text" name="email" placeholder="Логин (или Email)" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit" name="login_btn">Войти</button>
        </form>
        
        <div class="info">
            <b>Мастер-доступ:</b><br>
            Логин: <b>admin</b><br>
            Пароль: <b>12345</b>
        </div>
        
        <p style="text-align:center; margin-top:15px; font-size:14px;">Нет аккаунта? <a href="register.php">Регистрация</a></p>
    </div>
</body>
</html>