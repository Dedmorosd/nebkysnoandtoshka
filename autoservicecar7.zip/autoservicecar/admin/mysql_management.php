<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Управление MySQL сервером";

// Получение информации о MySQL сервере
$mysqlInfo = [];
try {
    // Версия MySQL
    $stmt = $pdo->query("SELECT VERSION() as version");
    $mysqlInfo['version'] = $stmt->fetch()['version'];
    
    // Время работы
    $stmt = $pdo->query("SHOW STATUS LIKE 'Uptime'");
    $uptime = $stmt->fetch()['Value'];
    $mysqlInfo['uptime_days'] = floor($uptime / 86400);
    $mysqlInfo['uptime_hours'] = floor(($uptime % 86400) / 3600);
    $mysqlInfo['uptime_minutes'] = floor(($uptime % 3600) / 60);
    
    // Количество подключений
    $stmt = $pdo->query("SHOW STATUS LIKE 'Threads_connected'");
    $mysqlInfo['connections'] = $stmt->fetch()['Value'];
    
    // Максимальное количество подключений
    $stmt = $pdo->query("SHOW VARIABLES LIKE 'max_connections'");
    $mysqlInfo['max_connections'] = $stmt->fetch()['Value'];
    
    // Количество запросов
    $stmt = $pdo->query("SHOW STATUS LIKE 'Questions'");
    $mysqlInfo['total_queries'] = $stmt->fetch()['Value'];
    
    // Медленные запросы
    $stmt = $pdo->query("SHOW STATUS LIKE 'Slow_queries'");
    $mysqlInfo['slow_queries'] = $stmt->fetch()['Value'];
    
    // Размер базы данных
    $stmt = $pdo->query("
        SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
        FROM information_schema.tables
        WHERE table_schema = 'project_Karachkin'
    ");
    $mysqlInfo['db_size_mb'] = $stmt->fetch()['size_mb'] ?? 0;
    
    // Количество таблиц
    $stmt = $pdo->query("
        SELECT COUNT(*) as table_count
        FROM information_schema.tables
        WHERE table_schema = 'project_Karachkin'
    ");
    $mysqlInfo['table_count'] = $stmt->fetch()['table_count'];
    
    // Статус сервера
    $stmt = $pdo->query("SHOW STATUS LIKE 'Innodb_buffer_pool_read_requests'");
    $read_requests = $stmt->fetch()['Value'];
    $stmt = $pdo->query("SHOW STATUS LIKE 'Innodb_buffer_pool_reads'");
    $reads = $stmt->fetch()['Value'];
    
    if ($read_requests > 0) {
        $mysqlInfo['cache_hit_rate'] = round((1 - $reads / $read_requests) * 100, 2);
    } else {
        $mysqlInfo['cache_hit_rate'] = 0;
    }
    
} catch (PDOException $e) {
    $error = "Ошибка получения информации: " . $e->getMessage();
}

// Получение списка пользователей
$users = [];
try {
    $stmt = $pdo->query("SELECT User, Host FROM mysql.user ORDER BY User");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    // Может не быть прав на чтение mysql.user
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --mysql-primary: #00758f;
        --mysql-secondary: #f29111;
        --mysql-success: #27ae60;
        --mysql-warning: #f39c12;
        --mysql-danger: #e74c3c;
        --mysql-info: #3498db;
        --mysql-dark: #1a1a2e;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s;
        border-left: 4px solid var(--mysql-primary);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2em;
        font-weight: 700;
        color: var(--mysql-dark);
    }
    
    .stat-label {
        color: #7f8c8d;
        font-size: 0.85em;
        margin-top: 5px;
    }
    
    .stat-unit {
        font-size: 0.6em;
        color: #95a5a6;
    }
    
    .mysql-header {
        background: linear-gradient(135deg, var(--mysql-primary), #005c6e);
        color: white;
        padding: 20px;
        border-radius: 15px;
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .mysql-header h2 {
        margin: 0;
        font-size: 1.5em;
    }
    
    .status-badge {
        display: inline-block;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: 600;
    }
    
    .status-online {
        background: rgba(39, 174, 96, 0.15);
        color: #27ae60;
    }
    
    .cards-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .info-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .info-card-header {
        background: var(--mysql-primary);
        color: white;
        padding: 15px 20px;
        font-weight: 600;
    }
    
    .info-card-body {
        padding: 20px;
    }
    
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .info-row:last-child {
        border-bottom: none;
    }
    
    .info-label {
        font-weight: 600;
        color: var(--mysql-dark);
    }
    
    .info-value {
        color: #7f8c8d;
        font-family: monospace;
    }
    
    .progress-bar {
        height: 10px;
        background: #ecf0f1;
        border-radius: 5px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--mysql-success), var(--mysql-primary));
        width: 0%;
        border-radius: 5px;
        transition: width 0.3s;
    }
    
    .users-table {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .users-table table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .users-table th,
    .users-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .users-table th {
        background: #f8f9fa;
        color: var(--mysql-dark);
        font-weight: 600;
    }
    
    .users-table tr:hover {
        background: #f8f9fa;
    }
    
    .btn-mysql {
        padding: 8px 15px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s;
        background: var(--mysql-primary);
        color: white;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-mysql:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }
    
    .btn-mysql-danger {
        background: var(--mysql-danger);
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 500px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        background: var(--mysql-primary);
        color: white;
        border-radius: 15px 15px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: white;
    }
    
    .form-group {
        margin-bottom: 15px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
        color: var(--mysql-dark);
    }
    
    .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
    }
    
    .form-control:focus {
        outline: none;
        border-color: var(--mysql-primary);
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
        border-left: 4px solid var(--mysql-success);
    }
    
    .toast.error {
        border-left-color: var(--mysql-danger);
    }
    
    .query-log {
        background: #2c3e50;
        color: #0f0;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        max-height: 300px;
        overflow-y: auto;
        margin-top: 10px;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-database"></i> Управление MySQL сервером
        </h1>
        <div>
            <button class="btn btn-primary" onclick="refreshPage()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo number_format($mysqlInfo['db_size_mb'] ?? 0, 2); ?> <span class="stat-unit">MB</span></div>
            <div class="stat-label">Размер базы данных</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['table_count'] ?? 0; ?></div>
            <div class="stat-label">Таблиц</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['connections'] ?? 0; ?> / <?php echo $mysqlInfo['max_connections'] ?? 0; ?></div>
            <div class="stat-label">Подключения</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo number_format($mysqlInfo['total_queries'] ?? 0, 0, '', ' '); ?></div>
            <div class="stat-label">Всего запросов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['slow_queries'] ?? 0; ?></div>
            <div class="stat-label">Медленных запросов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['cache_hit_rate'] ?? 0; ?>%</div>
            <div class="stat-label">Cache Hit Rate</div>
        </div>
    </div>
    
    <!-- Информация о сервере -->
    <div class="mysql-header">
        <div>
            <h2><i class="fas fa-server"></i> MySQL Server</h2>
            <p class="mb-0 small">Версия: <?php echo $mysqlInfo['version'] ?? 'N/A'; ?></p>
        </div>
        <div>
            <span class="status-badge status-online">
                <i class="fas fa-circle" style="font-size: 8px;"></i> Онлайн
            </span>
        </div>
    </div>
    
    <div class="cards-container">
        <!-- Системная информация -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-info-circle"></i> Системная информация
            </div>
            <div class="info-card-body">
                <div class="info-row">
                    <span class="info-label">Время работы:</span>
                    <span class="info-value">
                        <?php 
                            echo ($mysqlInfo['uptime_days'] ?? 0) . ' дн, ' . 
                                 ($mysqlInfo['uptime_hours'] ?? 0) . ' ч, ' . 
                                 ($mysqlInfo['uptime_minutes'] ?? 0) . ' мин';
                        ?>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Порт:</span>
                    <span class="info-value">3306</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Хост:</span>
                    <span class="info-value">localhost</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Движок по умолчанию:</span>
                    <span class="info-value">InnoDB</span>
                </div>
            </div>
        </div>
        
        <!-- Производительность -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-chart-line"></i> Производительность
            </div>
            <div class="info-card-body">
                <div class="info-row">
                    <span class="info-label">Cache Hit Rate:</span>
                    <span class="info-value"><?php echo $mysqlInfo['cache_hit_rate'] ?? 0; ?>%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $mysqlInfo['cache_hit_rate'] ?? 0; ?>%"></div>
                </div>
                <div class="info-row">
                    <span class="info-label">Использование подключений:</span>
                    <span class="info-value">
                        <?php 
                            $conn_percent = ($mysqlInfo['connections'] ?? 0) / ($mysqlInfo['max_connections'] ?? 1) * 100;
                            echo round($conn_percent, 1) . '%';
                        ?>
                    </span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $conn_percent; ?>%; background: <?php echo $conn_percent > 80 ? '#e74c3c' : '#27ae60'; ?>"></div>
                </div>
            </div>
        </div>
        
        <!-- Управление -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-cog"></i> Управление
            </div>
            <div class="info-card-body">
                <div class="info-row">
                    <button class="btn-mysql" onclick="showLogs()">
                        <i class="fas fa-history"></i> Логи сервера
                    </button>
                    <button class="btn-mysql" onclick="showConnections()">
                        <i class="fas fa-plug"></i> Активные подключения
                    </button>
                </div>
                <div class="info-row">
                    <button class="btn-mysql" onclick="showBackup()">
                        <i class="fas fa-database"></i> Резервное копирование
                    </button>
                    <button class="btn-mysql btn-mysql-danger" onclick="showOptimize()">
                        <i class="fas fa-magic"></i> Оптимизация
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Пользователи MySQL -->
    <?php if (!empty($users)): ?>
    <div class="users-table">
        <div style="padding: 15px 20px; background: linear-gradient(135deg, var(--mysql-primary), #005c6e); color: white;">
            <i class="fas fa-users"></i> Пользователи MySQL
        </div>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Пользователь</th>
                        <th>Хост</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['User']); ?></td>
                        <td><?php echo htmlspecialchars($user['Host']); ?></td>
                        <td>
                            <button class="btn-sm btn-info" onclick="viewUserPrivileges('<?php echo htmlspecialchars($user['User']); ?>', '<?php echo htmlspecialchars($user['Host']); ?>')">
                                <i class="fas fa-lock"></i> Привилегии
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Модальное окно для логов -->
<div id="logsModal" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h5><i class="fas fa-history"></i> Логи MySQL</h5>
            <span class="close" onclick="closeModal('logsModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Тип лога</label>
                <select class="form-control" id="logType">
                    <option value="error">Error Log</option>
                    <option value="slow">Slow Query Log</option>
                    <option value="general">General Log</option>
                </select>
            </div>
            <div id="logContent" class="query-log">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('logsModal')">Закрыть</button>
            <button class="btn btn-primary" onclick="refreshLogs()">Обновить</button>
        </div>
    </div>
</div>

<!-- Модальное окно для подключений -->
<div id="connectionsModal" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h5><i class="fas fa-plug"></i> Активные подключения</h5>
            <span class="close" onclick="closeModal('connectionsModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="connectionsContent" class="query-log">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('connectionsModal')">Закрыть</button>
            <button class="btn btn-primary" onclick="refreshConnections()">Обновить</button>
            <button class="btn btn-danger" onclick="killAllConnections()">Убить все подключения</button>
        </div>
    </div>
</div>

<!-- Модальное окно для бэкапа -->
<div id="backupModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-database"></i> Резервное копирование</h5>
            <span class="close" onclick="closeModal('backupModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Тип бэкапа</label>
                <select class="form-control" id="backupType">
                    <option value="full">Полный</option>
                    <option value="structure">Только структура</option>
                    <option value="data">Только данные</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Компрессия</label>
                <select class="form-control" id="backupCompression">
                    <option value="gzip">GZIP</option>
                    <option value="none">Без компрессии</option>
                </select>
            </div>
            <div id="backupResult" class="query-log" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('backupModal')">Отмена</button>
            <button class="btn btn-primary" onclick="createBackup()">Создать бэкап</button>
        </div>
    </div>
</div>

<!-- Модальное окно для оптимизации -->
<div id="optimizeModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-magic"></i> Оптимизация базы данных</h5>
            <span class="close" onclick="closeModal('optimizeModal')">&times;</span>
        </div>
        <div class="modal-body">
            <p>Оптимизация может занять некоторое время. Продолжить?</p>
            <div id="optimizeResult" class="query-log" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('optimizeModal')">Отмена</button>
            <button class="btn btn-primary" onclick="runOptimize()">Выполнить</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
// Показать логи
function showLogs() {
    document.getElementById('logsModal').style.display = 'flex';
    loadLogs();
}

function loadLogs() {
    const logType = document.getElementById('logType').value;
    document.getElementById('logContent').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка логов...';
    
    fetch(`../api/mysql_api.php?action=logs&type=${logType}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('logContent').innerHTML = data.logs || 'Логи пусты';
            } else {
                document.getElementById('logContent').innerHTML = `<span style="color: #e74c3c;">Ошибка: ${data.error}</span>`;
            }
        })
        .catch(error => {
            document.getElementById('logContent').innerHTML = `<span style="color: #e74c3c;">Ошибка: ${error}</span>`;
        });
}

function refreshLogs() {
    loadLogs();
}

// Показать подключения
function showConnections() {
    document.getElementById('connectionsModal').style.display = 'flex';
    loadConnections();
}

function loadConnections() {
    document.getElementById('connectionsContent').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка подключений...';
    
    fetch('../api/mysql_api.php?action=connections')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.connections && data.connections.length > 0) {
                let html = '<table style="width:100%; border-collapse: collapse;">';
                html += '<tr style="background: #34495e;"><th style="padding:8px;">ID</th><th style="padding:8px;">Пользователь</th><th style="padding:8px;">Хост</th><th style="padding:8px;">База</th><th style="padding:8px;">Команда</th><th style="padding:8px;">Время</th></tr>';
                data.connections.forEach(conn => {
                    html += `<tr>
                        <td style="padding:5px;">${conn.Id}</td>
                        <td style="padding:5px;">${conn.User}</td>
                        <td style="padding:5px;">${conn.Host}</td>
                        <td style="padding:5px;">${conn.db || '-'}</td>
                        <td style="padding:5px;">${conn.Command}</td>
                        <td style="padding:5px;">${conn.Time} сек</td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('connectionsContent').innerHTML = html;
            } else {
                document.getElementById('connectionsContent').innerHTML = data.error || 'Нет активных подключений';
            }
        })
        .catch(error => {
            document.getElementById('connectionsContent').innerHTML = `<span style="color: #e74c3c;">Ошибка: ${error}</span>`;
        });
}

function refreshConnections() {
    loadConnections();
}

function killAllConnections() {
    if (confirm('Убить все активные подключения? Это может привести к потере данных.')) {
        fetch('../api/mysql_api.php?action=kill_all', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    loadConnections();
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
            });
    }
}

// Бэкап
function showBackup() {
    document.getElementById('backupModal').style.display = 'flex';
    document.getElementById('backupResult').style.display = 'none';
}

function createBackup() {
    const type = document.getElementById('backupType').value;
    const compression = document.getElementById('backupCompression').value;
    
    document.getElementById('backupResult').style.display = 'block';
    document.getElementById('backupResult').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Создание бэкапа...';
    
    fetch('../api/mysql_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'backup', type: type, compression: compression })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('backupResult').innerHTML = `<span style="color: #27ae60;">✅ Бэкап создан: ${data.filename}</span>`;
            showToast('Бэкап создан успешно', 'success');
        } else {
            document.getElementById('backupResult').innerHTML = `<span style="color: #e74c3c;">❌ Ошибка: ${data.error}</span>`;
            showToast('Ошибка: ' + data.error, 'error');
        }
    })
    .catch(error => {
        document.getElementById('backupResult').innerHTML = `<span style="color: #e74c3c;">❌ Ошибка: ${error}</span>`;
    });
}

// Оптимизация
function showOptimize() {
    document.getElementById('optimizeModal').style.display = 'flex';
    document.getElementById('optimizeResult').style.display = 'none';
}

function runOptimize() {
    document.getElementById('optimizeResult').style.display = 'block';
    document.getElementById('optimizeResult').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Оптимизация базы данных...';
    
    fetch('../api/mysql_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'optimize' })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('optimizeResult').innerHTML = `<span style="color: #27ae60;">✅ ${data.message}</span>`;
            showToast('Оптимизация завершена', 'success');
        } else {
            document.getElementById('optimizeResult').innerHTML = `<span style="color: #e74c3c;">❌ Ошибка: ${data.error}</span>`;
            showToast('Ошибка: ' + data.error, 'error');
        }
    })
    .catch(error => {
        document.getElementById('optimizeResult').innerHTML = `<span style="color: #e74c3c;">❌ Ошибка: ${error}</span>`;
    });
}

// Просмотр привилегий
function viewUserPrivileges(user, host) {
    showToast(`Привилегии пользователя ${user}@${host}`, 'info');
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function refreshPage() {
    location.reload();
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type === 'error' ? 'error' : ''}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
