<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Управление MySQL (RedOS)";

// Получение информации о системе
$systemInfo = [];
$mysqlInfo = [];

try {
    // Информация о ОС
    $os = php_uname();
    $systemInfo['os'] = $os;
    
    // Информация о MySQL через существующее подключение
    $stmt = $pdo->query("SELECT VERSION() as version");
    $mysqlInfo['version'] = $stmt->fetch()['version'];
    
    // Время работы MySQL
    $stmt = $pdo->query("SHOW STATUS LIKE 'Uptime'");
    $uptime = $stmt->fetch()['Value'];
    $mysqlInfo['uptime_days'] = floor($uptime / 86400);
    $mysqlInfo['uptime_hours'] = floor(($uptime % 86400) / 3600);
    $mysqlInfo['uptime_minutes'] = floor(($uptime % 3600) / 60);
    
    // Статистика подключений
    $stmt = $pdo->query("SHOW STATUS LIKE 'Threads_connected'");
    $mysqlInfo['connections'] = $stmt->fetch()['Value'];
    
    $stmt = $pdo->query("SHOW VARIABLES LIKE 'max_connections'");
    $mysqlInfo['max_connections'] = $stmt->fetch()['Value'];
    
    // Статистика запросов
    $stmt = $pdo->query("SHOW STATUS LIKE 'Questions'");
    $mysqlInfo['total_queries'] = $stmt->fetch()['Value'];
    
    $stmt = $pdo->query("SHOW STATUS LIKE 'Slow_queries'");
    $mysqlInfo['slow_queries'] = $stmt->fetch()['Value'];
    
    // Размер базы данных
    $stmt = $pdo->query("
        SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
        FROM information_schema.tables
        WHERE table_schema = 'project_Karachkin'
    ");
    $mysqlInfo['db_size_mb'] = $stmt->fetch()['size_mb'] ?? 0;
    
    // Количество таблиц
    $stmt = $pdo->query("
        SELECT COUNT(*) as table_count
        FROM information_schema.tables
        WHERE table_schema = 'project_Karachkin'
    ");
    $mysqlInfo['table_count'] = $stmt->fetch()['table_count'];
    
    // Cache Hit Rate
    $stmt = $pdo->query("SHOW STATUS LIKE 'Innodb_buffer_pool_read_requests'");
    $read_requests = $stmt->fetch()['Value'];
    $stmt = $pdo->query("SHOW STATUS LIKE 'Innodb_buffer_pool_reads'");
    $reads = $stmt->fetch()['Value'];
    
    if ($read_requests > 0) {
        $mysqlInfo['cache_hit_rate'] = round((1 - $reads / $read_requests) * 100, 2);
    } else {
        $mysqlInfo['cache_hit_rate'] = 0;
    }
    
    // Информация о дисках (если доступно)
    $diskInfo = [];
    $diskFree = disk_free_space('/');
    $diskTotal = disk_total_space('/');
    if ($diskFree !== false && $diskTotal !== false) {
        $diskInfo['free'] = round($diskFree / 1024 / 1024 / 1024, 2);
        $diskInfo['total'] = round($diskTotal / 1024 / 1024 / 1024, 2);
        $diskInfo['used_percent'] = round((1 - $diskFree / $diskTotal) * 100, 2);
    }
    $systemInfo['disk'] = $diskInfo;
    
    // Информация о памяти (если доступна)
    $memInfo = [];
    if (file_exists('/proc/meminfo')) {
        $memData = file_get_contents('/proc/meminfo');
        preg_match('/MemTotal:\s+(\d+)/', $memData, $matches);
        $memInfo['total'] = round($matches[1] / 1024 / 1024, 2);
        preg_match('/MemAvailable:\s+(\d+)/', $memData, $matches);
        $memInfo['available'] = round($matches[1] / 1024 / 1024, 2);
        $memInfo['used_percent'] = round((1 - $memInfo['available'] / $memInfo['total']) * 100, 2);
    }
    $systemInfo['memory'] = $memInfo;
    
    // Информация о загрузке CPU (если доступна)
    if (file_exists('/proc/loadavg')) {
        $loadData = file_get_contents('/proc/loadavg');
        $load = explode(' ', $loadData);
        $systemInfo['load'] = [
            '1min' => $load[0],
            '5min' => $load[1],
            '15min' => $load[2]
        ];
    }
    
} catch (PDOException $e) {
    $error = "Ошибка получения информации: " . $e->getMessage();
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --redos-primary: #c52a2a;
        --redos-secondary: #8b0000;
        --redos-success: #27ae60;
        --redos-warning: #f39c12;
        --redos-danger: #e74c3c;
        --redos-info: #3498db;
        --redos-dark: #2c3e50;
    }
    
    .redos-header {
        background: linear-gradient(135deg, var(--redos-primary), var(--redos-secondary));
        color: white;
        padding: 20px;
        border-radius: 15px;
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .redos-header h2 {
        margin: 0;
        font-size: 1.5em;
    }
    
    .status-badge {
        display: inline-block;
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: 600;
    }
    
    .status-online {
        background: rgba(39, 174, 96, 0.15);
        color: #27ae60;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s;
        border-left: 4px solid var(--redos-primary);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2em;
        font-weight: 700;
        color: var(--redos-dark);
    }
    
    .stat-label {
        color: #7f8c8d;
        font-size: 0.85em;
        margin-top: 5px;
    }
    
    .cards-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .info-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .info-card-header {
        background: var(--redos-primary);
        color: white;
        padding: 15px 20px;
        font-weight: 600;
    }
    
    .info-card-body {
        padding: 20px;
    }
    
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .info-row:last-child {
        border-bottom: none;
    }
    
    .info-label {
        font-weight: 600;
        color: var(--redos-dark);
    }
    
    .info-value {
        color: #7f8c8d;
        font-family: monospace;
    }
    
    .progress-bar {
        height: 10px;
        background: #ecf0f1;
        border-radius: 5px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--redos-success), var(--redos-primary));
        width: 0%;
        border-radius: 5px;
        transition: width 0.3s;
    }
    
    .action-buttons {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 15px;
    }
    
    .btn-redos {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s;
        background: var(--redos-primary);
        color: white;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-redos:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }
    
    .btn-redos-success {
        background: var(--redos-success);
    }
    
    .btn-redos-warning {
        background: var(--redos-warning);
    }
    
    .btn-redos-danger {
        background: var(--redos-danger);
    }
    
    .btn-redos-info {
        background: var(--redos-info);
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 800px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        background: var(--redos-primary);
        color: white;
        border-radius: 15px 15px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: white;
    }
    
    .query-log {
        background: #2c3e50;
        color: #0f0;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        max-height: 400px;
        overflow-y: auto;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
        border-left: 4px solid var(--redos-success);
    }
    
    .toast.error {
        border-left-color: var(--redos-danger);
    }
    
    .system-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 15px;
        background: rgba(197, 42, 42, 0.1);
        color: var(--redos-primary);
        font-size: 0.8em;
        margin-left: 10px;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fab fa-linux"></i> Управление MySQL на RedOS
            <span class="system-badge"><i class="fas fa-server"></i> RedOS Linux</span>
        </h1>
        <div>
            <button class="btn btn-primary" onclick="refreshPage()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- RedOS Header -->
    <div class="redos-header">
        <div>
            <h2><i class="fab fa-redhat"></i> RedOS Server</h2>
            <p class="mb-0 small"><?php echo htmlspecialchars($systemInfo['os'] ?? 'RedOS Linux'); ?></p>
        </div>
        <div>
            <span class="status-badge status-online">
                <i class="fas fa-circle" style="font-size: 8px;"></i> MySQL Online
            </span>
        </div>
    </div>
    
    <!-- Статистика MySQL -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo number_format($mysqlInfo['db_size_mb'] ?? 0, 2); ?> <span class="stat-unit">MB</span></div>
            <div class="stat-label">Размер базы данных</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['table_count'] ?? 0; ?></div>
            <div class="stat-label">Таблиц</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['connections'] ?? 0; ?> / <?php echo $mysqlInfo['max_connections'] ?? 0; ?></div>
            <div class="stat-label">Подключения</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo number_format($mysqlInfo['total_queries'] ?? 0, 0, '', ' '); ?></div>
            <div class="stat-label">Всего запросов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['slow_queries'] ?? 0; ?></div>
            <div class="stat-label">Медленных запросов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $mysqlInfo['cache_hit_rate'] ?? 0; ?>%</div>
            <div class="stat-label">InnoDB Cache Hit Rate</div>
        </div>
    </div>
    
    <!-- Системная информация и управление -->
    <div class="cards-container">
        <!-- Информация о системе -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-microchip"></i> Системная информация
            </div>
            <div class="info-card-body">
                <div class="info-row">
                    <span class="info-label">Время работы MySQL:</span>
                    <span class="info-value">
                        <?php 
                            echo ($mysqlInfo['uptime_days'] ?? 0) . ' дн, ' . 
                                 ($mysqlInfo['uptime_hours'] ?? 0) . ' ч, ' . 
                                 ($mysqlInfo['uptime_minutes'] ?? 0) . ' мин';
                        ?>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Загрузка CPU (1/5/15 мин):</span>
                    <span class="info-value">
                        <?php 
                            echo ($systemInfo['load']['1min'] ?? '0') . ' / ' . 
                                 ($systemInfo['load']['5min'] ?? '0') . ' / ' . 
                                 ($systemInfo['load']['15min'] ?? '0');
                        ?>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Память:</span>
                    <span class="info-value">
                        <?php 
                            $memTotal = $systemInfo['memory']['total'] ?? 0;
                            $memUsedPercent = $systemInfo['memory']['used_percent'] ?? 0;
                            echo round($memTotal, 1) . ' GB (использовано ' . $memUsedPercent . '%)';
                        ?>
                    </span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $memUsedPercent ?? 0; ?>%"></div>
                </div>
                <div class="info-row">
                    <span class="info-label">Дисковое пространство (/):</span>
                    <span class="info-value">
                        <?php 
                            $diskFree = $systemInfo['disk']['free'] ?? 0;
                            $diskTotal = $systemInfo['disk']['total'] ?? 0;
                            echo 'Свободно ' . $diskFree . ' GB из ' . $diskTotal . ' GB';
                        ?>
                    </span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $systemInfo['disk']['used_percent'] ?? 0; ?>%"></div>
                </div>
            </div>
        </div>
        
        <!-- Управление -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-cog"></i> Управление MySQL
            </div>
            <div class="info-card-body">
                <div class="action-buttons">
                    <button class="btn-redos" onclick="showProcessList()">
                        <i class="fas fa-tasks"></i> Процессы
                    </button>
                    <button class="btn-redos btn-redos-info" onclick="showVariables()">
                        <i class="fas fa-code-branch"></i> Переменные
                    </button>
                    <button class="btn-redos btn-redos-success" onclick="showBackup()">
                        <i class="fas fa-database"></i> Бэкап
                    </button>
                    <button class="btn-redos btn-redos-warning" onclick="showOptimize()">
                        <i class="fas fa-magic"></i> Оптимизация
                    </button>
                    <button class="btn-redos btn-redos-danger" onclick="showFlush()">
                        <i class="fas fa-trash-alt"></i> Flush Logs
                    </button>
                </div>
                <div class="action-buttons mt-2">
                    <button class="btn-redos btn-redos-info" onclick="showSystemLogs()">
                        <i class="fas fa-history"></i> Системные логи
                    </button>
                    <button class="btn-redos btn-redos-info" onclick="showMySQLConfig()">
                        <i class="fas fa-file-code"></i> my.cnf
                    </button>
                    <button class="btn-redos btn-redos-danger" onclick="showRestart()">
                        <i class="fas fa-sync-alt"></i> Перезапуск MySQL
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно для процессов -->
<div id="processModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-tasks"></i> Активные процессы MySQL</h5>
            <span class="close" onclick="closeModal('processModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="processContent" class="query-log">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('processModal')">Закрыть</button>
            <button class="btn btn-primary" onclick="refreshProcesses()">Обновить</button>
        </div>
    </div>
</div>

<!-- Модальное окно для переменных -->
<div id="variablesModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h5><i class="fas fa-code-branch"></i> Переменные MySQL</h5>
            <span class="close" onclick="closeModal('variablesModal')">&times;</span>
        </div>
        <div class="modal-body">
            <input type="text" id="variableFilter" class="form-control mb-3" placeholder="Поиск переменных...">
            <div id="variablesContent" class="query-log" style="max-height: 500px;">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('variablesModal')">Закрыть</button>
        </div>
    </div>
</div>

<!-- Модальное окно для бэкапа -->
<div id="backupModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-database"></i> Резервное копирование</h5>
            <span class="close" onclick="closeModal('backupModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="form-group mb-3">
                <label class="form-label">Тип бэкапа</label>
                <select class="form-control" id="backupType">
                    <option value="full">Полный</option>
                    <option value="structure">Только структура</option>
                    <option value="data">Только данные</option>
                </select>
            </div>
            <div class="form-group mb-3">
                <label class="form-label">Компрессия</label>
                <select class="form-control" id="backupCompression">
                    <option value="gzip">GZIP</option>
                    <option value="none">Без компрессии</option>
                </select>
            </div>
            <div id="backupResult" class="query-log" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('backupModal')">Отмена</button>
            <button class="btn btn-primary" onclick="createBackup()">Создать бэкап</button>
        </div>
    </div>
</div>

<!-- Модальное окно для системных логов -->
<div id="logsModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h5><i class="fas fa-history"></i> Системные логи MySQL</h5>
            <span class="close" onclick="closeModal('logsModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="form-group mb-3">
                <label class="form-label">Тип лога</label>
                <select class="form-control" id="logType">
                    <option value="error">Error Log</option>
                    <option value="slow">Slow Query Log</option>
                    <option value="general">General Log</option>
                    <option value="system">System Log (journalctl)</option>
                </select>
            </div>
            <div id="logsContent" class="query-log">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('logsModal')">Закрыть</button>
            <button class="btn btn-primary" onclick="refreshLogs()">Обновить</button>
        </div>
    </div>
</div>

<!-- Модальное окно для конфигурации -->
<div id="configModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h5><i class="fas fa-file-code"></i> Конфигурация MySQL (my.cnf)</h5>
            <span class="close" onclick="closeModal('configModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="configContent" class="query-log" style="max-height: 500px;">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('configModal')">Закрыть</button>
            <button class="btn btn-primary" onclick="copyConfig()">Копировать</button>
        </div>
    </div>
</div>

<!-- Модальное окно подтверждения -->
<div id="confirmModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5>Подтверждение</h5>
            <span class="close" onclick="closeModal('confirmModal')">&times;</span>
        </div>
        <div class="modal-body" id="confirmMessage">
            Вы уверены?
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('confirmModal')">Отмена</button>
            <button id="confirmBtn" class="btn btn-danger">Подтвердить</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
let confirmCallback = null;

// Показать процессы
function showProcessList() {
    document.getElementById('processModal').style.display = 'flex';
    loadProcesses();
}

function loadProcesses() {
    document.getElementById('processContent').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка процессов...';
    
    fetch('../api/mysql_redos_api.php?action=processes')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.processes && data.processes.length > 0) {
                let html = '<table style="width:100%; border-collapse: collapse;">';
                html += '<tr style="background: #34495e;"><th style="padding:8px;">ID</th><th style="padding:8px;">Пользователь</th><th style="padding:8px;">Хост</th><th style="padding:8px;">База</th><th style="padding:8px;">Команда</th><th style="padding:8px;">Время</th><th style="padding:8px;"></th></tr>';
                data.processes.forEach(proc => {
                    html += `<tr>
                        <td style="padding:5px;">${proc.Id}</td>
                        <td style="padding:5px;">${proc.User}</td>
                        <td style="padding:5px;">${proc.Host}</td>
                        <td style="padding:5px;">${proc.db || '-'}</td>
                        <td style="padding:5px;">${proc.Command}</td>
                        <td style="padding:5px;">${proc.Time} сек</td>
                        <td style="padding:5px;"><button class="btn-sm btn-danger" onclick="killProcess(${proc.Id})">Kill</button></td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('processContent').innerHTML = html;
            } else {
                document.getElementById('processContent').innerHTML = data.error || 'Нет активных процессов';
            }
        })
        .catch(error => {
            document.getElementById('processContent').innerHTML = `<span style="color: #e74c3c;">Ошибка: ${error}</span>`;
        });
}

function refreshProcesses() {
    loadProcesses();
}

function killProcess(processId) {
    if (confirm(`Убить процесс ${processId}?`)) {
        fetch(`../api/mysql_redos_api.php?action=kill_process&id=${processId}`, { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    loadProcesses();
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
            });
    }
}

// Показать переменные
function showVariables() {
    document.getElementById('variablesModal').style.display = 'flex';
    loadVariables();
}

function loadVariables() {
    document.getElementById('variablesContent').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка переменных...';
    
    fetch('../api/mysql_redos_api.php?action=variables')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.variables) {
                let html = '<table style="width:100%; border-collapse: collapse;">';
                html += '<tr style="background: #34495e;"><th style="padding:8px;">Переменная</th><th style="padding:8px;">Значение</th></tr>';
                data.variables.forEach(variable => {
                    html += `<tr>
                        <td style="padding:5px;">${variable.Variable_name}</td>
                        <td style="padding:5px;">${variable.Value}</td>
                    </tr>`;
                });
                html += '</table>';
                document.getElementById('variablesContent').innerHTML = html;
            } else {
                document.getElementById('variablesContent').innerHTML = data.error || 'Ошибка загрузки';
            }
        });
    
    // Фильтр переменных
    document.getElementById('variableFilter').addEventListener('keyup', function() {
        const filter = this.value.toLowerCase();
        const rows = document.querySelectorAll('#variablesContent table tr');
        rows.forEach((row, index) => {
            if (index === 0) return;
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
}

// Бэкап
function showBackup() {
    document.getElementById('backupModal').style.display = 'flex';
    document.getElementById('backupResult').style.display = 'none';
}

function createBackup() {
    const type = document.getElementById('backupType').value;
    const compression = document.getElementById('backupCompression').value;
    
    document.getElementById('backupResult').style.display = 'block';
    document.getElementById('backupResult').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Создание бэкапа...';
    
    fetch('../api/mysql_redos_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'backup', type: type, compression: compression })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('backupResult').innerHTML = `<span style="color: #27ae60;">✅ Бэкап создан: ${data.filename}</span>`;
            showToast('Бэкап создан успешно', 'success');
        } else {
            document.getElementById('backupResult').innerHTML = `<span style="color: #e74c3c;">❌ Ошибка: ${data.error}</span>`;
            showToast('Ошибка: ' + data.error, 'error');
        }
    });
}

// Оптимизация
function showOptimize() {
    confirmCallback = () => {
        fetch('../api/mysql_redos_api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'optimize' }) })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
                closeModal('confirmModal');
            });
    };
    showConfirm('Оптимизация базы данных', 'Выполнить оптимизацию всех таблиц? Это может занять некоторое время.');
}

// Flush Logs
function showFlush() {
    confirmCallback = () => {
        fetch('../api/mysql_redos_api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'flush_logs' }) })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
                closeModal('confirmModal');
            });
    };
    showConfirm('Flush Logs', 'Выполнить сброс всех логов?');
}

// Системные логи
function showSystemLogs() {
    document.getElementById('logsModal').style.display = 'flex';
    loadLogs();
}

function loadLogs() {
    const logType = document.getElementById('logType').value;
    document.getElementById('logsContent').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка логов...';
    
    fetch(`../api/mysql_redos_api.php?action=logs&type=${logType}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('logsContent').innerHTML = data.logs || 'Логи пусты';
            } else {
                document.getElementById('logsContent').innerHTML = `<span style="color: #e74c3c;">Ошибка: ${data.error}</span>`;
            }
        });
}

function refreshLogs() {
    loadLogs();
}

// Конфигурация
function showMySQLConfig() {
    document.getElementById('configModal').style.display = 'flex';
    document.getElementById('configContent').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка конфигурации...';
    
    fetch('../api/mysql_redos_api.php?action=config')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('configContent').innerHTML = data.config;
            } else {
                document.getElementById('configContent').innerHTML = `<span style="color: #e74c3c;">Ошибка: ${data.error}</span>`;
            }
        });
}

function copyConfig() {
    const configText = document.getElementById('configContent').innerText;
    navigator.clipboard.writeText(configText);
    showToast('Конфигурация скопирована', 'success');
}

// Перезапуск MySQL
function showRestart() {
    confirmCallback = () => {
        fetch('../api/mysql_redos_api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'restart' }) })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message, 'success');
                    setTimeout(() => location.reload(), 3000);
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
                closeModal('confirmModal');
            });
    };
    showConfirm('Перезапуск MySQL', 'Перезапустить сервер MySQL? Это может временно прервать соединения.');
}

function showConfirm(message, title = 'Подтверждение') {
    document.getElementById('confirmMessage').innerHTML = message;
    document.getElementById('confirmModal').style.display = 'flex';
}

document.getElementById('confirmBtn').onclick = () => {
    if (confirmCallback) confirmCallback();
};

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    confirmCallback = null;
}

function refreshPage() {
    location.reload();
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type === 'error' ? 'error' : ''}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        confirmCallback = null;
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
