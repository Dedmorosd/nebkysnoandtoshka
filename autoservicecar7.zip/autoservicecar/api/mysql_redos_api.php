<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'backup':
                $type = $input['type'] ?? 'full';
                $compression = $input['compression'] ?? 'gzip';
                $response = createBackupRedOS($type, $compression);
                break;
                
            case 'optimize':
                $response = optimizeDatabaseRedOS();
                break;
                
            case 'flush_logs':
                $response = flushLogsRedOS();
                break;
                
            case 'kill_process':
                $processId = $input['id'] ?? 0;
                $response = killProcessRedOS($processId);
                break;
                
            case 'restart':
                $response = restartMySQLRedOS();
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'processes':
                $response = getProcessesRedOS();
                break;
                
            case 'variables':
                $response = getVariablesRedOS();
                break;
                
            case 'logs':
                $type = $_GET['type'] ?? 'error';
                $response = getLogsRedOS($type);
                break;
                
            case 'config':
                $response = getConfigRedOS();
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции для RedOS
// ============================================

function getProcessesRedOS()
{
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW FULL PROCESSLIST");
        $processes = $stmt->fetchAll();
        return ['success' => true, 'processes' => $processes];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function getVariablesRedOS()
{
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW VARIABLES");
        $variables = $stmt->fetchAll();
        return ['success' => true, 'variables' => $variables];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function killProcessRedOS($processId)
{
    global $pdo;
    
    try {
        $pdo->exec("KILL " . intval($processId));
        return ['success' => true, 'message' => "Процесс $processId завершен"];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function getLogsRedOS($type)
{
    $logPaths = [
        'error' => '/var/log/mysql/error.log',
        'slow' => '/var/log/mysql/slow.log',
        'general' => '/var/log/mysql/general.log',
        'system' => '/var/log/messages'
    ];
    
    $logFile = $logPaths[$type] ?? null;
    
    if ($type === 'system') {
        // Для системных логов используем journalctl
        $output = shell_exec('sudo journalctl -u mysqld -n 100 --no-pager 2>&1');
        return ['success' => true, 'logs' => $output ?: 'Нет системных логов'];
    }
    
    if (!$logFile || !file_exists($logFile)) {
        return ['error' => 'Лог-файл не найден: ' . $logFile];
    }
    
    $lines = file($logFile);
    $lastLines = array_slice($lines, -500);
    $logs = implode('', $lastLines);
    
    return ['success' => true, 'logs' => $logs];
}

function getConfigRedOS()
{
    $configFile = '/etc/my.cnf';
    
    if (!file_exists($configFile)) {
        return ['error' => 'Файл конфигурации не найден'];
    }
    
    $config = file_get_contents($configFile);
    return ['success' => true, 'config' => $config];
}

function createBackupRedOS($type, $compression)
{
    $backupDir = '/backup/mysql/';
    
    // Создание директории если не существует
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    
    $date = date('Y-m-d_H-i-s');
    $filename = "backup_{$date}.sql";
    $filepath = $backupDir . $filename;
    
    // Формирование команды mysqldump
    $dumpOptions = '--single-transaction --routines --triggers --events';
    
    if ($type === 'structure') {
        $dumpOptions .= ' --no-data';
    } elseif ($type === 'data') {
        $dumpOptions .= ' --no-create-info';
    }
    
    // Путь к mysqldump
    $mysqldump = '/usr/bin/mysqldump';
    if (!file_exists($mysqldump)) {
        $mysqldump = 'mysqldump';
    }
    
    $command = sprintf(
        '%s -u%s -p%s %s %s > %s 2>&1',
        escapeshellcmd($mysqldump),
        escapeshellarg('Karachkin'),
        escapeshellarg('*iNPsB2D[4NO!Hfx'),
        $dumpOptions,
        'project_Karachkin',
        escapeshellarg($filepath)
    );
    
    exec($command, $output, $returnCode);
    
    if ($returnCode !== 0) {
        return ['error' => 'Ошибка создания бэкапа: ' . implode("\n", $output)];
    }
    
    // Сжатие
    if ($compression === 'gzip') {
        $gzFile = $filepath . '.gz';
        $content = file_get_contents($filepath);
        file_put_contents($gzFile, gzencode($content));
        unlink($filepath);
        $filename .= '.gz';
    }
    
    return ['success' => true, 'filename' => $filename];
}

function optimizeDatabaseRedOS()
{
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll();
        $optimized = 0;
        
        foreach ($tables as $table) {
            $tableName = $table[0];
            $pdo->exec("OPTIMIZE TABLE `$tableName`");
            $optimized++;
        }
        
        return ['success' => true, 'message' => "Оптимизировано $optimized таблиц"];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function flushLogsRedOS()
{
    global $pdo;
    
    try {
        $pdo->exec("FLUSH LOGS");
        return ['success' => true, 'message' => "Логи сброшены"];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function restartMySQLRedOS()
{
    // Проверка, что скрипт запущен с правами на выполнение systemctl
    $output = shell_exec('sudo systemctl restart mysqld 2>&1');
    
    // Проверка статуса после перезапуска
    sleep(2);
    $status = shell_exec('systemctl is-active mysqld 2>&1');
    
    if (trim($status) === 'active') {
        return ['success' => true, 'message' => "MySQL успешно перезапущен"];
    } else {
        return ['error' => "Ошибка перезапуска MySQL: " . $output];
    }
}
?> 
