<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'backup':
                $type = $input['type'] ?? 'full';
                $compression = $input['compression'] ?? 'gzip';
                $response = createBackup($type, $compression);
                break;
                
            case 'optimize':
                $response = optimizeDatabase();
                break;
                
            case 'kill_all':
                $response = killAllConnections();
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'logs':
                $type = $_GET['type'] ?? 'error';
                $response = getLogs($type);
                break;
                
            case 'connections':
                $response = getConnections();
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции
// ============================================

function getLogs($type)
{
    $logPaths = [
        'error' => 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/mysql-error.log',
        'slow' => 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/mysql-slow.log',
        'general' => 'C:/ProgramData/MySQL/MySQL Server 8.0/Data/mysql-general.log'
    ];
    
    $logFile = $logPaths[$type] ?? null;
    
    if (!$logFile || !file_exists($logFile)) {
        return ['error' => 'Лог-файл не найден'];
    }
    
    // Читаем последние 500 строк лога
    $lines = file($logFile);
    $lastLines = array_slice($lines, -500);
    $logs = implode('', $lastLines);
    
    return ['success' => true, 'logs' => $logs];
}

function getConnections()
{
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW PROCESSLIST");
        $connections = $stmt->fetchAll();
        
        return ['success' => true, 'connections' => $connections];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function killAllConnections()
{
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW PROCESSLIST");
        $connections = $stmt->fetchAll();
        $killed = 0;
        
        foreach ($connections as $conn) {
            if ($conn['Id'] != $pdo->query("SELECT CONNECTION_ID()")->fetchColumn()) {
                $pdo->exec("KILL " . $conn['Id']);
                $killed++;
            }
        }
        
        return ['success' => true, 'message' => "Убито $killed подключений"];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function createBackup($type, $compression)
{
    $backupDir = __DIR__ . '/../backups/mysql/';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    
    $date = date('Y-m-d_H-i-s');
    $filename = "backup_{$date}.sql";
    
    // Формирование команды mysqldump
    $dumpOptions = '--single-transaction --routines --triggers --events';
    
    if ($type === 'structure') {
        $dumpOptions .= ' --no-data';
    } elseif ($type === 'data') {
        $dumpOptions .= ' --no-create-info';
    }
    
    $command = sprintf(
        'mysqldump -u%s -p%s %s %s > %s 2>&1',
        escapeshellarg($GLOBALS['db_user'] ?? 'Karachkin'),
        escapeshellarg($GLOBALS['db_password'] ?? '*iNPsB2D[4NO!Hfx'),
        $dumpOptions,
        'project_Karachkin',
        escapeshellarg($backupDir . $filename)
    );
    
    exec($command, $output, $returnCode);
    
    if ($returnCode !== 0) {
        return ['error' => 'Ошибка создания бэкапа: ' . implode("\n", $output)];
    }
    
    // Сжатие
    if ($compression === 'gzip') {
        $gzFile = $backupDir . $filename . '.gz';
        $content = file_get_contents($backupDir . $filename);
        file_put_contents($gzFile, gzencode($content));
        unlink($backupDir . $filename);
        $filename .= '.gz';
    }
    
    return ['success' => true, 'filename' => $filename];
}

function optimizeDatabase()
{
    global $pdo;
    
    try {
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll();
        $optimized = 0;
        
        foreach ($tables as $table) {
            $tableName = $table[0];
            $pdo->exec("OPTIMIZE TABLE `$tableName`");
            $optimized++;
        }
        
        return ['success' => true, 'message' => "Оптимизировано $optimized таблиц"];
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}
?> 
