<?php
// exit.php — завершение сессии пользователя
declare(strict_types=1);

// Стартуем сессию, чтобы получить доступ к её данным и параметрам cookie
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Очищаем массив $_SESSION
$_SESSION = [];

// 2. Удаляем cookie сессии в браузере
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        [
            'expires'  => time() - 42000,
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax',
        ]
    );
}

// 3. Уничтожаем сессию на сервере
session_destroy();

// 4. Запрещаем кеширование страницы, чтобы «назад» не показал закрытую зону
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// 5. Возвращаем на страницу входа
header('Location: auth.php');
exit;