<?php
// db.php — подключение к базе данных
declare(strict_types=1);

// Настройки — вынесите в .env или файл вне веб-корня
$dbHost = '134.90.167.42';
$dbPort = 10306;
$dbName = 'project_Karachkin';
$dbUser = 'Karachkin';
$dbPass = getenv('DB_PASS') ?: '*iNPsB2D[4NO!Hfx';

mysqli_report(MYSQLI_REPORT_OFF);

$conn = @new mysqli($dbHost, $dbUser, $dbPass, $dbName, $dbPort);

if ($conn->connect_errno) {
    error_log('DB connect error: ' . $conn->connect_error);
    http_response_code(500);
    exit('Внутренняя ошибка сервера.');
}

$conn->set_charset('utf8mb4');