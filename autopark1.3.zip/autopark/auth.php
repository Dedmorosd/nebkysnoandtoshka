<?php
// auth.php — страница авторизации с капчей из картинок
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Обработка кнопки "Обновить капчу"
if (isset($_GET['refresh'])) {
    unset($_SESSION['captcha_answer']);
}

// ===== СЛУЖЕБНЫЙ ДОСТУП =====
// ИЗМЕНЕНО: Убрано const, теперь используются обычные переменные (работает на всех версиях PHP)
$service_login = 'admin';
$service_pass  = '12345';
$service_id    = 999;
// =============================

// --- ГЕНЕРАЦИЯ КАПЧИ ---
$captcha_data = [
    1 => 'лицо',
    2 => 'рука',
    3 => 'воротник',
    4 => 'плечо'
];

// Генерируем новую капчу только если её нет в сессии
if (!isset($_SESSION['captcha_answer'])) {
    $keys = array_keys($captcha_data);
    shuffle($keys);
    
    $captcha_tiles = array_slice($keys, 0, 4);
    $correct_id = $captcha_tiles[array_rand($captcha_tiles)];
    
    $_SESSION['captcha_answer'] = $correct_id;
    $_SESSION['captcha_question'] = $captcha_data[$correct_id];
    $_SESSION['captcha_tiles'] = $captcha_tiles;
}

$feedback = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signin'])) {
    $login    = trim((string)($_POST['login'] ?? ''));
    $pass     = (string)($_POST['pass'] ?? '');
    $captcha  = (string)($_POST['captcha'] ?? '');

    // 1. Проверка капчи
    if (empty($captcha) || (int)$captcha !== $_SESSION['captcha_answer']) {
        $feedback = 'Неверно выбрана картинка капчи.';
        
        // Обновляем капчу при ошибке
        $keys = array_keys($captcha_data);
        shuffle($keys);
        $captcha_tiles = array_slice($keys, 0, 4);
        $correct_id = $captcha_tiles[array_rand($captcha_tiles)];
        $_SESSION['captcha_answer'] = $correct_id;
        $_SESSION['captcha_question'] = $captcha_data[$correct_id];
        $_SESSION['captcha_tiles'] = $captcha_tiles;
    } 
    // 2. Проверка логина/пароля
    elseif ($login === '' || $pass === '') {
        $feedback = 'Заполните оба поля.';
    } 
    // ИЗМЕНЕНО: Используем переменные вместо констант
    elseif ($login === $service_login && $pass === $service_pass) {
        $_SESSION['user_id']   = $service_id;
        $_SESSION['user_name'] = 'Системный администратор';
        $_SESSION['role']      = 'admin';
        header('Location: dashboard.php');
        exit;
    } 
    else {
        $dbFile = __DIR__ . '/db.php';
        if (!is_file($dbFile)) {
            $feedback = 'Сервис авторизации временно недоступен.';
        } else {
            require $dbFile;
            if (!isset($conn) || !($conn instanceof mysqli)) {
                $feedback = 'Сервис авторизации временно недоступен.';
            } else {
                $sql  = 'SELECT id, full_name, password FROM users WHERE email = ? LIMIT 1';
                $stmt = $conn->prepare($sql);

                if ($stmt === false) {
                    $feedback = 'Внутренняя ошибка.';
                } else {
                    $stmt->bind_param('s', $login);
                    $stmt->execute();
                    $res = $stmt->get_result();

                    if ($res->num_rows !== 1) {
                        $feedback = 'Неверный логин или пароль.';
                    } else {
                        $row = $res->fetch_assoc();
                        if (password_verify($pass, $row['password'])) {
                            $_SESSION['user_id']   = (int)$row['id'];
                            $_SESSION['user_name'] = $row['full_name'];
                            $_SESSION['role']      = 'user';
                            header('Location: dashboard.php');
                            exit;
                        }
                        $feedback = 'Неверный логин или пароль.';
                    }
                    $stmt->close();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Авторизация</title>
    <style>
        :root { --accent: #2f7d4f; --accent-hover: #256640; --bg: #eef1f5; --card: #ffffff; --text: #222; --muted: #6b7280; --danger: #c0392b; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { width: 100%; max-width: 360px; background: var(--card); border-radius: 10px; padding: 28px 24px; box-shadow: 0 6px 24px rgba(0,0,0,.08); }
        .card h1 { margin: 0 0 20px; font-size: 20px; text-align: center; font-weight: 600; }
        .field { margin-bottom: 14px; }
        .field input { width: 100%; padding: 11px 12px; font-size: 15px; border: 1px solid #d1d5db; border-radius: 6px; outline: none; transition: border-color .15s; }
        .field input:focus { border-color: var(--accent); }
        
        .captcha-container { margin: 16px 0; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; text-align: center; }
        .captcha-title { font-size: 14px; font-weight: 600; margin-bottom: 10px; color: var(--text); }
        .captcha-title span { color: var(--accent); }
        .captcha-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        
        .captcha-tile { background: #fff; border: 2px solid #d1d5db; border-radius: 6px; overflow: hidden; cursor: pointer; transition: all .15s; aspect-ratio: 1/1; display: flex; align-items: center; justify-content: center; }
        .captcha-tile img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .captcha-tile:hover { border-color: #9ca3af; transform: scale(1.02); }
        .captcha-tile.selected { border-color: var(--accent); box-shadow: 0 0 0 2px rgba(47,125,79,.2); }

        .submit { width: 100%; padding: 11px; font-size: 15px; border: none; border-radius: 6px; background: var(--accent); color: #fff; cursor: pointer; transition: background .15s; margin-top: 8px; }
        .submit:hover { background: var(--accent-hover); }
        .notice { color: var(--danger); font-size: 14px; text-align: center; margin: 0 0 14px; background: #fef2f2; padding: 8px; border-radius: 6px; }
        .hint { margin-top: 18px; padding: 12px; border-radius: 6px; background: #f3f4f6; font-size: 12.5px; color: var(--muted); line-height: 1.5; text-align: center; }
        .hint b { color: var(--text); }
        .footer-link { margin: 16px 0 0; text-align: center; font-size: 13.5px; }
        .footer-link a { color: var(--accent); text-decoration: none; }
        .footer-link a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <main class="card">
        <h1>Вход в систему</h1>

        <?php if ($feedback !== ''): ?>
            <p class="notice"><?= htmlspecialchars($feedback, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>

        <form method="post" autocomplete="off" novalidate>
            <div class="field">
                <input type="text" name="login" placeholder="Логин или email" required>
            </div>
            <div class="field">
                <input type="password" name="pass" placeholder="Пароль" required>
            </div>
            
            <div class="captcha-container">
                <div class="captcha-title" style="display:flex; justify-content:space-between; align-items:center;">
                    <span>Выберите: <span><?= htmlspecialchars($_SESSION['captcha_question']) ?></span></span>
                    <a href="?refresh=1" style="font-size:12px; color:var(--accent); text-decoration:none; font-weight:normal;">🔄 Обновить</a>
                </div>
                
                <input type="hidden" name="captcha" id="captcha_input" required>
                <div class="captcha-grid">
                    <?php foreach ($_SESSION['captcha_tiles'] as $imgId): ?>
                        <div class="captcha-tile" data-value="<?= $imgId ?>" onclick="selectCaptcha(this)">
                            <img src="captcha/<?= $imgId ?>.png" alt="Фрагмент">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <button type="submit" name="signin" value="1" class="submit">Войти</button>
        </form>

        <div class="hint">
            <b>Технический доступ</b><br>
            Логин: <b>admin</b> · Пароль: <b>12345</b>
        </div>

        <p class="footer-link">Нет аккаунта? <a href="signup.php">Зарегистрироваться</a></p>
    </main>

    <script>
        function selectCaptcha(el) {
            document.querySelectorAll('.captcha-tile').forEach(t => t.classList.remove('selected'));
            el.classList.add('selected');
            document.getElementById('captcha_input').value = el.dataset.value;
        }
    </script>
</body>
</html>