<?php
// edit_car.php — редактирование автомобиля
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

require __DIR__ . '/db.php';
require __DIR__ . '/logger.php'; // Подключаем логгер

/** @var mysqli $conn */

$userName = (string)($_SESSION['user_name'] ?? 'пользователь');

// Получаем ID из URL
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$statuses = [
    'available' => 'Свободен',
    'on_trip'   => 'В рейсе',
    'repair'    => 'На ремонте',
];

// Загружаем текущие данные автомобиля из БД
$stmt = $conn->prepare('SELECT brand, model, plate_number, year, status FROM cars WHERE id = ?');
if ($stmt) {
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $car = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} else {
    $car = null;
}

if (!$car) {
    die('Автомобиль с таким ID не найден.');
}

// Заполняем форму текущими данными
$form = $car;

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $form['brand']        = trim((string)($_POST['brand']        ?? ''));
    $form['model']        = trim((string)($_POST['model']        ?? ''));
    $form['plate_number'] = trim((string)($_POST['plate_number'] ?? ''));
    $form['year']         = trim((string)($_POST['year']         ?? ''));
    $form['status']       = (string)($_POST['status']            ?? 'available');

    // Валидация
    if ($form['brand'] === '') $errors[] = 'Укажите марку.';
    if ($form['model'] === '') $errors[] = 'Укажите модель.';
    if ($form['plate_number'] === '') $errors[] = 'Укажите гос. номер.';

    $year = null;
    if ($form['year'] !== '') {
        if (!ctype_digit($form['year'])) {
            $errors[] = 'Год должен содержать только цифры.';
        } else {
            $year = (int)$form['year'];
            $maxYear = (int)date('Y') + 1;
            if ($year < 1900 || $year > $maxYear) {
                $errors[] = "Год должен быть в диапазоне 1900–{$maxYear}.";
            }
        }
    }
    
    if (!isset($statuses[$form['status']])) {
        $errors[] = 'Некорректный статус.';
    }

    // Сохранение изменений
    if (!$errors) {
        $sql = 'UPDATE cars SET brand=?, model=?, plate_number=?, year=?, status=? WHERE id=?';
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $yearBind = $year !== null ? $year : 0; // Передаем 0, если год пустой
            $stmt->bind_param('sssisi', $form['brand'], $form['model'], $form['plate_number'], $yearBind, $form['status'], $id);
            
            if ($stmt->execute()) {
                // Логируем действие
                $logText = "Изменил данные авто: {$form['brand']} {$form['model']} ({$form['plate_number']})";
                logAction($conn, $userName, $logText);
                
                // Перенаправляем на главную с сообщением об успехе
                header('Location: dashboard.php?msg=updated');
                exit;
            } else {
                if ($stmt->errno === 1062) {
                    $errors[] = 'Автомобиль с таким гос. номером уже существует.';
                } else {
                    $errors[] = 'Ошибка базы данных: ' . $stmt->error;
                }
            }
            $stmt->close();
        } else {
            $errors[] = 'Ошибка подготовки запроса: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Редактировать автомобиль</title>
    <style>
        :root { --accent: #2563eb; --accent-hover: #1d4ed8; --bg: #eef1f5; --card: #fff; --text: #1f2937; --muted: #6b7280; --border: #d1d5db; --danger: #b91c1c; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { width: 100%; max-width: 420px; background: var(--card); border-radius: 10px; padding: 28px 24px; box-shadow: 0 6px 24px rgba(0,0,0,.08); }
        .card h1 { margin: 0 0 20px; font-size: 20px; text-align: center; font-weight: 600; }
        .field { margin-bottom: 14px; }
        .field label { display: block; margin-bottom: 6px; font-size: 13.5px; font-weight: 500; color: var(--muted); }
        .field input, .field select { width: 100%; padding: 10px 12px; font-size: 15px; border: 1px solid var(--border); border-radius: 6px; outline: none; background: #fff; transition: border-color .15s; }
        .field input:focus, .field select:focus { border-color: var(--accent); }
        .submit { width: 100%; padding: 11px; font-size: 15px; border: none; border-radius: 6px; background: var(--accent); color: #fff; cursor: pointer; transition: background .15s; margin-top: 6px; }
        .submit:hover { background: var(--accent-hover); }
        .msg { margin: 0 0 16px; padding: 11px 14px; border-radius: 6px; font-size: 14px; line-height: 1.5; background: #fef2f2; color: var(--danger); border: 1px solid #fecaca; }
        .msg ul { margin: 0; padding-left: 18px; }
        .back-link { display: block; text-align: center; margin-top: 16px; font-size: 13.5px; color: var(--muted); text-decoration: none; }
        .back-link:hover { color: var(--accent); }
    </style>
</head>
<body>
    <main class="card">
        <h1>Редактирование авто #<?= $id ?></h1>

        <?php if ($errors): ?>
            <div class="msg">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" autocomplete="off" novalidate>
            <div class="field">
                <label for="brand">Марка *</label>
                <input type="text" id="brand" name="brand" placeholder="Например: Toyota" required 
                       value="<?= htmlspecialchars($form['brand'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            
            <div class="field">
                <label for="model">Модель *</label>
                <input type="text" id="model" name="model" placeholder="Например: Camry" required 
                       value="<?= htmlspecialchars($form['model'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            
            <div class="field">
                <label for="plate_number">Гос. номер *</label>
                <input type="text" id="plate_number" name="plate_number" placeholder="Например: А123БВ77" required maxlength="20" 
                       value="<?= htmlspecialchars($form['plate_number'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            
            <div class="field">
                <label for="year">Год выпуска</label>
                <input type="number" id="year" name="year" placeholder="Например: 2020" min="1900" max="<?= (int)date('Y') + 1 ?>" 
                       value="<?= htmlspecialchars((string)$form['year'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            
            <div class="field">
                <label for="status">Статус</label>
                <select id="status" name="status">
                    <?php foreach ($statuses as $val => $lbl): ?>
                        <option value="<?= htmlspecialchars($val, ENT_QUOTES, 'UTF-8') ?>" <?= $form['status'] === $val ? 'selected' : '' ?>>
                            <?= htmlspecialchars($lbl, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit" name="update" value="1" class="submit">Сохранить изменения</button>
        </form>

        <a href="dashboard.php" class="back-link">← Назад к списку</a>
    </main>
</body>
</html>