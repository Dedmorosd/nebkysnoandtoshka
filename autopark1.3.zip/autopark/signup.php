<?php
// signup.php — регистрация нового пользователя с капчей из картинок
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require __DIR__ . '/db.php';
/** @var mysqli $conn */

$errors  = [];
$success = false;

// --- ГЕНЕРАЦИЯ КАПЧИ ---
// Фрагменты картинки (1, 2, 3, 4)
$captcha_items = [1, 2, 3, 4];

// Генерируем новую капчу только при загрузке страницы (GET)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    shuffle($captcha_items); // Перемешиваем картинки, чтобы они стояли в случайном порядке
    
    // Выбираем правильный ответ (в данном случае правильный - это оригинальный фрагмент №1, 
    // но так как мы перемешали массив, нам нужно найти его новую позицию).
    // Для простоты сделаем правильным тот, который сейчас стоит ПЕРВЫМ в перемешанном массиве.
    $correct_id = $captcha_items[0]; 
    
    $_SESSION['captcha_answer'] = $correct_id;
    $_SESSION['captcha_tiles']  = $captcha_items;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $name  = trim((string)($_POST['name']     ?? ''));
    $email = mb_strtolower(trim((string)($_POST['email'] ?? '')));
    $pass  = (string)($_POST['pass']   ?? '');
    $pass2 = (string)($_POST['pass2']  ?? '');
    $captcha = (string)($_POST['captcha'] ?? '');

    // --- ВАЛИДАЦИЯ ---
    
    // 1. Проверка капчи
    if (empty($captcha) || (int)$captcha !== $_SESSION['captcha_answer']) {
        $errors[] = 'Неверно выбран фрагмент капчи.';
        
        // Если капча не пройдена, генерируем новую
        shuffle($captcha_items);
        $_SESSION['captcha_answer'] = $captcha_items[0];
        $_SESSION['captcha_tiles']  = $captcha_items;
    }

    // 2. Проверка полей
    if ($name === '') {
        $errors[] = 'Укажите имя.';
    } elseif (mb_strlen($name) < 2) {
        $errors[] = 'Имя слишком короткое.';
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Некорректный email.';
    }
    if (strlen($pass) < 6) {
        $errors[] = 'Пароль должен быть не менее 6 символов.';
    } elseif ($pass !== $pass2) {
        $errors[] = 'Пароли не совпадают.';
    }

    // 3. Проверка занятости email
    if (!$errors) {
        $check = $conn->prepare('SELECT 1 FROM users WHERE email = ? LIMIT 1');
        if ($check === false) {
            $errors[] = 'Внутренняя ошибка сервера.';
        } else {
            $check->bind_param('s', $email);
            $check->execute();
            $check->store_result();
            if ($check->num_rows > 0) {
                $errors[] = 'Этот email уже зарегистрирован.';
            }
            $check->close();
        }
    }

    // 4. Создание записи
    if (!$errors) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $ins  = $conn->prepare('INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)');
        if ($ins === false) {
            $errors[] = 'Внутренняя ошибка сервера.';
        } else {
            $ins->bind_param('sss', $name, $email, $hash);
            if ($ins->execute()) {
                $success = true;
            } else {
                $errors[] = 'Не удалось создать аккаунт.';
            }
            $ins->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Регистрация</title>
    <style>
        :root {
            --accent: #2563eb; --accent-hover: #1d4ed8;
            --bg: #eef1f5; --card: #ffffff;
            --text: #1f2937; --muted: #6b7280;
            --danger: #b91c1c; --success: #15803d; --border: #d1d5db;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0; min-height: 100vh; font-family: system-ui, -apple-system, sans-serif;
            background: var(--bg); color: var(--text); display: flex; align-items: center; justify-content: center; padding: 20px;
        }
        .card { width: 100%; max-width: 380px; background: var(--card); border-radius: 10px; padding: 28px 24px; box-shadow: 0 6px 24px rgba(0,0,0,.08); }
        .card h1 { margin: 0 0 18px; font-size: 20px; text-align: center; font-weight: 600; }
        .field { margin-bottom: 12px; }
        .field input { width: 100%; padding: 11px 12px; font-size: 15px; border: 1px solid var(--border); border-radius: 6px; outline: none; transition: border-color .15s; }
        .field input:focus { border-color: var(--accent); }
        .submit { width: 100%; padding: 11px; font-size: 15px; border: none; border-radius: 6px; background: var(--accent); color: #fff; cursor: pointer; transition: background .15s; margin-top: 6px; }
        .submit:hover { background: var(--accent-hover); }
        .msg { margin: 0 0 14px; padding: 10px 12px; border-radius: 6px; font-size: 14px; line-height: 1.45; }
        .msg-err { background: #fef2f2; color: var(--danger); border: 1px solid #fecaca; }
        .msg-ok  { background: #f0fdf4; color: var(--success); border: 1px solid #bbf7d0; }
        .msg ul { margin: 0; padding-left: 18px; }
        .msg a { color: inherit; font-weight: 600; }
        .footer-link { margin: 16px 0 0; text-align: center; font-size: 13.5px; color: var(--muted); }
        .footer-link a { color: var(--accent); text-decoration: none; }
        .footer-link a:hover { text-decoration: underline; }

        /* Стили для капчи */
        .captcha-container { margin: 16px 0; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; text-align: center; }
        .captcha-title { font-size: 14px; font-weight: 600; margin-bottom: 10px; color: var(--text); }
        .captcha-title span { color: var(--accent); }
        .captcha-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        .captcha-tile { background: #fff; border: 2px solid #d1d5db; border-radius: 6px; overflow: hidden; cursor: pointer; transition: all .15s; aspect-ratio: 1/1; }
        .captcha-tile img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .captcha-tile:hover { border-color: #9ca3af; transform: scale(1.02); }
        .captcha-tile.selected { border-color: var(--accent); box-shadow: 0 0 0 2px rgba(37,99,235,.2); }
    </style>
</head>
<body>
    <main class="card">
        <h1>Регистрация</h1>

        <?php if ($success): ?>
            <div class="msg msg-ok">Аккаунт создан. <a href="auth.php">Войти</a>.</div>
        <?php elseif ($errors): ?>
            <div class="msg msg-err">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="post" autocomplete="off" novalidate>
            <div class="field">
                <input type="text" name="name" placeholder="Ваше имя" required value="<?= htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="field">
                <input type="email" name="email" placeholder="Email" required value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="field">
                <input type="password" name="pass" placeholder="Пароль (мин. 6 символов)" required>
            </div>
            <div class="field">
                <input type="password" name="pass2" placeholder="Повторите пароль" required>
            </div>

            <!-- КАПЧА -->
            <div class="captcha-container">
                <div class="captcha-title">Соберите картинку: выберите <span>фрагмент №<?= $_SESSION['captcha_answer'] ?></span></div>
                <input type="hidden" name="captcha" id="captcha_input" required>
                
                <div class="captcha-grid">
                    <?php foreach ($_SESSION['captcha_tiles'] as $imgId): ?>
                        <div class="captcha-tile" data-value="<?= $imgId ?>" onclick="selectCaptcha(this)">
                            <!-- Убедитесь, что папка называется captcha, а картинки 1.jpg, 2.jpg и т.д. -->
                            <img src="captcha/<?= $imgId ?>.jpg" alt="Фрагмент <?= $imgId ?>">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <button type="submit" name="signup" value="1" class="submit">Зарегистрироваться</button>
        </form>
        <?php endif; ?>

        <p class="footer-link">Уже есть аккаунт? <a href="auth.php">Войти</a></p>
    </main>

    <script>
        function selectCaptcha(el) {
            document.querySelectorAll('.captcha-tile').forEach(t => t.classList.remove('selected'));
            el.classList.add('selected');
            document.getElementById('captcha_input').value = el.dataset.value;
        }
    </script>
</body>
</html> 
