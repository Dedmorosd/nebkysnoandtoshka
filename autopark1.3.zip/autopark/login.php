<?php
// auth.php — страница авторизации
declare(strict_types=1);
session_start();

// ===== СЛУЖЕБНЫЙ ДОСТУП (техническая учётка) =====
const SERVICE_LOGIN = 'admin';
const SERVICE_PASS  = '12345';
const SERVICE_ID    = 999;
// =================================================

$feedback = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signin'])) {
    $login    = trim((string)($_POST['login'] ?? ''));
    $pass     = (string)($_POST['pass'] ?? '');

    if ($login === '' || $pass === '') {
        $feedback = 'Заполните оба поля.';
    } elseif ($login === SERVICE_LOGIN && $pass === SERVICE_PASS) {
        // Технический вход
        $_SESSION['user_id']   = SERVICE_ID;
        $_SESSION['user_name'] = 'Системный администратор';
        $_SESSION['role']      = 'admin';
        header('Location: index.php');
        exit;
    } else {
        // Обычный пользователь — ищем в БД
        $dbFile = __DIR__ . '/db.php';
        if (!is_file($dbFile)) {
            $feedback = 'Сервис авторизации временно недоступен.';
        } else {
            require $dbFile;

            if (!isset($conn) || !($conn instanceof mysqli)) {
                $feedback = 'Сервис авторизации временно недоступен.';
            } else {
                $sql  = 'SELECT id, full_name, password FROM users WHERE email = ? LIMIT 1';
                $stmt = $conn->prepare($sql);

                if ($stmt === false) {
                    $feedback = 'Внутренняя ошибка. Попробуйте позже.';
                } else {
                    $stmt->bind_param('s', $login);
                    $stmt->execute();
                    $res = $stmt->get_result();

                    if ($res->num_rows !== 1) {
                        $feedback = 'Неверный логин или пароль.';
                    } else {
                        $row = $res->fetch_assoc();
                        if (password_verify($pass, $row['password'])) {
                            $_SESSION['user_id']   = (int)$row['id'];
                            $_SESSION['user_name'] = $row['full_name'];
                            $_SESSION['role']      = 'user';
                            header('Location: index.php');
                            exit;
                        }
                        $feedback = 'Неверный логин или пароль.';
                    }
                    $stmt->close();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Авторизация</title>
    <style>
        :root {
            --accent: #2f7d4f;
            --accent-hover: #256640;
            --bg: #eef1f5;
            --card: #ffffff;
            --text: #222;
            --muted: #6b7280;
            --danger: #c0392b;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0; min-height: 100vh;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
            background: var(--bg); color: var(--text);
            display: flex; align-items: center; justify-content: center;
            padding: 20px;
        }
        .card {
            width: 100%; max-width: 340px;
            background: var(--card);
            border-radius: 10px;
            padding: 28px 24px;
            box-shadow: 0 6px 24px rgba(0,0,0,.08);
        }
        .card h1 {
            margin: 0 0 20px;
            font-size: 20px;
            text-align: center;
            font-weight: 600;
        }
        .field { margin-bottom: 14px; }
        .field input {
            width: 100%;
            padding: 11px 12px;
            font-size: 15px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            outline: none;
            transition: border-color .15s;
        }
        .field input:focus { border-color: var(--accent); }
        .submit {
            width: 100%;
            padding: 11px;
            font-size: 15px;
            border: none;
            border-radius: 6px;
            background: var(--accent);
            color: #fff;
            cursor: pointer;
            transition: background .15s;
        }
        .submit:hover { background: var(--accent-hover); }
        .notice {
            color: var(--danger);
            font-size: 14px;
            text-align: center;
            margin: 0 0 14px;
        }
        .hint {
            margin-top: 18px;
            padding: 12px;
            border-radius: 6px;
            background: #f3f4f6;
            font-size: 12.5px;
            color: var(--muted);
            line-height: 1.5;
            text-align: center;
        }
        .hint b { color: var(--text); }
        .footer-link {
            margin: 16px 0 0;
            text-align: center;
            font-size: 13.5px;
        }
        .footer-link a { color: var(--accent); text-decoration: none; }
        .footer-link a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <main class="card">
        <h1>Вход в систему</h1>

        <?php if ($feedback !== ''): ?>
            <p class="notice"><?= htmlspecialchars($feedback, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>

        <form method="post" autocomplete="off" novalidate>
            <div class="field">
                <input type="text" name="login" placeholder="Логин или email" required>
            </div>
            <div class="field">
                <input type="password" name="pass" placeholder="Пароль" required>
            </div>
            <button type="submit" name="signin" value="1" class="submit">Войти</button>
        </form>

        <div class="hint">
            <b>Технический доступ</b><br>
            Логин: <b>admin</b> · Пароль: <b>12345</b>
        </div>

        <p class="footer-link">Нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
    </main>
</body>
</html>