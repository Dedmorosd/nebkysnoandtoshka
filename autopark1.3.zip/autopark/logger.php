<?php
// logger.php — запись действий в историю
function logAction(mysqli $conn, string $userName, string $actionText): void {
    $stmt = $conn->prepare('INSERT INTO activity_log (user_name, action_text) VALUES (?, ?)');
    if ($stmt) {
        $stmt->bind_param('ss', $userName, $actionText);
        $stmt->execute();
        $stmt->close();
    }
}