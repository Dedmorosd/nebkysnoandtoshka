<?php
// car_details.php — подробная информация об автомобиле
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

require __DIR__ . '/db.php';
/** @var mysqli $conn */

$userName = (string)($_SESSION['user_name'] ?? 'пользователь');
$isAdmin  = ($_SESSION['role'] ?? '') === 'admin';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: dashboard.php');
    exit;
}

$stmt = $conn->prepare('SELECT * FROM cars WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$car = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$car) {
    die('Автомобиль не найден.');
}

$statuses = [
    'available' => ['label' => 'Свободен',  'color' => '#047857', 'bg' => '#ecfdf5'],
    'on_trip'   => ['label' => 'В рейсе',   'color' => '#b91c1c', 'bg' => '#fef2f2'],
    'repair'    => ['label' => 'На ремонте', 'color' => '#b45309', 'bg' => '#fffbeb'],
];
$st = $statuses[$car['status']] ?? ['label' => $car['status'], 'color' => '#6b7280', 'bg' => '#f3f4f6'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></title>
    <style>
        :root { --accent: #2563eb; --bg: #eef1f5; --text: #1f2937; --muted: #6b7280; --border: #e5e7eb; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--text); }
        
        /* Навигация */
        .topbar { background: #1f2937; color: #fff; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; }
        .brand { font-weight: 600; font-size: 18px; margin-right: 30px; color: #fff; text-decoration: none; }
        .nav-links { display: flex; gap: 20px; flex: 1; }
        .nav-links a { color: #9ca3af; text-decoration: none; font-weight: 500; }
        .nav-links a:hover { color: #fff; }
        .user-block { display: flex; align-items: center; gap: 14px; font-size: 14px; }
        .logout { color: #fca5a5; text-decoration: none; }

        .wrap { max-width: 800px; margin: 40px auto; padding: 0 20px; }
        .card { background: #fff; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.08); overflow: hidden; }
        
        /* Визуальная шапка карточки */
        .hero { background: linear-gradient(135deg, #1e3a8a, #3b82f6); height: 160px; position: relative; display: flex; align-items: center; justify-content: center; }
        .hero-icon { font-size: 70px; opacity: 0.9; text-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        
        .content { padding: 30px; }
        .header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; }
        .title h1 { margin: 0 0 8px; font-size: 28px; font-weight: 700; }
        .title p { margin: 0; color: var(--muted); font-size: 16px; }
        
        .status-badge { padding: 6px 14px; border-radius: 999px; font-weight: 600; font-size: 14px; }
        
        .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px; background: #f9fafb; padding: 20px; border-radius: 8px; border: 1px solid var(--border); }
        .detail-item label { display: block; font-size: 12px; text-transform: uppercase; color: var(--muted); font-weight: 600; margin-bottom: 4px; }
        .detail-item span { font-size: 16px; font-weight: 500; }
        
        .actions { display: flex; gap: 12px; padding-top: 20px; border-top: 1px solid var(--border); }
        .btn { display: inline-block; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-weight: 500; font-size: 14px; border: none; cursor: pointer; }
        .btn-primary { background: var(--accent); color: #fff; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-outline { background: transparent; color: var(--text); border: 1px solid var(--border); }
        .btn-outline:hover { background: #f9fafb; }
    </style>
</head>
<body>

<header class="topbar">
    <a href="dashboard.php" class="brand">Автопарк</a>
    <nav class="nav-links">
        <a href="dashboard.php">Автомобили</a>
        <a href="companies.php">Компании</a>
    </nav>
    <div class="user-block">
        <span>Привет, <?= htmlspecialchars($userName) ?></span>
        <a href="exit.php" class="logout">Выйти</a>
    </div>
</header>

<main class="wrap">
    <div class="card">
        <div class="hero">
            <div class="hero-icon">🚗</div>
        </div>
        
        <div class="content">
            <div class="header-row">
                <div class="title">
                    <h1><?= htmlspecialchars($car['brand'] . ' ' . $car['model']) ?></h1>
                    <p>Год выпуска: <?= $car['year'] ? (int)$car['year'] : 'Не указан' ?></p>
                </div>
                <div class="status-badge" style="color: <?= $st['color'] ?>; background: <?= $st['bg'] ?>;">
                    <?= $st['label'] ?>
                </div>
            </div>

            <div class="details-grid">
                <div class="detail-item">
                    <label>Гос. номер</label>
                    <span><?= htmlspecialchars($car['plate_number']) ?></span>
                </div>
                <div class="detail-item">
                    <label>ID в системе</label>
                    <span>#<?= $car['id'] ?></span>
                </div>
                <div class="detail-item">
                    <label>Марка</label>
                    <span><?= htmlspecialchars($car['brand']) ?></span>
                </div>
                <div class="detail-item">
                    <label>Модель</label>
                    <span><?= htmlspecialchars($car['model']) ?></span>
                </div>
            </div>

            <div class="actions">
                <a href="dashboard.php" class="btn btn-outline">← Назад к списку</a>
                <a href="edit_car.php?id=<?= $car['id'] ?>" class="btn btn-primary">Редактировать данные</a>
            </div>
        </div>
    </div>
</main>

</body>
</html>