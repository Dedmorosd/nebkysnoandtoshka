<?php
// companies.php — список компаний-партнеров
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

require __DIR__ . '/db.php';
/** @var mysqli $conn */

$userName = (string)($_SESSION['user_name'] ?? 'пользователь');
$isAdmin  = ($_SESSION['role'] ?? '') === 'admin';

// Удаление компании
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM companies WHERE id = $id");
    header('Location: companies.php?msg=deleted');
    exit;
}

// Получение списка
$companies = [];
$res = $conn->query('SELECT * FROM companies ORDER BY id DESC');
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $companies[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Автопарк — Компании</title>
    <style>
        /* Базовые стили, идентичные dashboard.php */
        :root { --accent: #2563eb; --accent-hover: #1d4ed8; --bg: #eef1f5; --panel: #fff; --text: #1f2937; --muted: #6b7280; --border: #e5e7eb; --danger: #b91c1c; --head: #1f2937; }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); }
        
        /* Навигация */
        .topbar { background: var(--head); color: #fff; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .brand { font-weight: 600; font-size: 18px; margin-right: 30px; }
        .nav-links { display: flex; gap: 20px; flex: 1; }
        .nav-links a { color: #9ca3af; text-decoration: none; font-weight: 500; transition: color .15s; }
        .nav-links a:hover { color: #fff; }
        .nav-links a.active { color: #fff; border-bottom: 2px solid var(--accent); padding-bottom: 2px; }
        
        .user-block { display: flex; align-items: center; gap: 14px; font-size: 14px; }
        .badge { padding: 2px 8px; border-radius: 999px; font-size: 11.5px; background: rgba(255,255,255,.15); }
        .logout { color: #fca5a5; text-decoration: none; font-weight: 500; }
        
        .wrap { max-width: 1040px; margin: 0 auto; padding: 24px 20px 40px; }
        .page-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .page-head h1 { margin: 0; font-size: 22px; font-weight: 600; }
        
        .btn { display: inline-block; padding: 9px 16px; font-size: 14px; border-radius: 6px; text-decoration: none; color: #fff; background: var(--accent); transition: background .15s; border: none; cursor: pointer; }
        .btn:hover { background: var(--accent-hover); }
        
        .card { background: var(--panel); border-radius: 10px; box-shadow: 0 6px 24px rgba(0,0,0,.06); overflow: hidden; }
        .alert { padding: 12px 14px; margin-bottom: 16px; border-radius: 6px; font-size: 14px; background: #f0fdf4; color: #15803d; border: 1px solid #bbf7d0; }
        
        table { width: 100%; border-collapse: collapse; font-size: 14.5px; }
        th, td { padding: 12px 14px; text-align: left; border-bottom: 1px solid var(--border); }
        th { background: #f9fafb; font-weight: 600; font-size: 13px; text-transform: uppercase; color: var(--muted); }
        tbody tr:hover { background: #f9fafb; }
        .empty { text-align: center; color: var(--muted); padding: 26px; }
        
        .btn-del { color: var(--danger); text-decoration: none; font-weight: 500; font-size: 13.5px; }
        .btn-del:hover { text-decoration: underline; }
    </style>
</head>
<body>

<header class="topbar">
    <div style="display:flex; align-items:center; width:100%;">
        <div class="brand">Автопарк</div>
        <nav class="nav-links">
            <a href="dashboard.php">Автомобили</a>
            <a href="companies.php" class="active">Компании</a>
        </nav>
        <div class="user-block">
            <span>Привет, <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></span>
            <?php if ($isAdmin): ?><span class="badge">админ</span><?php endif; ?>
            <a href="exit.php" class="logout">Выйти</a>
        </div>
    </div>
</header>

<main class="wrap">
    <div class="page-head">
        <h1>Компании-партнёры</h1>
        <a href="add_company.php" class="btn">Добавить компанию</a>
    </div>

    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
        <div class="alert">Компания удалена из базы.</div>
    <?php endif; ?>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Название</th>
                    <th>Контактное лицо</th>
                    <th>Телефон</th>
                    <th>Email</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($companies): ?>
                    <?php foreach ($companies as $comp): ?>
                        <tr>
                            <td><?= (int)$comp['id'] ?></td>
                            <td><b><?= htmlspecialchars($comp['name'], ENT_QUOTES, 'UTF-8') ?></b></td>
                            <td><?= htmlspecialchars((string)$comp['contact_person'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars((string)$comp['phone'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td><?= htmlspecialchars((string)$comp['email'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td style="text-align: right;">
                                <a href="companies.php?delete=<?= (int)$comp['id'] ?>" class="btn-del" onclick="return confirm('Удалить компанию?');">Удалить</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="empty">В базе пока нет компаний</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

</body>
</html>