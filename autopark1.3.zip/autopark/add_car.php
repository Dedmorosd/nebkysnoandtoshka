<?php
// add_car.php — добавление автомобиля в автопарк
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

require __DIR__ . '/db.php';
/** @var mysqli $conn */

$errors  = [];
$success = false;
$userName = (string)($_SESSION['user_name'] ?? 'пользователь');

$statuses = [
    'available' => 'Свободен',
    'on_trip'   => 'В рейсе',
    'repair'    => 'На ремонте',
];

$form = [
    'brand'         => '',
    'model'         => '',
    'plate_number'  => '',
    'year'          => '',
    'status'        => 'available',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $form['brand']        = trim((string)($_POST['brand']        ?? ''));
    $form['model']        = trim((string)($_POST['model']        ?? ''));
    $form['plate_number'] = trim((string)($_POST['plate_number'] ?? ''));
    $form['year']         = trim((string)($_POST['year']         ?? ''));
    $form['status']       = (string)($_POST['status']            ?? 'available');

    if ($form['brand'] === '') $errors[] = 'Укажите марку.';
    if ($form['model'] === '') $errors[] = 'Укажите модель.';
    if ($form['plate_number'] === '') $errors[] = 'Укажите гос. номер.';

    $year = null;
    if ($form['year'] !== '') {
        if (!ctype_digit($form['year'])) {
            $errors[] = 'Год должен содержать только цифры.';
        } else {
            $year = (int)$form['year'];
            $maxYear = (int)date('Y') + 1;
            if ($year < 1900 || $year > $maxYear) {
                $errors[] = "Год должен быть в диапазоне 1900–{$maxYear}.";
            }
        }
    }

    if (!isset($statuses[$form['status']])) $errors[] = 'Некорректный статус.';

    if (!$errors) {
        $sql = 'INSERT INTO cars (brand, model, plate_number, year, status) VALUES (?, ?, ?, ?, ?)';
        $stmt = $conn->prepare($sql);
        
        if ($stmt === false) {
            $errors[] = 'Ошибка SQL: ' . $conn->error;
        } else {
            $yearBind = $year !== null ? $year : 0;
            $stmt->bind_param('sssis', $form['brand'], $form['model'], $form['plate_number'], $yearBind, $form['status']);

            if ($stmt->execute()) {
                $success = true;
                
                // --- ЗАПИСЬ В ИСТОРИЮ ---
                $tableCheck = $conn->query("SHOW TABLES LIKE 'activity_log'");
                if ($tableCheck && $tableCheck->num_rows > 0) {
                    $logText = "Добавил авто: {$form['brand']} {$form['model']} ({$form['plate_number']})";
                    $stmtLog = $conn->prepare('INSERT INTO activity_log (user_name, action_text) VALUES (?, ?)');
                    if ($stmtLog) {
                        $stmtLog->bind_param('ss', $userName, $logText);
                        $stmtLog->execute();
                        $stmtLog->close();
                    }
                }
                // ------------------------

                $form = ['brand' => '', 'model' => '', 'plate_number' => '', 'year' => '', 'status' => 'available'];
            } else {
                if ($stmt->errno === 1062) {
                    $errors[] = 'Автомобиль с таким гос. номером уже есть в базе.';
                } else {
                    $errors[] = 'Ошибка SQL: ' . $stmt->error;
                }
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Добавить автомобиль</title>
    <style>
        :root { --accent: #2563eb; --accent-hover: #1d4ed8; --bg: #eef1f5; --card: #fff; --text: #1f2937; --muted: #6b7280; --border: #d1d5db; --danger: #b91c1c; --success: #15803d; }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; font-family: system-ui, sans-serif; background: var(--bg); color: var(--text); display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { width: 100%; max-width: 420px; background: var(--card); border-radius: 10px; padding: 28px 24px; box-shadow: 0 6px 24px rgba(0,0,0,.08); }
        .card h1 { margin: 0 0 20px; font-size: 20px; text-align: center; font-weight: 600; }
        .field { margin-bottom: 14px; }
        .field label { display: block; margin-bottom: 6px; font-size: 13.5px; font-weight: 500; color: var(--muted); }
        .field input, .field select { width: 100%; padding: 10px 12px; font-size: 15px; border: 1px solid var(--border); border-radius: 6px; outline: none; background: #fff; transition: border-color .15s; }
        .field input:focus, .field select:focus { border-color: var(--accent); }
        .submit { width: 100%; padding: 11px; font-size: 15px; border: none; border-radius: 6px; background: var(--accent); color: #fff; cursor: pointer; transition: background .15s; margin-top: 6px; }
        .submit:hover { background: var(--accent-hover); }
        .msg { margin: 0 0 16px; padding: 11px 14px; border-radius: 6px; font-size: 14px; line-height: 1.5; }
        .msg-err { background: #fef2f2; color: var(--danger); border: 1px solid #fecaca; }
        .msg-ok  { background: #f0fdf4; color: var(--success); border: 1px solid #bbf7d0; }
        .msg ul { margin: 0; padding-left: 18px; }
        .msg a { color: inherit; font-weight: 600; }
        .back-link { display: block; text-align: center; margin-top: 16px; font-size: 13.5px; color: var(--muted); text-decoration: none; }
        .back-link:hover { color: var(--accent); }
    </style>
</head>
<body>
    <main class="card">
        <h1>Добавление автомобиля</h1>

        <?php if ($success): ?>
            <div class="msg msg-ok">Автомобиль сохранён. <a href="dashboard.php">К списку автомобилей</a>.</div>
        <?php elseif ($errors): ?>
            <div class="msg msg-err">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e, ENT_QUOTES, 'UTF-8') ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="post" autocomplete="off" novalidate>
            <div class="field">
                <label for="brand">Марка *</label>
                <input type="text" id="brand" name="brand" placeholder="Например: Toyota" required value="<?= htmlspecialchars($form['brand'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="field">
                <label for="model">Модель *</label>
                <input type="text" id="model" name="model" placeholder="Например: Camry" required value="<?= htmlspecialchars($form['model'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="field">
                <label for="plate_number">Гос. номер *</label>
                <input type="text" id="plate_number" name="plate_number" placeholder="Например: А123БВ77" required maxlength="20" value="<?= htmlspecialchars($form['plate_number'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="field">
                <label for="year">Год выпуска</label>
                <input type="number" id="year" name="year" placeholder="Например: 2020" min="1900" max="<?= (int)date('Y') + 1 ?>" value="<?= htmlspecialchars($form['year'], ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="field">
                <label for="status">Статус</label>
                <select id="status" name="status">
                    <?php foreach ($statuses as $value => $label): ?>
                        <option value="<?= htmlspecialchars($value, ENT_QUOTES, 'UTF-8') ?>" <?= $form['status'] === $value ? 'selected' : '' ?>>
                            <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" name="add" value="1" class="submit">Сохранить</button>
        </form>
        <?php endif; ?>

        <a href="dashboard.php" class="back-link">← Назад к списку автомобилей</a>
    </main>
</body>
</html>