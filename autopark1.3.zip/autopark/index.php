<?php
// dashboard.php — главная страница автопарка
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Доступ только авторизованным
if (empty($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

require __DIR__ . '/db.php';

/** @var mysqli $conn */

// Загружаем список автомобилей
$cars       = [];
$loadError  = null;

$stmt = $conn->prepare('SELECT id, brand, model, license_plate, status FROM cars ORDER BY id');
if ($stmt === false) {
    error_log('dashboard select prepare: ' . $conn->error);
    $loadError = 'Не удалось загрузить список автомобилей.';
} else {
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $cars[] = $row;
        }
    } else {
        error_log('dashboard select exec: ' . $stmt->error);
        $loadError = 'Не удалось загрузить список автомобилей.';
    }
    $stmt->close();
}

$userName = (string)($_SESSION['user_name'] ?? 'пользователь');
$isAdmin  = ($_SESSION['role'] ?? '') === 'admin';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Автопарк — главная</title>
    <style>
        :root {
            --accent: #2563eb;
            --accent-hover: #1d4ed8;
            --bg: #eef1f5;
            --panel: #ffffff;
            --text: #1f2937;
            --muted: #6b7280;
            --border: #e5e7eb;
            --danger: #b91c1c;
            --head: #1f2937;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
            background: var(--bg);
            color: var(--text);
        }
        .topbar {
            background: var(--head);
            color: #fff;
            padding: 14px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }
        .brand {
            font-weight: 600;
            letter-spacing: .3px;
        }
        .user-block {
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 14px;
        }
        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 999px;
            font-size: 11.5px;
            background: rgba(255,255,255,.15);
        }
        .logout {
            color: #fca5a5;
            text-decoration: none;
            font-weight: 500;
        }
        .logout:hover { text-decoration: underline; }
        .wrap {
            max-width: 1040px;
            margin: 0 auto;
            padding: 24px 20px 40px;
        }
        .page-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }
        .page-head h1 {
            margin: 0;
            font-size: 22px;
            font-weight: 600;
        }
        .btn {
            display: inline-block;
            padding: 9px 16px;
            font-size: 14px;
            border-radius: 6px;
            text-decoration: none;
            color: #fff;
            background: var(--accent);
            transition: background .15s;
        }
        .btn:hover { background: var(--accent-hover); }
        .card {
            background: var(--panel);
            border-radius: 10px;
            box-shadow: 0 6px 24px rgba(0,0,0,.06);
            overflow: hidden;
        }
        .alert {
            padding: 12px 14px;
            margin-bottom: 16px;
            border-radius: 6px;
            font-size: 14px;
            background: #fef2f2;
            color: var(--danger);
            border: 1px solid #fecaca;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14.5px;
        }
        th, td {
            padding: 12px 14px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        th {
            background: #f9fafb;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: .4px;
            color: var(--muted);
        }
        tbody tr:last-child td { border-bottom: none; }
        tbody tr:hover { background: #f9fafb; }
        .empty {
            text-align: center;
            color: var(--muted);
            padding: 26px 14px;
        }
        .status {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 999px;
            font-size: 12.5px;
            background: #eef2ff;
            color: #3730a3;
        }
        .status-free    { background: #ecfdf5; color: #047857; }
        .status-busy    { background: #fef2f2; color: #b91c1c; }
        .status-service { background: #fffbeb; color: #b45309; }
        @media (max-width: 600px) {
            .card { border-radius: 8px; }
            table, thead, tbody, tr, th, td { display: block; }
            thead { display: none; }
            tbody tr {
                padding: 10px 14px;
                border-bottom: 1px solid var(--border);
            }
            tbody td {
                padding: 6px 0;
                border: none;
                display: flex;
                justify-content: space-between;
                gap: 12px;
            }
            tbody td::before {
                content: attr(data-label);
                font-size: 12.5px;
                color: var(--muted);
                text-transform: uppercase;
                letter-spacing: .3px;
            }
        }
    </style>
</head>
<body>

<header class="topbar">
    <div class="brand">Автопарк</div>
    <div class="user-block">
        <span>Привет, <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></span>
        <?php if ($isAdmin): ?>
            <span class="badge">админ</span>
        <?php endif; ?>
        <a href="exit.php" class="logout">Выйти</a>
    </div>
</header>

<main class="wrap">
    <div class="page-head">
        <h1>Список автомобилей</h1>
        <a href="add_car.php" class="btn">Добавить автомобиль</a>
    </div>

    <?php if ($loadError !== null): ?>
        <div class="alert"><?= htmlspecialchars($loadError, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Марка</th>
                    <th>Модель</th>
                    <th>Номер</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($cars): ?>
                    <?php foreach ($cars as $car): ?>
                        <tr>
                            <td data-label="ID"><?= (int)$car['id'] ?></td>
                            <td data-label="Марка"><?= htmlspecialchars((string)$car['brand'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td data-label="Модель"><?= htmlspecialchars((string)$car['model'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td data-label="Номер"><?= htmlspecialchars((string)$car['license_plate'], ENT_QUOTES, 'UTF-8') ?></td>
                            <td data-label="Статус">
                                <?php
                                $status = (string)($car['status'] ?? '');
                                $cls = 'status';
                                switch (mb_strtolower($status)) {
                                    case 'свободен': case 'free': case 'доступен':
                                        $cls .= ' status-free'; break;
                                    case 'занят': case 'busy': case 'в рейсе':
                                        $cls .= ' status-busy'; break;
                                    case 'ремонт': case 'service': case 'обслуживание':
                                        $cls .= ' status-service'; break;
                                }
                                ?>
                                <span class="<?= $cls ?>"><?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="empty">В базе пока нет автомобилей</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

</body>
</html>