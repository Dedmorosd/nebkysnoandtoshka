<?php
// dashboard.php — главная страница автопарка
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

require __DIR__ . '/db.php';

/** @var mysqli $conn */

$cars      = [];
$loadError = null;
$search    = trim((string)($_GET['search'] ?? ''));
$filter    = trim((string)($_GET['filter'] ?? ''));
$userName  = (string)($_SESSION['user_name'] ?? 'пользователь');
$isAdmin   = ($_SESSION['role'] ?? '') === 'admin';

// --- УДАЛЕНИЕ ---
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    if ($deleteId > 0) {
        // Логирование удаления, если есть таблица
        $tableCheck = $conn->query("SHOW TABLES LIKE 'activity_log'");
        if ($tableCheck && $tableCheck->num_rows > 0) {
            $stmtCheck = $conn->prepare('SELECT brand, model, plate_number FROM cars WHERE id = ?');
            $stmtCheck->bind_param('i', $deleteId);
            $stmtCheck->execute();
            $carToDelete = $stmtCheck->get_result()->fetch_assoc();
            $stmtCheck->close();
            if ($carToDelete) {
                $logText = "Удалил авто: {$carToDelete['brand']} {$carToDelete['model']}";
                $stmtLog = $conn->prepare('INSERT INTO activity_log (user_name, action_text) VALUES (?, ?)');
                $stmtLog->bind_param('ss', $userName, $logText);
                $stmtLog->execute();
                $stmtLog->close();
            }
        }
        
        $stmtDel = $conn->prepare('DELETE FROM cars WHERE id = ?');
        if ($stmtDel !== false) {
            $stmtDel->bind_param('i', $deleteId);
            $stmtDel->execute();
            $stmtDel->close();
            header('Location: dashboard.php?msg=deleted');
            exit;
        }
    }
}

// --- ЭКСПОРТ В CSV ---
if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="cars_export.csv"');
    $output = fopen('php://output', 'w');
    fwrite($output, "\xEF\xBB\xBF"); 
    fputcsv($output, ['ID', 'Марка', 'Модель', 'Гос.номер', 'Год', 'Статус'], ';');
    $res = $conn->query('SELECT id, brand, model, plate_number, year, status FROM cars ORDER BY id');
    while ($row = $res->fetch_assoc()) {
        fputcsv($output, $row, ';');
    }
    fclose($output);
    exit;
}

// --- ЗАГРУЗКА СПИСКА ---
$sql = 'SELECT id, brand, model, plate_number, year, status FROM cars WHERE 1=1';
$params = [];
$types = '';

if ($search !== '') {
    $sql .= ' AND (brand LIKE ? OR model LIKE ? OR plate_number LIKE ?)';
    $like = '%' . $search . '%';
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types .= 'sss';
}
if ($filter !== '' && in_array($filter, ['available', 'on_trip', 'repair'], true)) {
    $sql .= ' AND status = ?';
    $params[] = $filter;
    $types .= 's';
}
$sql .= ' ORDER BY id';

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    $loadError = 'Не удалось загрузить список.';
} else {
    if ($params) $stmt->bind_param($types, ...$params);
    if ($stmt->execute()) {
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $cars[] = $row;
    } else {
        $loadError = 'Ошибка выполнения запроса.';
    }
    $stmt->close();
}

// Статистика
$stats = ['total' => 0, 'available' => 0, 'on_trip' => 0, 'repair' => 0];
$resAll = $conn->query('SELECT status, COUNT(*) as cnt FROM cars GROUP BY status');
if ($resAll) {
    while ($r = $resAll->fetch_assoc()) {
        $stats['total'] += $r['cnt'];
        if (isset($stats[$r['status']])) $stats[$r['status']] = (int)$r['cnt'];
    }
}

// История
$activities = [];
$tableCheck = $conn->query("SHOW TABLES LIKE 'activity_log'");
if ($tableCheck && $tableCheck->num_rows > 0) {
    $resLog = $conn->query('SELECT user_name, action_text, created_at FROM activity_log ORDER BY id DESC LIMIT 10');
    if ($resLog) {
        while ($r = $resLog->fetch_assoc()) $activities[] = $r;
    }
}

$statusLabels = [
    'available' => ['label' => 'Свободен',  'class' => 'status-free'],
    'on_trip'   => ['label' => 'В рейсе',   'class' => 'status-busy'],
    'repair'    => ['label' => 'На ремонте', 'class' => 'status-service'],
];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Автопарк — главная</title>
    <style>
        :root {
            --accent: #2563eb; --accent-hover: #1d4ed8;
            --bg: #eef1f5; --panel: #ffffff;
            --text: #1f2937; --muted: #6b7280;
            --border: #e5e7eb; --danger: #b91c1c; --head: #1f2937;
            --green: #047857; --red: #b91c1c; --orange: #b45309;
        }
        * { box-sizing: border-box; }
        body { margin: 0; font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); }
        
        /* НАВИГАЦИЯ */
        .topbar { background: var(--head); color: #fff; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .brand { font-weight: 600; font-size: 18px; margin-right: 30px; color: #fff; text-decoration: none; }
        .nav-links { display: flex; gap: 20px; flex: 1; }
        .nav-links a { color: #9ca3af; text-decoration: none; font-weight: 500; transition: color .15s; }
        .nav-links a:hover { color: #fff; }
        .nav-links a.active { color: #fff; border-bottom: 2px solid var(--accent); padding-bottom: 2px; }
        .user-block { display: flex; align-items: center; gap: 14px; font-size: 14px; }
        .badge { padding: 2px 8px; border-radius: 999px; font-size: 11.5px; background: rgba(255,255,255,.15); }
        .logout { color: #fca5a5; text-decoration: none; font-weight: 500; }
        
        .wrap { max-width: 1300px; margin: 0 auto; padding: 24px 20px 40px; }
        
        /* СТАТИСТИКА */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: var(--panel); border-radius: 10px; padding: 16px 20px; box-shadow: 0 4px 12px rgba(0,0,0,.04); border-left: 4px solid var(--accent); }
        .stat-card.green { border-left-color: var(--green); }
        .stat-card.red { border-left-color: var(--red); }
        .stat-card.orange { border-left-color: var(--orange); }
        .stat-title { font-size: 13px; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; font-weight: 600; margin-bottom: 6px; }
        .stat-value { font-size: 26px; font-weight: 700; color: var(--text); line-height: 1; }

        /* СЕТКА */
        .content-grid { display: grid; grid-template-columns: 2.5fr 1fr; gap: 24px; align-items: start; }
        @media (max-width: 1024px) { .content-grid { grid-template-columns: 1fr; } }

        .page-head { display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; }
        .page-head h1 { margin: 0; font-size: 22px; font-weight: 600; }
        
        .top-controls { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .search-form { display: flex; gap: 8px; }
        .search-form input { padding: 9px 12px; border: 1px solid var(--border); border-radius: 6px; font-size: 14px; outline: none; width: 220px; }
        .search-form input:focus { border-color: var(--accent); }
        
        .btn { display: inline-block; padding: 9px 16px; font-size: 14px; border-radius: 6px; text-decoration: none; color: #fff; background: var(--accent); transition: background .15s; cursor: pointer; border: none; white-space: nowrap; }
        .btn:hover { background: var(--accent-hover); }
        .btn-sec { background: #6b7280; }
        .btn-sec:hover { background: #4b5563; }
        .btn-export { background: #10b981; }
        .btn-export:hover { background: #059669; }

        /* Фильтры */
        .filters { display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap; }
        .filter-btn { padding: 6px 12px; border-radius: 999px; font-size: 13px; text-decoration: none; border: 1px solid var(--border); background: #fff; color: var(--muted); transition: all .15s; }
        .filter-btn:hover { background: #f9fafb; color: var(--text); }
        .filter-btn.active { background: var(--accent); color: #fff; border-color: var(--accent); }

        .card { background: var(--panel); border-radius: 10px; box-shadow: 0 6px 24px rgba(0,0,0,.06); overflow: hidden; }
        .alert { padding: 12px 14px; margin-bottom: 16px; border-radius: 6px; font-size: 14px; background: #fef2f2; color: var(--danger); border: 1px solid #fecaca; }
        .alert-success { background: #f0fdf4; color: #15803d; border-color: #bbf7d0; }
        
        table { width: 100%; border-collapse: collapse; font-size: 14.5px; }
        th, td { padding: 12px 14px; text-align: left; border-bottom: 1px solid var(--border); }
        th { background: #f9fafb; font-weight: 600; font-size: 13px; text-transform: uppercase; color: var(--muted); }
        tbody tr:hover { background: #f9fafb; }
        
        .empty { text-align: center; color: var(--muted); padding: 26px; }
        .status { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12.5px; background: #eef2ff; color: #3730a3; }
        .status-free { background: #ecfdf5; color: #047857; }
        .status-busy { background: #fef2f2; color: #b91c1c; }
        .status-service { background: #fffbeb; color: #b45309; }
        
        .actions { display: flex; gap: 12px; justify-content: flex-end; }
        .btn-edit { color: var(--accent); text-decoration: none; font-weight: 500; font-size: 13.5px; }
        .btn-edit:hover { text-decoration: underline; }
        .btn-del { color: var(--danger); text-decoration: none; font-weight: 500; font-size: 13.5px; }
        .btn-del:hover { text-decoration: underline; }

        .history-panel h2 { margin: 0 0 16px; font-size: 18px; font-weight: 600; }
        .history-list { list-style: none; padding: 0; margin: 0; }
        .history-item { padding: 12px 0; border-bottom: 1px solid var(--border); }
        .history-item:last-child { border-bottom: none; padding-bottom: 0; }
        .history-action { font-size: 14px; color: var(--text); margin-bottom: 4px; line-height: 1.4; }
        .history-meta { font-size: 12px; color: var(--muted); display: flex; justify-content: space-between; }
        .history-user { font-weight: 600; color: var(--accent); }
        
        @media (max-width: 768px) {
            .topbar { flex-direction: column; gap: 10px; align-items: flex-start; }
            .nav-links { flex-direction: column; gap: 8px; }
            .page-head { flex-direction: column; align-items: flex-start; }
            .top-controls { width: 100%; }
            .search-form { flex: 1; }
            .search-form input { width: 100%; }
        }
    </style>
</head>
<body>

<header class="topbar">
    <a href="dashboard.php" class="brand">Автопарк</a>
    <nav class="nav-links">
        <a href="dashboard.php" class="active">Автомобили</a>
        <a href="companies.php">Компании</a>
    </nav>
    <div class="user-block">
        <span>Привет, <?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></span>
        <?php if ($isAdmin): ?><span class="badge">админ</span><?php endif; ?>
        <a href="exit.php" class="logout">Выйти</a>
    </div>
</header>

<main class="wrap">
    
    <!-- СТАТИСТИКА -->
    <div class="stats-grid">
        <div class="stat-card"><div class="stat-title">Всего авто</div><div class="stat-value"><?= $stats['total'] ?></div></div>
        <div class="stat-card green"><div class="stat-title">Свободны</div><div class="stat-value"><?= $stats['available'] ?></div></div>
        <div class="stat-card red"><div class="stat-title">В рейсе</div><div class="stat-value"><?= $stats['on_trip'] ?></div></div>
        <div class="stat-card orange"><div class="stat-title">На ремонте</div><div class="stat-value"><?= $stats['repair'] ?></div></div>
    </div>

    <div class="content-grid">
        
        <!-- ЛЕВАЯ КОЛОНКА: ТАБЛИЦА -->
        <div>
            <div class="page-head">
                <h1>Список автомобилей</h1>
                <div class="top-controls">
                    <form class="search-form" method="GET">
                        <?php if ($filter): ?><input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>"><?php endif; ?>
                        <input type="text" name="search" placeholder="Поиск..." value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" class="btn btn-sec" style="padding: 9px 12px;">Найти</button>
                    </form>
                    <a href="dashboard.php?export=1" class="btn btn-export" title="Скачать в Excel">Экспорт</a>
                    <a href="add_car.php" class="btn">Добавить</a>
                </div>
            </div>

            <!-- ФИЛЬТРЫ -->
            <div class="filters">
                <a href="dashboard.php?search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === '' ? 'active' : '' ?>">Все</a>
                <a href="dashboard.php?filter=available&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'available' ? 'active' : '' ?>">Свободные</a>
                <a href="dashboard.php?filter=on_trip&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'on_trip' ? 'active' : '' ?>">В рейсе</a>
                <a href="dashboard.php?filter=repair&search=<?= urlencode($search) ?>" class="filter-btn <?= $filter === 'repair' ? 'active' : '' ?>">На ремонте</a>
            </div>

            <?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>
                <div class="alert alert-success">Автомобиль удалён.</div>
            <?php elseif (isset($_GET['msg']) && $_GET['msg'] === 'updated'): ?>
                <div class="alert alert-success">Данные обновлены.</div>
            <?php endif; ?>
            <?php if ($loadError !== null): ?>
                <div class="alert"><?= htmlspecialchars($loadError, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <div class="card">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th><th>Марка</th><th>Модель</th><th>Номер</th><th>Статус</th><th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($cars): ?>
                            <?php foreach ($cars as $car): ?>
                                <?php
                                $st = (string)($car['status'] ?? '');
                                $info = $statusLabels[$st] ?? ['label' => $st, 'class' => ''];
                                $cls = 'status' . ($info['class'] ? ' ' . $info['class'] : '');
                                ?>
                                <tr>
                                    <td><?= (int)$car['id'] ?></td>
                                    <td>
                                        <a href="car_details.php?id=<?= (int)$car['id'] ?>" style="color: var(--accent); text-decoration: none; font-weight: 500;">
                                            <?= htmlspecialchars((string)$car['brand'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>
                                    <td>
                                        <a href="car_details.php?id=<?= (int)$car['id'] ?>" style="color: var(--accent); text-decoration: none; font-weight: 500;">
                                            <?= htmlspecialchars((string)$car['model'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>
                                    <td><?= htmlspecialchars((string)$car['plate_number'], ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><span class="<?= $cls ?>"><?= htmlspecialchars($info['label'], ENT_QUOTES, 'UTF-8') ?></span></td>
                                    <td>
                                        <div class="actions">
                                            <a href="edit_car.php?id=<?= (int)$car['id'] ?>" class="btn-edit">Изменить</a>
                                            <a href="dashboard.php?delete=<?= (int)$car['id'] ?>" class="btn-del" onclick="return confirm('Удалить автомобиль?');">Удалить</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="empty">Ничего не найдено</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ПРАВАЯ КОЛОНКА: ИСТОРИЯ -->
        <div class="card" style="padding: 20px;">
            <div class="history-panel">
                <h2>Последние действия</h2>
                <?php if ($activities): ?>
                    <ul class="history-list">
                        <?php foreach ($activities as $act): ?>
                            <li class="history-item">
                                <div class="history-action"><?= htmlspecialchars($act['action_text'], ENT_QUOTES, 'UTF-8') ?></div>
                                <div class="history-meta">
                                    <span class="history-user"><?= htmlspecialchars($act['user_name'], ENT_QUOTES, 'UTF-8') ?></span>
                                    <span><?= date('d.m H:i', strtotime($act['created_at'])) ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p style="color:var(--muted); font-size: 14px;">Пока нет записей о действиях. (Создайте таблицу activity_log)</p>
                <?php endif; ?>
            </div>
        </div>

    </div>
</main>

</body>
</html>