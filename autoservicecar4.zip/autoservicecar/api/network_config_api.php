<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Обработка POST запросов с JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($action)) {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
}

$response = [];

try {
    switch ($action) {
        case 'view':
            $deviceId = $_GET['device_id'] ?? 0;
            $response = viewConfig($deviceId);
            break;
            
        case 'save':
            $deviceId = $input['device_id'] ?? 0;
            $config = $input['config'] ?? '';
            $response = saveConfig($deviceId, $config);
            break;
            
        case 'backup':
            $deviceId = $_GET['device_id'] ?? 0;
            $response = backupConfig($deviceId);
            break;
            
        case 'backup_all':
            $response = backupAllConfigs();
            break;
            
        case 'restore':
            $deviceId = $_GET['device_id'] ?? 0;
            $response = restoreConfig($deviceId);
            break;
            
        case 'diff':
            $deviceId = $_GET['device_id'] ?? 0;
            $response = showDiff($deviceId);
            break;
            
        case 'preview':
            $deviceId = $input['device_id'] ?? 0;
            $config = $input['config'] ?? '';
            $response = previewDiff($deviceId, $config);
            break;
            
        case 'status':
            $response = getDevicesStatus();
            break;
            
        case 'history':
            $deviceId = $_GET['device_id'] ?? 0;
            $response = getConfigHistory($deviceId);
            break;
            
        default:
            $response = ['error' => 'Неизвестное действие'];
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции
// ============================================

function viewConfig($deviceId)
{
    $configDir = __DIR__ . '/../configs/devices/';
    $configFile = $configDir . "device_{$deviceId}.rsc";
    
    if (file_exists($configFile)) {
        $config = file_get_contents($configFile);
        return ['success' => true, 'config' => $config];
    }
    
    // Генерация примера конфигурации
    $exampleConfig = getExampleConfig($deviceId);
    return ['success' => true, 'config' => $exampleConfig];
}

function saveConfig($deviceId, $config)
{
    $configDir = __DIR__ . '/../configs/devices/';
    if (!is_dir($configDir)) {
        mkdir($configDir, 0777, true);
    }
    
    // Сохранение текущей версии как бэкап
    $backupDir = __DIR__ . '/../configs/backups/';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    
    $oldConfigFile = $configDir . "device_{$deviceId}.rsc";
    if (file_exists($oldConfigFile)) {
        $backupFile = $backupDir . "device_{$deviceId}_" . date('Ymd_His') . ".rsc";
        copy($oldConfigFile, $backupFile);
    }
    
    // Сохранение новой конфигурации
    file_put_contents($oldConfigFile, $config);
    
    // Логирование изменения
    logConfigChange($deviceId, $config);
    
    return ['success' => true, 'message' => 'Конфигурация сохранена'];
}

function backupConfig($deviceId)
{
    $backupDir = __DIR__ . '/../configs/backups/';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    
    $configFile = __DIR__ . "/../configs/devices/device_{$deviceId}.rsc";
    $backupFile = $backupDir . "device_{$deviceId}_" . date('Ymd_His') . ".rsc";
    
    if (file_exists($configFile)) {
        copy($configFile, $backupFile);
        return ['success' => true, 'filename' => basename($backupFile)];
    }
    
    // Создание примера конфигурации
    $exampleConfig = getExampleConfig($deviceId);
    file_put_contents($backupFile, $exampleConfig);
    
    return ['success' => true, 'filename' => basename($backupFile)];
}

function backupAllConfigs()
{
    $devices = getDevicesList();
    $count = 0;
    
    foreach ($devices as $device) {
        $result = backupConfig($device['id']);
        if ($result['success']) {
            $count++;
        }
    }
    
    return ['success' => true, 'count' => $count];
}

function restoreConfig($deviceId)
{
    $backupDir = __DIR__ . '/../configs/backups/';
    $configFile = __DIR__ . "/../configs/devices/device_{$deviceId}.rsc";
    
    // Поиск последнего бэкапа
    $backups = glob($backupDir . "device_{$deviceId}_*.rsc");
    if (empty($backups)) {
        return ['error' => 'Нет доступных бэкапов'];
    }
    
    usort($backups, function($a, $b) {
        return filemtime($b) - filemtime($a);
    });
    
    $latestBackup = $backups[0];
    copy($latestBackup, $configFile);
    
    return ['success' => true, 'message' => 'Конфигурация восстановлена из ' . basename($latestBackup)];
}

function showDiff($deviceId)
{
    $configFile = __DIR__ . "/../configs/devices/device_{$deviceId}.rsc";
    $backupDir = __DIR__ . '/../configs/backups/';
    
    $backups = glob($backupDir . "device_{$deviceId}_*.rsc");
    if (empty($backups)) {
        return ['error' => 'Нет предыдущих версий для сравнения'];
    }
    
    usort($backups, function($a, $b) {
        return filemtime($b) - filemtime($a);
    });
    
    $currentConfig = file_exists($configFile) ? file_get_contents($configFile) : '';
    $previousConfig = file_get_contents($backups[0]);
    
    $diff = simpleDiff($previousConfig, $currentConfig);
    
    return ['success' => true, 'diff' => $diff];
}

function previewDiff($deviceId, $newConfig)
{
    $configFile = __DIR__ . "/../configs/devices/device_{$deviceId}.rsc";
    $currentConfig = file_exists($configFile) ? file_get_contents($configFile) : '';
    
    $diff = simpleDiff($currentConfig, $newConfig);
    
    return ['success' => true, 'diff' => $diff];
}

function getDevicesStatus()
{
    $devices = getDevicesList();
    
    foreach ($devices as &$device) {
        // Эмуляция проверки статуса
        $device['status'] = rand(0, 100) > 10 ? 'online' : 'offline';
    }
    
    return ['devices' => $devices];
}

function getConfigHistory($deviceId)
{
    $backupDir = __DIR__ . '/../configs/backups/';
    $backups = glob($backupDir . "device_{$deviceId}_*.rsc");
    
    $history = [];
    foreach ($backups as $backup) {
        $history[] = [
            'file' => basename($backup),
            'date' => date('Y-m-d H:i:s', filemtime($backup)),
            'size' => round(filesize($backup) / 1024, 2) . ' KB'
        ];
    }
    
    return ['success' => true, 'history' => $history];
}

function logConfigChange($deviceId, $config)
{
    $logFile = __DIR__ . '/../configs/changes.log';
    $logEntry = sprintf(
        "[%s] Device %d - Config changed by %s\n",
        date('Y-m-d H:i:s'),
        $deviceId,
        $_SESSION['username'] ?? 'unknown'
    );
    file_put_contents($logFile, $logEntry, FILE_APPEND);
}

function getExampleConfig($deviceId)
{
    $devices = getDevicesList();
    $device = null;
    
    foreach ($devices as $d) {
        if ($d['id'] == $deviceId) {
            $device = $d;
            break;
        }
    }
    
    if (!$device) {
        return "# Конфигурация устройства #{$deviceId}\n# Пример конфигурации\n\n";
    }
    
    return "# ============================================\n" .
           "# Конфигурация: {$device['name']}\n" .
           "# IP адрес: {$device['ip']}\n" .
           "# Тип: {$device['type']}\n" .
           "# Модель: {$device['model']}\n" .
           "# ============================================\n\n" .
           "/system identity set name=\"{$device['name']}\"\n\n" .
           "# Настройка интерфейсов\n" .
           "/interface ethernet set wan name=wan\n" .
           "/ip address add address={$device['ip']}/24 interface=wan\n\n" .
           "# Настройка DHCP\n" .
           "/ip pool add name=dhcp_pool ranges=192.168.1.100-192.168.1.200\n" .
           "/ip dhcp-server add name=dhcp1 interface=lan address-pool=dhcp_pool\n\n" .
           "# Настройка NAT\n" .
           "/ip firewall nat add chain=srcnat out-interface=wan action=masquerade\n\n" .
           "# Сохранение конфигурации\n" .
           "/system backup save name=backup\n";
}

function getDevicesList()
{
    return [
        ['id' => 1, 'name' => 'Moscow-Router', 'ip' => '10.10.10.1', 'type' => 'router', 'model' => 'MikroTik CCR2004'],
        ['id' => 2, 'name' => 'Moscow-Core-Switch', 'ip' => '10.10.10.2', 'type' => 'switch', 'model' => 'MikroTik CRS354'],
        ['id' => 3, 'name' => 'Moscow-Access-Switch', 'ip' => '10.10.10.3', 'type' => 'switch', 'model' => 'MikroTik CRS326'],
        ['id' => 4, 'name' => 'SPB-Router', 'ip' => '10.20.10.1', 'type' => 'router', 'model' => 'MikroTik RB5009'],
        ['id' => 5, 'name' => 'EKB-Router', 'ip' => '10.30.10.1', 'type' => 'router', 'model' => 'MikroTik RB5009'],
        ['id' => 6, 'name' => 'NSK-Router', 'ip' => '10.40.10.1', 'type' => 'router', 'model' => 'MikroTik RB5009'],
    ];
}

function simpleDiff($old, $new)
{
    $oldLines = explode("\n", $old);
    $newLines = explode("\n", $new);
    
    $diff = '';
    $maxLines = max(count($oldLines), count($newLines));
    
    for ($i = 0; $i < $maxLines; $i++) {
        $oldLine = $oldLines[$i] ?? '';
        $newLine = $newLines[$i] ?? '';
        
        if ($oldLine === $newLine) {
            $diff .= "<div style='color: #666;'>    {$oldLine}</div>\n";
        } elseif (empty($oldLine)) {
            $diff .= "<div class='diff-added' style='background: #d4edda; color: #155724;'>+   {$newLine}</div>\n";
        } elseif (empty($newLine)) {
            $diff .= "<div class='diff-removed' style='background: #f8d7da; color: #721c24;'>-   {$oldLine}</div>\n";
        } else {
            $diff .= "<div class='diff-removed' style='background: #f8d7da; color: #721c24;'>-   {$oldLine}</div>\n";
            $diff .= "<div class='diff-added' style='background: #d4edda; color: #155724;'>+   {$newLine}</div>\n";
        }
    }
    
    return $diff;
}
?> 
