<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$action = $_GET['action'] ?? '';

$response = [];

try {
    switch ($action) {
        case 'view':
            $triggerName = $_GET['name'] ?? '';
            $response = getTriggerInfo($pdo, $triggerName);
            break;
            
        case 'drop':
            $triggerName = $_GET['name'] ?? '';
            $response = dropTrigger($pdo, $triggerName);
            break;
            
        case 'list':
            $response = getTriggersList($pdo);
            break;
            
        default:
            $response = ['error' => 'Неизвестное действие'];
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции
// ============================================

function getTriggersList($pdo)
{
    try {
        $stmt = $pdo->query("
            SELECT 
                TRIGGER_NAME as name,
                EVENT_MANIPULATION as event,
                EVENT_OBJECT_TABLE as table_name,
                ACTION_TIMING as timing,
                CREATED as created
            FROM information_schema.TRIGGERS
            WHERE TRIGGER_SCHEMA = DATABASE()
            ORDER BY EVENT_OBJECT_TABLE, ACTION_TIMING, EVENT_MANIPULATION
        ");
        
        $triggers = $stmt->fetchAll();
        
        return [
            'success' => true,
            'triggers' => $triggers,
            'count' => count($triggers)
        ];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function getTriggerInfo($pdo, $triggerName)
{
    if (empty($triggerName)) {
        return ['error' => 'Имя триггера не указано'];
    }
    
    try {
        // Получение информации о триггере
        $stmt = $pdo->prepare("
            SELECT 
                TRIGGER_NAME as name,
                EVENT_MANIPULATION as event,
                EVENT_OBJECT_TABLE as table_name,
                ACTION_TIMING as timing,
                ACTION_STATEMENT as definition,
                CREATED as created,
                DEFINER as definer
            FROM information_schema.TRIGGERS
            WHERE TRIGGER_SCHEMA = DATABASE()
              AND TRIGGER_NAME = ?
        ");
        $stmt->execute([$triggerName]);
        $trigger = $stmt->fetch();
        
        if (!$trigger) {
            return ['error' => 'Триггер не найден'];
        }
        
        // Получение кода триггера
        $stmt = $pdo->prepare("SHOW CREATE TRIGGER $triggerName");
        $stmt->execute();
        $createResult = $stmt->fetch();
        
        $code = $createResult ? $createResult['SQL Original Statement'] : $trigger['definition'];
        
        return [
            'success' => true,
            'trigger' => $trigger,
            'code' => $code
        ];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function dropTrigger($pdo, $triggerName)
{
    if (empty($triggerName)) {
        return ['error' => 'Имя триггера не указано'];
    }
    
    try {
        // Проверка существования триггера
        $stmt = $pdo->prepare("
            SELECT TRIGGER_NAME 
            FROM information_schema.TRIGGERS 
            WHERE TRIGGER_SCHEMA = DATABASE() 
              AND TRIGGER_NAME = ?
        ");
        $stmt->execute([$triggerName]);
        
        if ($stmt->rowCount() == 0) {
            return ['error' => 'Триггер не найден'];
        }
        
        // Удаление триггера
        $pdo->exec("DROP TRIGGER IF EXISTS `$triggerName`");
        
        return ['success' => true, 'message' => "Триггер $triggerName удален"];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}
?> 
