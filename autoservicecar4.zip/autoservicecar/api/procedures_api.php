<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'create_order':
                $response = executeCreateOrder($pdo, $input['data']);
                break;
                
            case 'update_status':
                $response = executeUpdateStatus($pdo, $input['data']);
                break;
                
            case 'report':
                $response = executeReport($pdo, $input['data']);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'code':
                $procedureName = $_GET['name'] ?? '';
                $response = getProcedureCode($pdo, $procedureName);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции выполнения процедур
// ============================================

function executeCreateOrder($pdo, $data)
{
    try {
        $stmt = $pdo->prepare("
            CALL sp_create_order(?, ?, ?, ?, ?, @order_id, @total_price, @message)
        ");
        
        $stmt->execute([
            $data['client_id'],
            $data['car_id'],
            $data['service_ids'],
            $data['description'],
            $data['preferred_date']
        ]);
        
        $result = $pdo->query("SELECT @order_id AS order_id, @total_price AS total_price, @message AS message")->fetch();
        
        if ($result['order_id'] == -1) {
            return ['error' => $result['message']];
        }
        
        return [
            'success' => true,
            'order_id' => $result['order_id'],
            'total_price' => $result['total_price'],
            'message' => $result['message']
        ];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function executeUpdateStatus($pdo, $data)
{
    try {
        $stmt = $pdo->prepare("
            CALL sp_update_order_status(?, ?, ?, @result, @message)
        ");
        
        $stmt->execute([
            $data['order_id'],
            $data['new_status'],
            $data['employee_id'] ?: null
        ]);
        
        $result = $pdo->query("SELECT @result AS result, @message AS message")->fetch();
        
        return [
            'success' => $result['result'] == 1,
            'message' => $result['message']
        ];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function executeReport($pdo, $data)
{
    try {
        $stmt = $pdo->prepare("
            CALL sp_revenue_report(?, ?, ?, ?, @total_revenue, @orders_count, @avg_order)
        ");
        
        $stmt->execute([
            $data['start_date'] ?: null,
            $data['end_date'] ?: null,
            $data['group_by'],
            $data['branch_id'] ?: null
        ]);
        
        $details = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $stmt->nextRowset();
        $summary = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return [
            'success' => true,
            'summary' => [
                'total_revenue' => $summary['@total_revenue'] ?? 0,
                'orders_count' => $summary['@orders_count'] ?? 0,
                'avg_order' => $summary['@avg_order'] ?? 0
            ],
            'details' => $details
        ];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}

function getProcedureCode($pdo, $procedureName)
{
    try {
        $stmt = $pdo->prepare("SHOW CREATE PROCEDURE $procedureName");
        $stmt->execute();
        $result = $stmt->fetch();
        
        if ($result) {
            return [
                'success' => true,
                'code' => $result['Create Procedure']
            ];
        }
        
        return ['error' => 'Процедура не найдена'];
        
    } catch (PDOException $e) {
        return ['error' => $e->getMessage()];
    }
}
?> 
