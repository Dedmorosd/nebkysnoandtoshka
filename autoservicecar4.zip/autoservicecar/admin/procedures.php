<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Хранимые процедуры";

// Получение списка процедур
$procedures = [];
try {
    $stmt = $pdo->query("
        SELECT 
            ROUTINE_NAME as name,
            ROUTINE_COMMENT as comment,
            CREATED as created,
            LAST_ALTERED as modified,
            DEFINER as definer
        FROM information_schema.ROUTINES 
        WHERE ROUTINE_SCHEMA = 'project_Karachkin' 
            AND ROUTINE_TYPE = 'PROCEDURE'
        ORDER BY ROUTINE_NAME
    ");
    $procedures = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Ошибка получения списка процедур: " . $e->getMessage();
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --proc-primary: #2c3e50;
        --proc-success: #27ae60;
        --proc-warning: #f39c12;
        --proc-danger: #e74c3c;
        --proc-info: #3498db;
    }
    
    .procedures-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .procedure-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s, box-shadow 0.3s;
    }
    
    .procedure-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .procedure-header {
        background: linear-gradient(135deg, var(--proc-primary), #34495e);
        color: white;
        padding: 20px;
        position: relative;
    }
    
    .procedure-header h3 {
        margin: 0;
        font-size: 1.3em;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .procedure-body {
        padding: 20px;
    }
    
    .procedure-description {
        color: #7f8c8d;
        font-size: 0.9em;
        margin-bottom: 15px;
        padding-bottom: 15px;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .procedure-params {
        background: #f8f9fa;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 15px;
    }
    
    .procedure-param {
        font-family: monospace;
        font-size: 0.85em;
        padding: 3px 0;
    }
    
    .procedure-param.in { color: var(--proc-success); }
    .procedure-param.out { color: var(--proc-warning); }
    .procedure-param.inout { color: var(--proc-info); }
    
    .procedure-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
    }
    
    .proc-btn {
        flex: 1;
        padding: 10px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        font-weight: 500;
    }
    
    .proc-btn-primary {
        background: linear-gradient(135deg, var(--proc-primary), #34495e);
        color: white;
    }
    
    .proc-btn-success {
        background: linear-gradient(135deg, var(--proc-success), #1e8449);
        color: white;
    }
    
    .proc-btn-info {
        background: linear-gradient(135deg, var(--proc-info), #2980b9);
        color: white;
    }
    
    .proc-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 600px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        background: var(--proc-primary);
        color: white;
        border-radius: 15px 15px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: white;
    }
    
    .form-group {
        margin-bottom: 15px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
        color: var(--proc-primary);
    }
    
    .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
    }
    
    .form-control:focus {
        outline: none;
        border-color: var(--proc-primary);
        box-shadow: 0 0 0 3px rgba(44,62,80,0.1);
    }
    
    .result-box {
        background: #2c3e50;
        color: #0f0;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 13px;
        max-height: 300px;
        overflow-y: auto;
        white-space: pre-wrap;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
    }
    
    .toast.success { border-left: 4px solid var(--proc-success); }
    .toast.error { border-left: 4px solid var(--proc-danger); }
    .toast.info { border-left: 4px solid var(--proc-info); }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .stat-value {
        font-size: 2em;
        font-weight: 700;
        color: var(--proc-primary);
    }
    
    .stat-label {
        color: #7f8c8d;
        font-size: 0.85em;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-database"></i> Хранимые процедуры
        </h1>
        <div>
            <button class="btn btn-primary" onclick="refreshProcedures()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo count($procedures); ?></div>
            <div class="stat-label">Всего процедур</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">3</div>
            <div class="stat-label">Активных процедур</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo date('d.m.Y'); ?></div>
            <div class="stat-label">Последнее обновление</div>
        </div>
    </div>
    
    <!-- Список процедур -->
    <div class="procedures-grid">
        <!-- Процедура 1: Создание заказа -->
        <div class="procedure-card">
            <div class="procedure-header">
                <h3>
                    <i class="fas fa-plus-circle"></i> 
                    sp_create_order
                </h3>
            </div>
            <div class="procedure-body">
                <div class="procedure-description">
                    <i class="fas fa-info-circle"></i> Создание нового заказа с автоматическим расчетом стоимости
                </div>
                <div class="procedure-params">
                    <div class="procedure-param in"><strong>IN</strong> p_client_id INT</div>
                    <div class="procedure-param in"><strong>IN</strong> p_car_id INT</div>
                    <div class="procedure-param in"><strong>IN</strong> p_service_ids VARCHAR(255)</div>
                    <div class="procedure-param in"><strong>IN</strong> p_description TEXT</div>
                    <div class="procedure-param in"><strong>IN</strong> p_preferred_date DATE</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_order_id INT</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_total_price DECIMAL(10,2)</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_status_message VARCHAR(255)</div>
                </div>
                <div class="procedure-actions">
                    <button class="proc-btn proc-btn-primary" onclick="openCreateOrderModal()">
                        <i class="fas fa-play"></i> Выполнить
                    </button>
                    <button class="proc-btn proc-btn-info" onclick="viewCode('sp_create_order')">
                        <i class="fas fa-code"></i> Код
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Процедура 2: Обновление статуса заказа -->
        <div class="procedure-card">
            <div class="procedure-header">
                <h3>
                    <i class="fas fa-exchange-alt"></i> 
                    sp_update_order_status
                </h3>
            </div>
            <div class="procedure-body">
                <div class="procedure-description">
                    <i class="fas fa-info-circle"></i> Обновление статуса заказа с логированием
                </div>
                <div class="procedure-params">
                    <div class="procedure-param in"><strong>IN</strong> p_order_id INT</div>
                    <div class="procedure-param in"><strong>IN</strong> p_new_status VARCHAR(20)</div>
                    <div class="procedure-param in"><strong>IN</strong> p_employee_id INT</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_result BOOLEAN</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_message VARCHAR(255)</div>
                </div>
                <div class="procedure-actions">
                    <button class="proc-btn proc-btn-primary" onclick="openUpdateStatusModal()">
                        <i class="fas fa-play"></i> Выполнить
                    </button>
                    <button class="proc-btn proc-btn-info" onclick="viewCode('sp_update_order_status')">
                        <i class="fas fa-code"></i> Код
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Процедура 3: Отчет по выручке -->
        <div class="procedure-card">
            <div class="procedure-header">
                <h3>
                    <i class="fas fa-chart-bar"></i> 
                    sp_revenue_report
                </h3>
            </div>
            <div class="procedure-body">
                <div class="procedure-description">
                    <i class="fas fa-info-circle"></i> Формирование отчета по выручке за период
                </div>
                <div class="procedure-params">
                    <div class="procedure-param in"><strong>IN</strong> p_start_date DATE</div>
                    <div class="procedure-param in"><strong>IN</strong> p_end_date DATE</div>
                    <div class="procedure-param in"><strong>IN</strong> p_group_by VARCHAR(20)</div>
                    <div class="procedure-param in"><strong>IN</strong> p_branch_id INT</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_total_revenue DECIMAL(12,2)</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_orders_count INT</div>
                    <div class="procedure-param out"><strong>OUT</strong> p_avg_order DECIMAL(10,2)</div>
                </div>
                <div class="procedure-actions">
                    <button class="proc-btn proc-btn-primary" onclick="openReportModal()">
                        <i class="fas fa-play"></i> Выполнить
                    </button>
                    <button class="proc-btn proc-btn-info" onclick="viewCode('sp_revenue_report')">
                        <i class="fas fa-code"></i> Код
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно создания заказа -->
<div id="createOrderModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-plus-circle"></i> Создание заказа</h5>
            <span class="close" onclick="closeModal('createOrderModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="createOrderForm">
                <div class="form-group">
                    <label class="form-label">ID клиента *</label>
                    <input type="number" class="form-control" id="client_id" required>
                </div>
                <div class="form-group">
                    <label class="form-label">ID автомобиля *</label>
                    <input type="number" class="form-control" id="car_id" required>
                </div>
                <div class="form-group">
                    <label class="form-label">ID услуг (через запятую) *</label>
                    <input type="text" class="form-control" id="service_ids" placeholder="1,2,3" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Описание</label>
                    <textarea class="form-control" id="description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Предпочтительная дата *</label>
                    <input type="date" class="form-control" id="preferred_date" required>
                </div>
            </form>
            <div id="createOrderResult" class="result-box" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('createOrderModal')">Отмена</button>
            <button class="btn btn-primary" onclick="executeCreateOrder()">Выполнить</button>
        </div>
    </div>
</div>

<!-- Модальное окно обновления статуса -->
<div id="updateStatusModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-exchange-alt"></i> Обновление статуса заказа</h5>
            <span class="close" onclick="closeModal('updateStatusModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="updateStatusForm">
                <div class="form-group">
                    <label class="form-label">ID заказа *</label>
                    <input type="number" class="form-control" id="order_id" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Новый статус *</label>
                    <select class="form-control" id="new_status" required>
                        <option value="new">Новый</option>
                        <option value="in_progress">В работе</option>
                        <option value="completed">Завершен</option>
                        <option value="cancelled">Отменен</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">ID сотрудника (механика)</label>
                    <input type="number" class="form-control" id="employee_id">
                </div>
            </form>
            <div id="updateStatusResult" class="result-box" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('updateStatusModal')">Отмена</button>
            <button class="btn btn-primary" onclick="executeUpdateStatus()">Выполнить</button>
        </div>
    </div>
</div>

<!-- Модальное окно отчета -->
<div id="reportModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-chart-bar"></i> Отчет по выручке</h5>
            <span class="close" onclick="closeModal('reportModal')">&times;</span>
        </div>
        <div class="modal-body">
            <form id="reportForm">
                <div class="form-group">
                    <label class="form-label">Начальная дата</label>
                    <input type="date" class="form-control" id="start_date" value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Конечная дата</label>
                    <input type="date" class="form-control" id="end_date" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Группировка</label>
                    <select class="form-control" id="group_by">
                        <option value="day">По дням</option>
                        <option value="service">По услугам</option>
                        <option value="client">По клиентам</option>
                        <option value="status">По статусам</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">ID филиала</label>
                    <input type="number" class="form-control" id="branch_id" placeholder="Оставить пустым для всех">
                </div>
            </form>
            <div id="reportResult" class="result-box" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('reportModal')">Отмена</button>
            <button class="btn btn-primary" onclick="executeReport()">Выполнить</button>
        </div>
    </div>
</div>

<!-- Модальное окно просмотра кода -->
<div id="codeModal" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h5><i class="fas fa-code"></i> Код процедуры</h5>
            <span class="close" onclick="closeModal('codeModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="codeContent" class="result-box" style="background: #1e1e1e; color: #d4d4d4;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" onclick="copyCode()">Копировать</button>
            <button class="btn btn-secondary" onclick="closeModal('codeModal')">Закрыть</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
let currentProcedureCode = '';

// Открытие модальных окон
function openCreateOrderModal() {
    document.getElementById('createOrderForm').reset();
    document.getElementById('createOrderResult').style.display = 'none';
    document.getElementById('createOrderModal').style.display = 'flex';
}

function openUpdateStatusModal() {
    document.getElementById('updateStatusForm').reset();
    document.getElementById('updateStatusResult').style.display = 'none';
    document.getElementById('updateStatusModal').style.display = 'flex';
}

function openReportModal() {
    document.getElementById('reportForm').reset();
    document.getElementById('reportResult').style.display = 'none';
    document.getElementById('reportModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Выполнение создания заказа
function executeCreateOrder() {
    const data = {
        client_id: document.getElementById('client_id').value,
        car_id: document.getElementById('car_id').value,
        service_ids: document.getElementById('service_ids').value,
        description: document.getElementById('description').value,
        preferred_date: document.getElementById('preferred_date').value
    };
    
    if (!data.client_id || !data.car_id || !data.service_ids || !data.preferred_date) {
        showToast('Заполните все обязательные поля', 'error');
        return;
    }
    
    showToast('Выполнение процедуры...', 'info');
    
    fetch('../api/procedures_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create_order', data: data })
    })
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('createOrderResult');
        if (data.success) {
            resultDiv.innerHTML = `
                ✅ <strong>Заказ успешно создан!</strong><br><br>
                📋 Номер заказа: <strong>#${data.order_id}</strong><br>
                💰 Сумма: <strong>${Number(data.total_price).toLocaleString()} руб.</strong><br>
                📝 Сообщение: ${data.message}
            `;
            showToast('Заказ создан успешно', 'success');
        } else {
            resultDiv.innerHTML = `❌ Ошибка: ${data.error}`;
            showToast('Ошибка: ' + data.error, 'error');
        }
        resultDiv.style.display = 'block';
    })
    .catch(error => {
        showToast('Ошибка: ' + error, 'error');
    });
}

// Выполнение обновления статуса
function executeUpdateStatus() {
    const data = {
        order_id: document.getElementById('order_id').value,
        new_status: document.getElementById('new_status').value,
        employee_id: document.getElementById('employee_id').value
    };
    
    if (!data.order_id || !data.new_status) {
        showToast('Заполните ID заказа и статус', 'error');
        return;
    }
    
    showToast('Выполнение процедуры...', 'info');
    
    fetch('../api/procedures_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_status', data: data })
    })
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('updateStatusResult');
        if (data.success) {
            resultDiv.innerHTML = `✅ ${data.message}`;
            showToast('Статус обновлен', 'success');
        } else {
            resultDiv.innerHTML = `❌ Ошибка: ${data.error}`;
            showToast('Ошибка: ' + data.error, 'error');
        }
        resultDiv.style.display = 'block';
    })
    .catch(error => {
        showToast('Ошибка: ' + error, 'error');
    });
}

// Выполнение отчета
function executeReport() {
    const data = {
        start_date: document.getElementById('start_date').value,
        end_date: document.getElementById('end_date').value,
        group_by: document.getElementById('group_by').value,
        branch_id: document.getElementById('branch_id').value
    };
    
    showToast('Формирование отчета...', 'info');
    
    fetch('../api/procedures_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'report', data: data })
    })
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('reportResult');
        if (data.success) {
            let html = `📊 <strong>ОТЧЕТ ПО ВЫРУЧКЕ</strong><br><br>`;
            html += `💰 Общая выручка: <strong>${Number(data.summary.total_revenue).toLocaleString()} руб.</strong><br>`;
            html += `📋 Количество заказов: <strong>${data.summary.orders_count}</strong><br>`;
            html += `📊 Средний чек: <strong>${Number(data.summary.avg_order).toLocaleString()} руб.</strong><br><br>`;
            html += `<hr><strong>Детализация:</strong><br><br>`;
            
            if (data.details && data.details.length > 0) {
                html += `<table style="width:100%; border-collapse: collapse;">`;
                html += `<tr style="background: #34495e;"><th style="padding: 8px;">Период/Услуга</th><th style="padding: 8px;">Кол-во</th><th style="padding: 8px;">Выручка</th></tr>`;
                data.details.forEach(row => {
                    const period = row.period || row.service_name || row.client_name || row.status;
                    const count = row.orders_count || row.times_ordered || 0;
                    const revenue = row.revenue || row.total_revenue || row.total_spent || 0;
                    html += `<tr><td style="padding: 5px;">${period}</td><td style="padding: 5px;">${count}</td><td style="padding: 5px;">${Number(revenue).toLocaleString()} руб.</td></tr>`;
                });
                html += `</table>`;
            } else {
                html += `Нет данных за выбранный период`;
            }
            
            resultDiv.innerHTML = html;
            showToast('Отчет сформирован', 'success');
        } else {
            resultDiv.innerHTML = `❌ Ошибка: ${data.error}`;
            showToast('Ошибка: ' + data.error, 'error');
        }
        resultDiv.style.display = 'block';
    })
    .catch(error => {
        showToast('Ошибка: ' + error, 'error');
    });
}

// Просмотр кода процедуры
function viewCode(procedureName) {
    showToast('Загрузка кода...', 'info');
    
    fetch(`../api/procedures_api.php?action=code&name=${procedureName}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                currentProcedureCode = data.code;
                document.getElementById('codeContent').innerHTML = data.code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                document.getElementById('codeModal').style.display = 'flex';
            } else {
                showToast('Ошибка: ' + data.error, 'error');
            }
        });
}

function copyCode() {
    navigator.clipboard.writeText(currentProcedureCode);
    showToast('Код скопирован в буфер обмена', 'success');
}

function refreshProcedures() {
    location.reload();
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
