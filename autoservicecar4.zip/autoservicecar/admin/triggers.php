<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Управление триггерами";

// Получение списка триггеров
$triggers = [];
try {
    $stmt = $pdo->query("
        SELECT 
            TRIGGER_NAME as name,
            EVENT_MANIPULATION as event,
            EVENT_OBJECT_TABLE as table_name,
            ACTION_TIMING as timing,
            ACTION_STATEMENT as definition,
            CREATED as created,
            DEFINER as definer
        FROM information_schema.TRIGGERS
        WHERE TRIGGER_SCHEMA = 'project_Karachkin'
        ORDER BY EVENT_OBJECT_TABLE, ACTION_TIMING, EVENT_MANIPULATION
    ");
    $triggers = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Ошибка получения списка триггеров: " . $e->getMessage();
}

// Статистика по триггерам
$stats = [
    'total' => count($triggers),
    'before' => count(array_filter($triggers, fn($t) => $t['timing'] == 'BEFORE')),
    'after' => count(array_filter($triggers, fn($t) => $t['timing'] == 'AFTER')),
    'insert' => count(array_filter($triggers, fn($t) => $t['event'] == 'INSERT')),
    'update' => count(array_filter($triggers, fn($t) => $t['event'] == 'UPDATE')),
    'delete' => count(array_filter($triggers, fn($t) => $t['event'] == 'DELETE')),
];

require_once '../includes/header.php';
?>

<style>
    :root {
        --trigger-primary: #2c3e50;
        --trigger-success: #27ae60;
        --trigger-warning: #f39c12;
        --trigger-danger: #e74c3c;
        --trigger-info: #3498db;
        --trigger-before: #3498db;
        --trigger-after: #2ecc71;
        --trigger-insert: #27ae60;
        --trigger-update: #f39c12;
        --trigger-delete: #e74c3c;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2em;
        font-weight: 700;
        color: var(--trigger-primary);
    }
    
    .stat-label {
        color: #7f8c8d;
        font-size: 0.85em;
        margin-top: 5px;
    }
    
    .triggers-table {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .triggers-header {
        background: linear-gradient(135deg, var(--trigger-primary), #34495e);
        color: white;
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .triggers-table table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .triggers-table th,
    .triggers-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .triggers-table th {
        background: #f8f9fa;
        color: var(--trigger-primary);
        font-weight: 600;
    }
    
    .triggers-table tr:hover {
        background: #f8f9fa;
    }
    
    .trigger-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75em;
        font-weight: 600;
    }
    
    .badge-before { background: rgba(52, 152, 219, 0.15); color: #3498db; }
    .badge-after { background: rgba(46, 204, 113, 0.15); color: #2ecc71; }
    .badge-insert { background: rgba(39, 174, 96, 0.15); color: #27ae60; }
    .badge-update { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
    .badge-delete { background: rgba(231, 76, 60, 0.15); color: #e74c3c; }
    
    .action-buttons {
        display: flex;
        gap: 8px;
    }
    
    .action-btn {
        padding: 6px 12px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 0.8em;
        transition: all 0.3s;
    }
    
    .action-btn.view {
        background: #3498db;
        color: white;
    }
    
    .action-btn.drop {
        background: #e74c3c;
        color: white;
    }
    
    .action-btn:hover {
        transform: translateY(-2px);
        opacity: 0.9;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 800px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        background: var(--trigger-primary);
        color: white;
        border-radius: 15px 15px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: white;
    }
    
    .code-preview {
        background: #1e1e1e;
        color: #d4d4d4;
        padding: 15px;
        border-radius: 8px;
        font-family: 'Courier New', monospace;
        font-size: 13px;
        overflow-x: auto;
        white-space: pre-wrap;
        max-height: 500px;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
    }
    
    .toast.success { border-left: 4px solid var(--trigger-success); }
    .toast.error { border-left: 4px solid var(--trigger-danger); }
    .toast.info { border-left: 4px solid var(--trigger-info); }
    
    .trigger-info {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 15px;
    }
    
    .trigger-info p {
        margin: 5px 0;
    }
    
    .search-box {
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        width: 250px;
        font-size: 14px;
    }
    
    .search-box:focus {
        outline: none;
        border-color: var(--trigger-primary);
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-bolt"></i> Управление триггерами
        </h1>
        <div>
            <button class="btn btn-primary" onclick="refreshTriggers()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['total']; ?></div>
            <div class="stat-label">Всего триггеров</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['before']; ?></div>
            <div class="stat-label">BEFORE</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['after']; ?></div>
            <div class="stat-label">AFTER</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['insert']; ?></div>
            <div class="stat-label">INSERT</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['update']; ?></div>
            <div class="stat-label">UPDATE</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $stats['delete']; ?></div>
            <div class="stat-label">DELETE</div>
        </div>
    </div>
    
    <!-- Таблица триггеров -->
    <div class="triggers-table">
        <div class="triggers-header">
            <span><i class="fas fa-list"></i> Список триггеров</span>
            <input type="text" class="search-box" id="searchInput" placeholder="Поиск триггеров...">
        </div>
        <div style="overflow-x: auto;">
            <table id="triggersTable">
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Событие</th>
                        <th>Таблица</th>
                        <th>Тип</th>
                        <th>Дата создания</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($triggers as $trigger): ?>
                    <tr data-name="<?php echo htmlspecialchars($trigger['name']); ?>">
                        <td>
                            <i class="fas fa-bolt" style="color: var(--trigger-warning);"></i>
                            <strong><?php echo htmlspecialchars($trigger['name']); ?></strong>
                        </td>
                        <td>
                            <span class="trigger-badge badge-<?php echo strtolower($trigger['event']); ?>">
                                <?php echo $trigger['event']; ?>
                            </span>
                        </td>
                        <td><?php echo htmlspecialchars($trigger['table_name']); ?></td>
                        <td>
                            <span class="trigger-badge badge-<?php echo strtolower($trigger['timing']); ?>">
                                <?php echo $trigger['timing']; ?>
                            </span>
                        </td>
                        <td><?php echo date('d.m.Y H:i', strtotime($trigger['created'])); ?></td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn view" onclick="viewTrigger('<?php echo $trigger['name']; ?>')">
                                    <i class="fas fa-eye"></i> Просмотр
                                </button>
                                <button class="action-btn drop" onclick="dropTrigger('<?php echo $trigger['name']; ?>')">
                                    <i class="fas fa-trash"></i> Удалить
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Модальное окно просмотра триггера -->
<div id="viewModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-bolt"></i> Детали триггера</h5>
            <span class="close" onclick="closeModal('viewModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="triggerDetails"></div>
            <div id="triggerCode" class="code-preview">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" onclick="copyCode()">Копировать код</button>
            <button class="btn btn-secondary" onclick="closeModal('viewModal')">Закрыть</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
let currentTriggerCode = '';
let currentTriggerName = '';

// Поиск триггеров
document.getElementById('searchInput').addEventListener('keyup', function() {
    const searchValue = this.value.toLowerCase();
    const rows = document.querySelectorAll('#triggersTable tbody tr');
    
    rows.forEach(row => {
        const name = row.getAttribute('data-name').toLowerCase();
        if (name.includes(searchValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Просмотр триггера
function viewTrigger(triggerName) {
    currentTriggerName = triggerName;
    showToast('Загрузка информации о триггере...', 'info');
    
    fetch(`../api/triggers_api.php?action=view&name=${encodeURIComponent(triggerName)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const details = `
                    <div class="trigger-info">
                        <p><strong><i class="fas fa-tag"></i> Название:</strong> ${data.trigger.name}</p>
                        <p><strong><i class="fas fa-table"></i> Таблица:</strong> ${data.trigger.table_name}</p>
                        <p><strong><i class="fas fa-clock"></i> Событие:</strong> ${data.trigger.event}</p>
                        <p><strong><i class="fas fa-hourglass-half"></i> Тип:</strong> ${data.trigger.timing}</p>
                        <p><strong><i class="fas fa-calendar"></i> Создан:</strong> ${data.trigger.created}</p>
                        <p><strong><i class="fas fa-user"></i> Определитель:</strong> ${data.trigger.definer || 'N/A'}</p>
                    </div>
                `;
                document.getElementById('triggerDetails').innerHTML = details;
                document.getElementById('triggerCode').innerHTML = data.code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                currentTriggerCode = data.code;
                document.getElementById('viewModal').style.display = 'flex';
                showToast('Информация загружена', 'success');
            } else {
                showToast('Ошибка: ' + data.error, 'error');
            }
        })
        .catch(error => {
            showToast('Ошибка: ' + error, 'error');
        });
}

// Удаление триггера
function dropTrigger(triggerName) {
    if (confirm(`Вы уверены, что хотите удалить триггер "${triggerName}"? Это действие необратимо.`)) {
        showToast('Удаление триггера...', 'info');
        
        fetch(`../api/triggers_api.php?action=drop&name=${encodeURIComponent(triggerName)}`, { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Триггер успешно удален', 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
            })
            .catch(error => {
                showToast('Ошибка: ' + error, 'error');
            });
    }
}

// Копирование кода
function copyCode() {
    navigator.clipboard.writeText(currentTriggerCode);
    showToast('Код скопирован в буфер обмена', 'success');
}

// Обновление страницы
function refreshTriggers() {
    location.reload();
}

// Закрытие модального окна
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Показ уведомления
function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// Закрытие модального окна при клике вне его
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
