<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Управление конфигурацией сети";

// Список устройств с их конфигурациями
$devices = [
    [
        'id' => 1,
        'name' => 'Moscow-Router',
        'ip' => '10.10.10.1',
        'type' => 'router',
        'model' => 'MikroTik CCR2004',
        'os_version' => 'RouterOS 7.12',
        'status' => 'online',
        'last_backup' => '2024-01-15 02:30:00',
        'config_size' => '45.2 KB'
    ],
    [
        'id' => 2,
        'name' => 'Moscow-Core-Switch',
        'ip' => '10.10.10.2',
        'type' => 'switch',
        'model' => 'MikroTik CRS354',
        'os_version' => 'SwitchOS 2.14',
        'status' => 'online',
        'last_backup' => '2024-01-15 02:35:00',
        'config_size' => '28.1 KB'
    ],
    [
        'id' => 3,
        'name' => 'Moscow-Access-Switch',
        'ip' => '10.10.10.3',
        'type' => 'switch',
        'model' => 'MikroTik CRS326',
        'os_version' => 'SwitchOS 2.14',
        'status' => 'online',
        'last_backup' => '2024-01-15 02:40:00',
        'config_size' => '18.3 KB'
    ],
    [
        'id' => 4,
        'name' => 'SPB-Router',
        'ip' => '10.20.10.1',
        'type' => 'router',
        'model' => 'MikroTik RB5009',
        'os_version' => 'RouterOS 7.12',
        'status' => 'online',
        'last_backup' => '2024-01-15 02:45:00',
        'config_size' => '32.7 KB'
    ],
    [
        'id' => 5,
        'name' => 'EKB-Router',
        'ip' => '10.30.10.1',
        'type' => 'router',
        'model' => 'MikroTik RB5009',
        'os_version' => 'RouterOS 7.12',
        'status' => 'online',
        'last_backup' => '2024-01-15 02:50:00',
        'config_size' => '32.7 KB'
    ],
    [
        'id' => 6,
        'name' => 'NSK-Router',
        'ip' => '10.40.10.1',
        'type' => 'router',
        'model' => 'MikroTik RB5009',
        'os_version' => 'RouterOS 7.12',
        'status' => 'offline',
        'last_backup' => '2024-01-14 02:55:00',
        'config_size' => '32.7 KB'
    ]
];

// Получение статистики
$totalDevices = count($devices);
$onlineDevices = count(array_filter($devices, fn($d) => $d['status'] == 'online'));
$offlineDevices = $totalDevices - $onlineDevices;
$totalBackups = 24;
$lastBackupDate = '2024-01-15 03:00:00';

require_once '../includes/header.php';
?>

<style>
    :root {
        --config-primary: #2c3e50;
        --config-success: #27ae60;
        --config-warning: #f39c12;
        --config-danger: #e74c3c;
        --config-info: #3498db;
        --config-dark: #1a1a2e;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s;
        border-left: 4px solid var(--config-primary);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2.5em;
        font-weight: 700;
        color: var(--config-dark);
    }
    
    .stat-label {
        color: #7f8c8d;
        font-size: 0.85em;
        text-transform: uppercase;
    }
    
    .devices-table {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .devices-table-header {
        background: linear-gradient(135deg, var(--config-primary), var(--config-dark));
        color: white;
        padding: 15px 20px;
        font-weight: 600;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .devices-table table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .devices-table th,
    .devices-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .devices-table th {
        background: #f8f9fa;
        color: var(--config-primary);
        font-weight: 600;
    }
    
    .devices-table tr:hover {
        background: #f8f9fa;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75em;
        font-weight: 600;
    }
    
    .status-online {
        background: rgba(39, 174, 96, 0.15);
        color: #27ae60;
    }
    
    .status-offline {
        background: rgba(231, 76, 60, 0.15);
        color: #e74c3c;
    }
    
    .action-buttons {
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
    }
    
    .action-btn {
        padding: 5px 10px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 0.8em;
        transition: all 0.3s;
        background: #ecf0f1;
        color: #2c3e50;
    }
    
    .action-btn:hover {
        transform: translateY(-2px);
    }
    
    .action-btn.view { background: #3498db; color: white; }
    .action-btn.edit { background: #f39c12; color: white; }
    .action-btn.backup { background: #27ae60; color: white; }
    .action-btn.restore { background: #9b59b6; color: white; }
    .action-btn.diff { background: #1abc9c; color: white; }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 800px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--config-primary);
        color: white;
        border-radius: 15px 15px 0 0;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: white;
    }
    
    .config-preview {
        background: #2c3e50;
        color: #0f0;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        overflow-x: auto;
        white-space: pre-wrap;
        max-height: 500px;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
    }
    
    .toast.success { border-left: 4px solid #27ae60; }
    .toast.error { border-left: 4px solid #e74c3c; }
    .toast.info { border-left: 4px solid #3498db; }
    
    .diff-view {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
    }
    
    .diff-added {
        background: #d4edda;
        color: #155724;
    }
    
    .diff-removed {
        background: #f8d7da;
        color: #721c24;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-network-wired"></i> Управление конфигурацией сети
        </h1>
        <div>
            <button class="btn btn-primary" onclick="backupAll()">
                <i class="fas fa-database"></i> Бэкап всех устройств
            </button>
            <a href="network_config_history.php" class="btn btn-info">
                <i class="fas fa-history"></i> История изменений
            </a>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo $totalDevices; ?></div>
            <div class="stat-label">Всего устройств</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $onlineDevices; ?></div>
            <div class="stat-label">Онлайн</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $offlineDevices; ?></div>
            <div class="stat-label">Оффлайн</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo $totalBackups; ?></div>
            <div class="stat-label">Бэкапов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo date('d.m.Y H:i', strtotime($lastBackupDate)); ?></div>
            <div class="stat-label">Последний бэкап</div>
        </div>
    </div>
    
    <!-- Список устройств -->
    <div class="devices-table">
        <div class="devices-table-header">
            <span><i class="fas fa-microchip"></i> Сетевые устройства</span>
            <span><i class="fas fa-sync-alt"></i> Автообновление: 30 сек</span>
        </div>
        <div style="overflow-x: auto;">
            <table id="devicesTable">
                <thead>
                    <tr>
                        <th>Устройство</th>
                        <th>IP-адрес</th>
                        <th>Тип</th>
                        <th>Модель</th>
                        <th>Версия ПО</th>
                        <th>Статус</th>
                        <th>Последний бэкап</th>
                        <th>Размер</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($devices as $device): ?>
                    <tr data-device-id="<?php echo $device['id']; ?>">
                        <td>
                            <i class="fas <?php echo $device['type'] == 'router' ? 'fa-router' : 'fa-exchange-alt'; ?>"></i>
                            <?php echo $device['name']; ?>
                        </td>
                        <td><?php echo $device['ip']; ?></td>
                        <td><?php echo ucfirst($device['type']); ?></td>
                        <td><?php echo $device['model']; ?></td>
                        <td><?php echo $device['os_version']; ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $device['status']; ?>">
                                <i class="fas fa-circle" style="font-size: 8px;"></i> 
                                <?php echo ucfirst($device['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('d.m.Y H:i', strtotime($device['last_backup'])); ?></td>
                        <td><?php echo $device['config_size']; ?></td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn view" onclick="viewConfig(<?php echo $device['id']; ?>, '<?php echo $device['name']; ?>')">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit" onclick="editConfig(<?php echo $device['id']; ?>, '<?php echo $device['name']; ?>')">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn backup" onclick="backupDevice(<?php echo $device['id']; ?>, '<?php echo $device['name']; ?>')">
                                    <i class="fas fa-database"></i>
                                </button>
                                <button class="action-btn restore" onclick="restoreConfig(<?php echo $device['id']; ?>, '<?php echo $device['name']; ?>')">
                                    <i class="fas fa-undo-alt"></i>
                                </button>
                                <button class="action-btn diff" onclick="showDiff(<?php echo $device['id']; ?>, '<?php echo $device['name']; ?>')">
                                    <i class="fas fa-code-branch"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Модальное окно просмотра конфигурации -->
<div id="viewModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 id="viewModalTitle"><i class="fas fa-eye"></i> Просмотр конфигурации</h5>
            <span class="close" onclick="closeModal('viewModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="configContent" class="config-preview">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('viewModal')">Закрыть</button>
            <button class="btn btn-primary" onclick="copyToClipboard()">Копировать</button>
        </div>
    </div>
</div>

<!-- Модальное окно редактирования -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 id="editModalTitle"><i class="fas fa-edit"></i> Редактирование конфигурации</h5>
            <span class="close" onclick="closeModal('editModal')">&times;</span>
        </div>
        <div class="modal-body">
            <textarea id="configEditor" class="form-control" style="font-family: monospace; min-height: 400px;"></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('editModal')">Отмена</button>
            <button class="btn btn-warning" onclick="previewChanges()">Предпросмотр</button>
            <button class="btn btn-primary" onclick="saveConfig()">Сохранить</button>
        </div>
    </div>
</div>

<!-- Модальное окно сравнения -->
<div id="diffModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 id="diffModalTitle"><i class="fas fa-code-branch"></i> Сравнение версий</h5>
            <span class="close" onclick="closeModal('diffModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div id="diffContent" class="diff-view">Загрузка...</div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('diffModal')">Закрыть</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
let currentDeviceId = null;

// Просмотр конфигурации
function viewConfig(deviceId, deviceName) {
    currentDeviceId = deviceId;
    document.getElementById('viewModalTitle').innerHTML = `<i class="fas fa-eye"></i> Конфигурация: ${deviceName}`;
    document.getElementById('configContent').innerHTML = 'Загрузка...';
    document.getElementById('viewModal').style.display = 'flex';
    
    fetch(`../api/network_config_api.php?action=view&device_id=${deviceId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('configContent').innerHTML = data.config;
            } else {
                document.getElementById('configContent').innerHTML = `<span style="color: red;">Ошибка: ${data.error}</span>`;
            }
        })
        .catch(error => {
            document.getElementById('configContent').innerHTML = `<span style="color: red;">Ошибка загрузки: ${error}</span>`;
        });
}

// Редактирование конфигурации
function editConfig(deviceId, deviceName) {
    currentDeviceId = deviceId;
    document.getElementById('editModalTitle').innerHTML = `<i class="fas fa-edit"></i> Редактирование: ${deviceName}`;
    document.getElementById('configEditor').value = 'Загрузка...';
    document.getElementById('editModal').style.display = 'flex';
    
    fetch(`../api/network_config_api.php?action=view&device_id=${deviceId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('configEditor').value = data.config;
            } else {
                document.getElementById('configEditor').value = `Ошибка: ${data.error}`;
            }
        });
}

// Бэкап устройства
function backupDevice(deviceId, deviceName) {
    showToast(`Создание бэкапа для ${deviceName}...`, 'info');
    
    fetch(`../api/network_config_api.php?action=backup&device_id=${deviceId}`, { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`Бэкап ${deviceName} создан: ${data.filename}`, 'success');
                location.reload();
            } else {
                showToast(`Ошибка: ${data.error}`, 'error');
            }
        });
}

// Бэкап всех устройств
function backupAll() {
    showToast('Создание бэкапов всех устройств...', 'info');
    
    fetch('../api/network_config_api.php?action=backup_all', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`Создано бэкапов: ${data.count}`, 'success');
                location.reload();
            } else {
                showToast(`Ошибка: ${data.error}`, 'error');
            }
        });
}

// Восстановление конфигурации
function restoreConfig(deviceId, deviceName) {
    if (confirm(`Восстановить конфигурацию для ${deviceName}? Это действие может перезаписать текущие настройки.`)) {
        showToast(`Восстановление конфигурации для ${deviceName}...`, 'info');
        
        fetch(`../api/network_config_api.php?action=restore&device_id=${deviceId}`, { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(`Конфигурация ${deviceName} восстановлена`, 'success');
                } else {
                    showToast(`Ошибка: ${data.error}`, 'error');
                }
            });
    }
}

// Сохранение конфигурации
function saveConfig() {
    const newConfig = document.getElementById('configEditor').value;
    
    showToast('Сохранение конфигурации...', 'info');
    
    fetch('../api/network_config_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'save',
            device_id: currentDeviceId,
            config: newConfig
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Конфигурация сохранена', 'success');
            closeModal('editModal');
        } else {
            showToast(`Ошибка: ${data.error}`, 'error');
        }
    });
}

// Предпросмотр изменений
function previewChanges() {
    const currentConfig = document.getElementById('configEditor').value;
    
    fetch('../api/network_config_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'preview',
            device_id: currentDeviceId,
            config: currentConfig
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('diffModalTitle').innerHTML = `<i class="fas fa-code-branch"></i> Предпросмотр изменений`;
            document.getElementById('diffContent').innerHTML = data.diff;
            document.getElementById('diffModal').style.display = 'flex';
        }
    });
}

// Сравнение версий
function showDiff(deviceId, deviceName) {
    document.getElementById('diffModalTitle').innerHTML = `<i class="fas fa-code-branch"></i> Сравнение: ${deviceName}`;
    document.getElementById('diffContent').innerHTML = 'Загрузка...';
    document.getElementById('diffModal').style.display = 'flex';
    
    fetch(`../api/network_config_api.php?action=diff&device_id=${deviceId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('diffContent').innerHTML = data.diff;
            } else {
                document.getElementById('diffContent').innerHTML = `<span style="color: red;">Ошибка: ${data.error}</span>`;
            }
        });
}

// Копирование в буфер обмена
function copyToClipboard() {
    const configText = document.getElementById('configContent').innerText;
    navigator.clipboard.writeText(configText);
    showToast('Конфигурация скопирована в буфер обмена', 'success');
}

// Закрытие модального окна
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Показ уведомления
function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// Закрытие модального окна при клике вне его
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Автообновление статуса
setInterval(() => {
    fetch('../api/network_config_api.php?action=status')
        .then(response => response.json())
        .then(data => {
            if (data.devices) {
                for (const device of data.devices) {
                    const row = document.querySelector(`tr[data-device-id="${device.id}"]`);
                    if (row) {
                        const statusCell = row.cells[5];
                        statusCell.innerHTML = `<span class="status-badge status-${device.status}">
                            <i class="fas fa-circle" style="font-size: 8px;"></i> ${device.status}
                        </span>`;
                    }
                }
            }
        });
}, 30000);
</script>

<?php require_once '../includes/footer.php'; ?> 
