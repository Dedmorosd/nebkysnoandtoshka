<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$pageTitle = "Управление таблицами";
$action = $_GET['action'] ?? 'list';
$tableName = $_GET['table'] ?? '';

// Обработка создания таблицы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_table'])) {
        $newTableName = $_POST['table_name'];
        $columns = $_POST['columns'];
        
        $sql = "CREATE TABLE `$newTableName` (";
        $colDefs = [];
        foreach ($columns as $col) {
            $colDefs[] = "`{$col['name']}` {$col['type']}" . ($col['nullable'] ? '' : ' NOT NULL');
        }
        $sql .= implode(', ', $colDefs);
        $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        try {
            $pdo->exec($sql);
            $success = "Таблица '$newTableName' успешно создана";
        } catch (PDOException $e) {
            $error = "Ошибка: " . $e->getMessage();
        }
    }
    
    if (isset($_POST['add_column'])) {
        $table = $_POST['table_name'];
        $columnName = $_POST['column_name'];
        $columnType = $_POST['column_type'];
        $columnNullable = isset($_POST['column_nullable']) ? '' : ' NOT NULL';
        
        $sql = "ALTER TABLE `$table` ADD COLUMN `$columnName` $columnType$columnNullable";
        
        try {
            $pdo->exec($sql);
            $success = "Колонка '$columnName' добавлена";
        } catch (PDOException $e) {
            $error = "Ошибка: " . $e->getMessage();
        }
    }
    
    if (isset($_POST['drop_column'])) {
        $table = $_POST['table_name'];
        $columnName = $_POST['column_name'];
        
        $sql = "ALTER TABLE `$table` DROP COLUMN `$columnName`";
        
        try {
            $pdo->exec($sql);
            $success = "Колонка '$columnName' удалена";
        } catch (PDOException $e) {
            $error = "Ошибка: " . $e->getMessage();
        }
    }
}

// Получение структуры таблицы
$tableColumns = [];
if ($tableName) {
    try {
        $stmt = $pdo->query("DESCRIBE `$tableName`");
        $tableColumns = $stmt->fetchAll();
    } catch (PDOException $e) {
        $error = "Ошибка: " . $e->getMessage();
    }
}

// Получение списка таблиц
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

require_once '../includes/header.php';
?>

<style>
    .form-section {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .column-row {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 15px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        align-items: center;
    }
    
    .column-row input, .column-row select {
        flex: 1;
        min-width: 150px;
    }
    
    .type-select {
        width: 150px;
    }
    
    .nullable-check {
        width: auto;
    }
    
    .btn-add-column {
        background: var(--dbm-success);
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 8px;
        cursor: pointer;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-table"></i> Управление таблицами</h1>
        <a href="db_manager.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- Создание таблицы -->
    <div class="form-section">
        <h4><i class="fas fa-plus-circle"></i> Создать новую таблицу</h4>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Название таблицы</label>
                <input type="text" name="table_name" class="form-control" required pattern="[a-zA-Z_][a-zA-Z0-9_]*">
            </div>
            <div id="columnsContainer">
                <div class="column-row">
                    <input type="text" name="columns[0][name]" placeholder="Имя колонки" required>
                    <select name="columns[0][type]" class="type-select">
                        <option value="INT">INT</option>
                        <option value="VARCHAR(255)">VARCHAR(255)</option>
                        <option value="TEXT">TEXT</option>
                        <option value="DATE">DATE</option>
                        <option value="DATETIME">DATETIME</option>
                        <option value="DECIMAL(10,2)">DECIMAL(10,2)</option>
                        <option value="BOOLEAN">BOOLEAN</option>
                    </select>
                    <label class="nullable-check">
                        <input type="checkbox" name="columns[0][nullable]"> NULL
                    </label>
                </div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm mb-3" onclick="addColumn()">
                <i class="fas fa-plus"></i> Добавить колонку
            </button>
            <button type="submit" name="create_table" class="btn btn-primary">Создать таблицу</button>
        </form>
    </div>
    
    <!-- Редактирование таблицы -->
    <?php if ($tableName && $action === 'edit'): ?>
    <div class="form-section">
        <h4><i class="fas fa-edit"></i> Редактирование таблицы: <?php echo htmlspecialchars($tableName); ?></h4>
        
        <h5 class="mt-3">Структура таблицы</h5>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Поле</th>
                        <th>Тип</th>
                        <th>Null</th>
                        <th>Ключ</th>
                        <th>Default</th>
                        <th>Extra</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tableColumns as $col): ?>
                    <tr>
                        <td><?php echo $col['Field']; ?></td>
                        <td><?php echo $col['Type']; ?></td>
                        <td><?php echo $col['Null']; ?></td>
                        <td><?php echo $col['Key']; ?></td>
                        <td><?php echo $col['Default']; ?></td>
                        <td><?php echo $col['Extra']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <h5 class="mt-4">Добавить колонку</h5>
        <form method="POST" class="row g-3">
            <input type="hidden" name="table_name" value="<?php echo htmlspecialchars($tableName); ?>">
            <div class="col-md-4">
                <input type="text" name="column_name" class="form-control" placeholder="Имя колонки" required>
            </div>
            <div class="col-md-4">
                <select name="column_type" class="form-control">
                    <option value="INT">INT</option>
                    <option value="VARCHAR(255)">VARCHAR(255)</option>
                    <option value="TEXT">TEXT</option>
                    <option value="DATE">DATE</option>
                    <option value="DATETIME">DATETIME</option>
                    <option value="DECIMAL(10,2)">DECIMAL(10,2)</option>
                </select>
            </div>
            <div class="col-md-2">
                <label>
                    <input type="checkbox" name="column_nullable"> NULL
                </label>
            </div>
            <div class="col-md-2">
                <button type="submit" name="add_column" class="btn btn-success w-100">Добавить</button>
            </div>
        </form>
        
        <h5 class="mt-4">Удалить колонку</h5>
        <form method="POST" class="row g-3">
            <input type="hidden" name="table_name" value="<?php echo htmlspecialchars($tableName); ?>">
            <div class="col-md-8">
                <select name="column_name" class="form-control" required>
                    <option value="">Выберите колонку</option>
                    <?php foreach ($tableColumns as $col): ?>
                    <option value="<?php echo $col['Field']; ?>"><?php echo $col['Field']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" name="drop_column" class="btn btn-danger w-100" onclick="return confirm('Удалить колонку? Данные будут потеряны.')">Удалить колонку</button>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>

<script>
let columnCount = 1;

function addColumn() {
    const container = document.getElementById('columnsContainer');
    const newRow = document.createElement('div');
    newRow.className = 'column-row';
    newRow.innerHTML = `
        <input type="text" name="columns[${columnCount}][name]" placeholder="Имя колонки" required>
        <select name="columns[${columnCount}][type]" class="type-select">
            <option value="INT">INT</option>
            <option value="VARCHAR(255)">VARCHAR(255)</option>
            <option value="TEXT">TEXT</option>
            <option value="DATE">DATE</option>
            <option value="DATETIME">DATETIME</option>
            <option value="DECIMAL(10,2)">DECIMAL(10,2)</option>
            <option value="BOOLEAN">BOOLEAN</option>
        </select>
        <label class="nullable-check">
            <input type="checkbox" name="columns[${columnCount}][nullable]"> NULL
        </label>
        <button type="button" class="btn btn-sm btn-danger" onclick="this.parentElement.remove()">✕</button>
    `;
    container.appendChild(newRow);
    columnCount++;
}
</script>

<?php require_once '../includes/footer.php'; ?> 
