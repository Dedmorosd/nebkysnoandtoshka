<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$pageTitle = "Управление SSH ключами";

$sshKeys = [];
$authorizedKeysFile = '/home/admin/.ssh/authorized_keys';

if (file_exists($authorizedKeysFile)) {
    $content = file_get_contents($authorizedKeysFile);
    $keys = explode("\n", $content);
    foreach ($keys as $key) {
        if (trim($key) && strpos($key, 'ssh-rsa') !== false) {
            $parts = explode(' ', $key);
            $sshKeys[] = [
                'type' => $parts[0] ?? 'unknown',
                'key' => $parts[1] ?? '',
                'comment' => $parts[2] ?? 'Без комментария',
                'full' => $key
            ];
        }
    }
}

require_once '../includes/header.php';
?>

<div class="container">
    <h1 class="mb-4"><i class="fas fa-key"></i> Управление SSH ключами</h1>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Добавление SSH ключа</h5>
                </div>
                <div class="card-body">
                    <form id="addKeyForm">
                        <div class="mb-3">
                            <label class="form-label">Публичный ключ</label>
                            <textarea class="form-control" id="publicKey" rows="3" 
                                      placeholder="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQ... user@host"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Комментарий</label>
                            <input type="text" class="form-control" id="comment" placeholder="Ключ администратора">
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Добавить ключ
                        </button>
                    </form>
                    <div id="addResult" class="mt-3"></div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Инструкция по созданию ключа</h5>
                </div>
                <div class="card-body">
                    <h6>Linux / macOS:</h6>
                    <code class="d-block mb-2 p-2 bg-light">ssh-keygen -t rsa -b 4096 -C "your_email@example.com"</code>
                    <code class="d-block mb-3 p-2 bg-light">cat ~/.ssh/id_rsa.pub</code>
                    
                    <h6>Windows (PuTTY):</h6>
                    <p class="mb-0">Используйте PuTTYgen для генерации ключей</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card mt-4">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0"><i class="fas fa-list"></i> Установленные ключи</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Тип</th>
                            <th>Комментарий</th>
                            <th>Отпечаток</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody id="keysList">
                        <?php foreach ($sshKeys as $index => $key): ?>
                        <tr data-key-idx="<?php echo $index; ?>">
                            <td><?php echo htmlspecialchars($key['type']); ?></td>
                            <td><?php echo htmlspecialchars($key['comment']); ?></td>
                            <td><?php echo substr(htmlspecialchars($key['key']), 0, 20); ?>...</td>
                            <td>
                                <button class="btn btn-sm btn-danger" onclick="deleteKey(<?php echo $index; ?>)">
                                    <i class="fas fa-trash"></i> Удалить
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($sshKeys)): ?>
                        <tr>
                            <td colspan="4" class="text-center">Нет добавленных ключей</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('addKeyForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const publicKey = document.getElementById('publicKey').value;
    const comment = document.getElementById('comment').value;
    
    fetch('../api/remote_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'add_ssh_key', key: publicKey, comment: comment })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('addResult').innerHTML = '<div class="alert alert-success">Ключ добавлен успешно</div>';
            setTimeout(() => location.reload(), 1500);
        } else {
            document.getElementById('addResult').innerHTML = `<div class="alert alert-danger">Ошибка: ${data.error}</div>`;
        }
    });
});

function deleteKey(index) {
    if (confirm('Удалить этот ключ?')) {
        fetch('../api/remote_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete_ssh_key', index: index })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
            }
        });
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
