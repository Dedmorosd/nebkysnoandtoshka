<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();
$pageTitle = "Настройки аудита";

// Получение текущих настроек
$settings = [];
$variables = [
    'general_log', 'slow_query_log', 'log_queries_not_using_indexes',
    'long_query_time', 'expire_logs_days', 'binlog_format'
];

foreach ($variables as $var) {
    $stmt = $pdo->query("SHOW VARIABLES LIKE '$var'");
    $settings[$var] = $stmt->fetch()['Value'];
}

require_once '../includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-cog"></i> Настройки аудита</h1>
        <a href="audit.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Настройки логирования</h5>
                </div>
                <div class="card-body">
                    <form id="auditSettingsForm">
                        <div class="mb-3">
                            <label class="form-label">General Log</label>
                            <select name="general_log" class="form-control">
                                <option value="ON" <?php echo $settings['general_log'] == 'ON' ? 'selected' : ''; ?>>Включен</option>
                                <option value="OFF" <?php echo $settings['general_log'] == 'OFF' ? 'selected' : ''; ?>>Выключен</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Slow Query Log</label>
                            <select name="slow_query_log" class="form-control">
                                <option value="ON" <?php echo $settings['slow_query_log'] == 'ON' ? 'selected' : ''; ?>>Включен</option>
                                <option value="OFF" <?php echo $settings['slow_query_log'] == 'OFF' ? 'selected' : ''; ?>>Выключен</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Логирование запросов без индексов</label>
                            <select name="log_queries_not_using_indexes" class="form-control">
                                <option value="ON" <?php echo $settings['log_queries_not_using_indexes'] == 'ON' ? 'selected' : ''; ?>>Включен</option>
                                <option value="OFF" <?php echo $settings['log_queries_not_using_indexes'] == 'OFF' ? 'selected' : ''; ?>>Выключен</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Порог медленного запроса (сек)</label>
                            <input type="number" name="long_query_time" class="form-control" step="0.1" value="<?php echo $settings['long_query_time']; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Хранение бинарных логов (дни)</label>
                            <input type="number" name="expire_logs_days" class="form-control" value="<?php echo $settings['expire_logs_days']; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Формат бинарного лога</label>
                            <select name="binlog_format" class="form-control">
                                <option value="ROW" <?php echo $settings['binlog_format'] == 'ROW' ? 'selected' : ''; ?>>ROW</option>
                                <option value="STATEMENT" <?php echo $settings['binlog_format'] == 'STATEMENT' ? 'selected' : ''; ?>>STATEMENT</option>
                                <option value="MIXED" <?php echo $settings['binlog_format'] == 'MIXED' ? 'selected' : ''; ?>>MIXED</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Сохранить настройки</button>
                        <button type="button" class="btn btn-danger" onclick="clearAuditData()">Очистить логи аудита</button>
                    </form>
                    <div id="resultMessage" class="mt-3"></div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Информация</h5>
                </div>
                <div class="card-body">
                    <h6>Рекомендации по настройке:</h6>
                    <ul>
                        <li><strong>General Log</strong> - включайте только для отладки, создает большую нагрузку</li>
                        <li><strong>Slow Query Log</strong> - рекомендуется всегда включен</li>
                        <li><strong>Порог медленного запроса</strong> - 1-2 секунды для OLTP, 5-10 для отчетов</li>
                        <li><strong>Хранение бинарных логов</strong> - 7-14 дней для большинства систем</li>
                        <li><strong>binlog_format</strong> - ROW наиболее безопасен для репликации</li>
                    </ul>
                    <hr>
                    <h6>Команды для управления аудитом:</h6>
                    <pre class="bg-light p-2 rounded">
-- Просмотр статуса
SHOW VARIABLES LIKE 'log%';

-- Включение/отключение
SET GLOBAL general_log = ON;
SET GLOBAL slow_query_log = ON;

-- Очистка логов
FLUSH LOGS;
PURGE BINARY LOGS BEFORE NOW();

-- Просмотр размера логов
SELECT table_schema, 
       ROUND(SUM(data_length+index_length)/1024/1024,2) AS size_mb
FROM information_schema.tables
WHERE table_schema = 'audit_db'
GROUP BY table_schema;
                    </pre>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('auditSettingsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const data = {};
    formData.forEach((value, key) => data[key] = value);
    
    fetch('../api/audit_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_settings', settings: data })
    })
    .then(response => response.json())
    .then(data => {
        const msgDiv = document.getElementById('resultMessage');
        if (data.success) {
            msgDiv.innerHTML = '<div class="alert alert-success">Настройки сохранены</div>';
            setTimeout(() => location.reload(), 1500);
        } else {
            msgDiv.innerHTML = '<div class="alert alert-danger">Ошибка: ' + data.error + '</div>';
        }
    });
});

function clearAuditData() {
    if (confirm('Очистить все логи аудита? Это действие необратимо.')) {
        fetch('../api/audit_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'clear_logs' })
        })
        .then(response => response.json())
        .then(data => {
            const msgDiv = document.getElementById('resultMessage');
            if (data.success) {
                msgDiv.innerHTML = '<div class="alert alert-success">Логи очищены</div>';
            } else {
                msgDiv.innerHTML = '<div class="alert alert-danger">Ошибка: ' + data.error + '</div>';
            }
        });
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
