<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();
$pageTitle = "Аудит подключений";

// Фильтры
$filterUser = $_GET['user'] ?? '';
$filterStatus = $_GET['status'] ?? '';
$filterDate = $_GET['date'] ?? '';

$sql = "SELECT * FROM audit_db.connection_audit WHERE 1=1";
$params = [];

if ($filterUser) {
    $sql .= " AND username LIKE ?";
    $params[] = "%$filterUser%";
}
if ($filterStatus) {
    $sql .= " AND status = ?";
    $params[] = $filterStatus;
}
if ($filterDate) {
    $sql .= " AND DATE(connection_time) = ?";
    $params[] = $filterDate;
}

$sql .= " ORDER BY connection_time DESC LIMIT 500";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$connections = $stmt->fetchAll();

require_once '../includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-plug"></i> Аудит подключений</h1>
        <a href="audit.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <!-- Фильтры -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <input type="text" name="user" class="form-control" placeholder="Пользователь" value="<?php echo htmlspecialchars($filterUser); ?>">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-control">
                        <option value="">Все статусы</option>
                        <option value="SUCCESS" <?php echo $filterStatus == 'SUCCESS' ? 'selected' : ''; ?>>Успешные</option>
                        <option value="FAILED" <?php echo $filterStatus == 'FAILED' ? 'selected' : ''; ?>>Неудачные</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="date" name="date" class="form-control" value="<?php echo $filterDate; ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">Фильтровать</button>
                    <a href="audit_connections.php" class="btn btn-secondary">Сбросить</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Таблица подключений -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Время</th>
                            <th>Пользователь</th>
                            <th>Хост</th>
                            <th>Статус</th>
                            <th>Ошибка</th>
                            <th>Длительность</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($connections as $conn): ?>
                        <tr>
                            <td><?php echo $conn['connection_time']; ?></td>
                            <td><?php echo htmlspecialchars($conn['username']); ?></td>
                            <td><?php echo htmlspecialchars($conn['host']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $conn['status'] == 'SUCCESS' ? 'success' : 'danger'; ?>">
                                    <?php echo $conn['status']; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($conn['error_message'] ?? '-'); ?></td>
                            <td><?php echo $conn['duration_seconds'] ?: '-'; ?> сек</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($connections)): ?>
                        <tr>
                            <td colspan="6" class="text-center">Нет записей</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?> 
