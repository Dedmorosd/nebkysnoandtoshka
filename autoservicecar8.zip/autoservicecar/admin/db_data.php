<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$pageTitle = "Управление данными";
$tableName = $_GET['table'] ?? '';
$action = $_GET['action'] ?? 'list';
$editId = $_GET['id'] ?? 0;

// Получение списка таблиц
$tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

// Получение структуры таблицы
$columns = [];
$primaryKey = null;
if ($tableName) {
    $stmt = $pdo->query("DESCRIBE `$tableName`");
    $columns = $stmt->fetchAll();
    
    // Поиск первичного ключа
    foreach ($columns as $col) {
        if ($col['Key'] === 'PRI') {
            $primaryKey = $col['Field'];
            break;
        }
    }
}

// Получение данных таблицы
$rows = [];
if ($tableName) {
    $orderBy = $primaryKey ? "$primaryKey DESC" : "1";
    $stmt = $pdo->query("SELECT * FROM `$tableName` ORDER BY $orderBy LIMIT 500");
    $rows = $stmt->fetchAll();
}

// Вставка записи
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['insert'])) {
    $values = [];
    $placeholders = [];
    $fields = [];
    
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'col_') === 0) {
            $field = substr($key, 4);
            $fields[] = "`$field`";
            $placeholders[] = '?';
            $values[] = $value === '' ? null : $value;
        }
    }
    
    $sql = "INSERT INTO `$tableName` (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        $success = "Запись успешно добавлена";
        header("Location: db_data.php?table=$tableName");
        exit();
    } catch (PDOException $e) {
        $error = "Ошибка: " . $e->getMessage();
    }
}

// Обновление записи
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update']) && $primaryKey) {
    $set = [];
    $values = [];
    
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'col_') === 0) {
            $field = substr($key, 4);
            $set[] = "`$field` = ?";
            $values[] = $value === '' ? null : $value;
        }
    }
    
    $values[] = $_POST['record_id'];
    $sql = "UPDATE `$tableName` SET " . implode(', ', $set) . " WHERE `$primaryKey` = ?";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        $success = "Запись успешно обновлена";
        header("Location: db_data.php?table=$tableName");
        exit();
    } catch (PDOException $e) {
        $error = "Ошибка: " . $e->getMessage();
    }
}

// Удаление записи
if (isset($_GET['delete']) && $primaryKey) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM `$tableName` WHERE `$primaryKey` = ?");
        $stmt->execute([$id]);
        $success = "Запись удалена";
        header("Location: db_data.php?table=$tableName");
        exit();
    } catch (PDOException $e) {
        $error = "Ошибка: " . $e->getMessage();
    }
}

// Получение записи для редактирования
$editRow = null;
if ($action === 'edit' && $editId && $primaryKey) {
    $stmt = $pdo->prepare("SELECT * FROM `$tableName` WHERE `$primaryKey` = ?");
    $stmt->execute([$editId]);
    $editRow = $stmt->fetch();
}

require_once '../includes/header.php';
?>

<style>
    .data-table {
        font-size: 0.85em;
    }
    
    .data-table td, .data-table th {
        max-width: 200px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .form-container {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-edit"></i> Управление данными</h1>
        <a href="db_manager.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- Выбор таблицы -->
    <div class="form-container">
        <form method="GET" class="row g-3">
            <div class="col-md-8">
                <select name="table" class="form-control" required>
                    <option value="">Выберите таблицу</option>
                    <?php foreach ($tables as $table): ?>
                    <option value="<?php echo htmlspecialchars($table); ?>" <?php echo $tableName == $table ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($table); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary w-100">Выбрать</button>
            </div>
        </form>
    </div>
    
    <?php if ($tableName): ?>
    <!-- Форма добавления/редактирования -->
    <div class="form-container">
        <h4><i class="fas fa-<?php echo $action === 'edit' ? 'edit' : 'plus'; ?>"></i> 
            <?php echo $action === 'edit' ? 'Редактирование записи' : 'Добавление записи'; ?>
        </h4>
        
        <form method="POST">
            <?php if ($action === 'edit'): ?>
                <input type="hidden" name="record_id" value="<?php echo $editId; ?>">
                <input type="hidden" name="update" value="1">
            <?php else: ?>
                <input type="hidden" name="insert" value="1">
            <?php endif; ?>
            
            <?php foreach ($columns as $col): 
                $field = $col['Field'];
                $value = $editRow ? $editRow[$field] : '';
                $isAutoInc = strpos($col['Extra'], 'auto_increment') !== false;
                if ($isAutoInc && $action !== 'edit') continue;
            ?>
            <div class="mb-3">
                <label class="form-label"><?php echo htmlspecialchars($field); ?></label>
                <?php if (strpos($col['Type'], 'text') !== false): ?>
                    <textarea name="col_<?php echo $field; ?>" class="form-control" rows="3"><?php echo htmlspecialchars($value); ?></textarea>
                <?php elseif (strpos($col['Type'], 'date') !== false): ?>
                    <input type="date" name="col_<?php echo $field; ?>" class="form-control" value="<?php echo $value; ?>">
                <?php elseif (strpos($col['Type'], 'int') !== false): ?>
                    <input type="number" name="col_<?php echo $field; ?>" class="form-control" value="<?php echo $value; ?>">
                <?php else: ?>
                    <input type="text" name="col_<?php echo $field; ?>" class="form-control" value="<?php echo htmlspecialchars($value); ?>">
                <?php endif; ?>
                <?php if ($col['Null'] === 'YES'): ?>
                    <small class="text-muted">Может быть NULL</small>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> <?php echo $action === 'edit' ? 'Обновить' : 'Добавить'; ?>
            </button>
            <?php if ($action === 'edit'): ?>
                <a href="db_data.php?table=<?php echo urlencode($tableName); ?>" class="btn btn-secondary">Отмена</a>
            <?php endif; ?>
        </form>
    </div>
    
    <!-- Список записей -->
    <div class="form-container">
        <h4><i class="fas fa-list"></i> Записи таблицы "<?php echo htmlspecialchars($tableName); ?>"</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped data-table">
                <thead>
                    <tr>
                        <?php foreach ($columns as $col): ?>
                        <th><?php echo htmlspecialchars($col['Field']); ?></th>
                        <?php endforeach; ?>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                    <tr>
                        <?php foreach ($columns as $col): ?>
                        <td title="<?php echo htmlspecialchars($row[$col['Field']]); ?>">
                            <?php 
                            $val = $row[$col['Field']];
                            if ($val === null) echo '<em>NULL</em>';
                            else echo htmlspecialchars(mb_substr($val, 0, 50)) . (mb_strlen($val) > 50 ? '...' : '');
                            ?>
                        </td>
                        <?php endforeach; ?>
                        <td>
                            <?php if ($primaryKey): ?>
                            <a href="db_data.php?table=<?php echo urlencode($tableName); ?>&action=edit&id=<?php echo $row[$primaryKey]; ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="db_data.php?table=<?php echo urlencode($tableName); ?>&delete=<?php echo $row[$primaryKey]; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Удалить запись?')">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="<?php echo count($columns) + 1; ?>" class="text-center">Нет записей</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?> 
