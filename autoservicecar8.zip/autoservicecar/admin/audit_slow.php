<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();
$pageTitle = "Медленные запросы";

// Фильтры
$minTime = $_GET['min_time'] ?? 1;
$limit = (int)($_GET['limit'] ?? 100);

$sql = "SELECT * FROM audit_db.slow_query_audit 
        WHERE query_time >= ? 
        ORDER BY query_time DESC 
        LIMIT ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$minTime, $limit]);
$queries = $stmt->fetchAll();

require_once '../includes/header.php';
?>

<style>
    .query-card {
        background: white;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .query-time {
        font-size: 1.2em;
        font-weight: bold;
    }
    
    .query-text {
        background: #1e1e1e;
        color: #d4d4d4;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        overflow-x: auto;
        margin: 10px 0;
    }
    
    .query-meta {
        display: flex;
        gap: 20px;
        margin-top: 10px;
        font-size: 0.85em;
        color: #666;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-turtle"></i> Медленные запросы</h1>
        <a href="audit.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Минимальное время (сек)</label>
                    <input type="number" name="min_time" class="form-control" step="0.1" value="<?php echo $minTime; ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Количество записей</label>
                    <input type="number" name="limit" class="form-control" value="<?php echo $limit; ?>">
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">Применить</button>
                </div>
            </form>
        </div>
    </div>
    
    <?php foreach ($queries as $query): ?>
    <div class="query-card">
        <div class="d-flex justify-content-between">
            <div>
                <span class="badge bg-warning"><?php echo round($query['query_time'], 3); ?> сек</span>
                <span class="badge bg-info"><?php echo $query['rows_examined']; ?> rows examined</span>
            </div>
            <small><?php echo $query['created_at']; ?></small>
        </div>
        <div class="query-text"><?php echo htmlspecialchars($query['query_text']); ?></div>
        <div class="query-meta">
            <span>🔒 Lock time: <?php echo $query['lock_time']; ?> сек</span>
            <span>📤 Rows sent: <?php echo $query['rows_sent']; ?></span>
            <span>👤 User: <?php echo htmlspecialchars($query['user_host']); ?></span>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if (empty($queries)): ?>
    <div class="alert alert-info">Нет медленных запросов</div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?> 
