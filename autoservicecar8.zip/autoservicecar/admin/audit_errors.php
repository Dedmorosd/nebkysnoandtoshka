<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();
$pageTitle = "Журнал ошибок";

// Фильтры
$severity = $_GET['severity'] ?? '';
$code = $_GET['code'] ?? '';

$sql = "SELECT * FROM audit_db.error_audit WHERE 1=1";
$params = [];

if ($severity) {
    $sql .= " AND severity = ?";
    $params[] = $severity;
}
if ($code) {
    $sql .= " AND error_code = ?";
    $params[] = $code;
}

$sql .= " ORDER BY created_at DESC LIMIT 500";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$errors = $stmt->fetchAll();

require_once '../includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-exclamation-circle"></i> Журнал ошибок</h1>
        <a href="audit.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <select name="severity" class="form-control">
                        <option value="">Все уровни</option>
                        <option value="INFO" <?php echo $severity == 'INFO' ? 'selected' : ''; ?>>INFO</option>
                        <option value="WARNING" <?php echo $severity == 'WARNING' ? 'selected' : ''; ?>>WARNING</option>
                        <option value="ERROR" <?php echo $severity == 'ERROR' ? 'selected' : ''; ?>>ERROR</option>
                        <option value="CRITICAL" <?php echo $severity == 'CRITICAL' ? 'selected' : ''; ?>>CRITICAL</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="number" name="code" class="form-control" placeholder="Код ошибки" value="<?php echo $code; ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Фильтровать</button>
                    <a href="audit_errors.php" class="btn btn-secondary">Сбросить</a>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Время</th>
                            <th>Код</th>
                            <th>Сообщение</th>
                            <th>Пользователь</th>
                            <th>Важность</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($errors as $err): ?>
                        <tr>
                            <td><?php echo $err['created_at']; ?></td>
                            <td><?php echo $err['error_code']; ?></td>
                            <td><?php echo htmlspecialchars($err['error_message']); ?></td>
                            <td><?php echo htmlspecialchars($err['user_host'] ?? '-'); ?></td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo $err['severity'] == 'CRITICAL' ? 'danger' : 
                                        ($err['severity'] == 'ERROR' ? 'warning' : 
                                        ($err['severity'] == 'WARNING' ? 'info' : 'secondary')); 
                                ?>">
                                    <?php echo $err['severity']; ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($errors)): ?>
                        <tr>
                            <td colspan="5" class="text-center">Нет записей</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?> 
