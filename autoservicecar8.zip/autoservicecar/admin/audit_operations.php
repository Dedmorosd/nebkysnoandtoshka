<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();
$pageTitle = "Аудит операций с данными";

// Фильтры
$filterTable = $_GET['table'] ?? '';
$filterAction = $_GET['action'] ?? '';
$filterUser = $_GET['user'] ?? '';

$sql = "SELECT * FROM audit_db.data_audit WHERE 1=1";
$params = [];

if ($filterTable) {
    $sql .= " AND table_name = ?";
    $params[] = $filterTable;
}
if ($filterAction) {
    $sql .= " AND action = ?";
    $params[] = $filterAction;
}
if ($filterUser) {
    $sql .= " AND username LIKE ?";
    $params[] = "%$filterUser%";
}

$sql .= " ORDER BY created_at DESC LIMIT 500";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$operations = $stmt->fetchAll();

// Получение списка таблиц для фильтра
$tables = $pdo->query("SHOW TABLES FROM project_Karachkin")->fetchAll(PDO::FETCH_COLUMN);

require_once '../includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-database"></i> Аудит операций с данными</h1>
        <a href="audit.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <!-- Фильтры -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <select name="table" class="form-control">
                        <option value="">Все таблицы</option>
                        <?php foreach ($tables as $table): ?>
                        <option value="<?php echo $table; ?>" <?php echo $filterTable == $table ? 'selected' : ''; ?>>
                            <?php echo $table; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="action" class="form-control">
                        <option value="">Все действия</option>
                        <option value="INSERT" <?php echo $filterAction == 'INSERT' ? 'selected' : ''; ?>>INSERT</option>
                        <option value="UPDATE" <?php echo $filterAction == 'UPDATE' ? 'selected' : ''; ?>>UPDATE</option>
                        <option value="DELETE" <?php echo $filterAction == 'DELETE' ? 'selected' : ''; ?>>DELETE</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="user" class="form-control" placeholder="Пользователь" value="<?php echo htmlspecialchars($filterUser); ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">Фильтровать</button>
                    <a href="audit_operations.php" class="btn btn-secondary">Сбросить</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Таблица операций -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Время</th>
                            <th>Таблица</th>
                            <th>Действие</th>
                            <th>Пользователь</th>
                            <th>Старые данные</th>
                            <th>Новые данные</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($operations as $op): ?>
                        <tr>
                            <td><?php echo $op['created_at']; ?></td>
                            <td><?php echo htmlspecialchars($op['table_name']); ?></td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo $op['action'] == 'INSERT' ? 'success' : ($op['action'] == 'UPDATE' ? 'warning' : 'danger'); 
                                ?>">
                                    <?php echo $op['action']; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($op['username']); ?></td>
                            <td>
                                <?php if ($op['old_data']): ?>
                                <button class="btn btn-sm btn-info" onclick="showData('old', <?php echo $op['id']; ?>)">Показать</button>
                                <?php else: ?>-<?php endif; ?>
                            </td>
                            <td>
                                <?php if ($op['new_data']): ?>
                                <button class="btn btn-sm btn-info" onclick="showData('new', <?php echo $op['id']; ?>)">Показать</button>
                                <?php else: ?>-<?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($operations)): ?>
                        <tr>
                            <td colspan="6" class="text-center">Нет записей</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно для просмотра данных -->
<div id="dataModal" class="modal fade">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Данные операции</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <pre id="dataContent" style="background: #f8f9fa; padding: 15px; border-radius: 5px;"></pre>
            </div>
        </div>
    </div>
</div>

<script>
function showData(type, id) {
    fetch(`../api/audit_api.php?action=get_data&type=${type}&id=${id}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('dataContent').textContent = JSON.stringify(data.data, null, 2);
            new bootstrap.Modal(document.getElementById('dataModal')).show();
        });
}
</script>

<?php require_once '../includes/footer.php'; ?> 
