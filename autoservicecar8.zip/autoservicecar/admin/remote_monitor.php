<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$pageTitle = "Мониторинг сервера";

// Сбор метрик
$metrics = [];

// CPU
$cpuUsage = 0;
if (file_exists('/proc/stat')) {
    $stat = file_get_contents('/proc/stat');
    preg_match('/cpu\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/', $stat, $matches);
    $total = array_sum(array_slice($matches, 1));
    $idle = $matches[4];
    $cpuUsage = round((1 - $idle / $total) * 100, 1);
}
$metrics['cpu'] = $cpuUsage;

// Память
if (file_exists('/proc/meminfo')) {
    $memData = file_get_contents('/proc/meminfo');
    preg_match('/MemTotal:\s+(\d+)/', $memData, $total);
    preg_match('/MemAvailable:\s+(\d+)/', $memData, $available);
    $metrics['memory_total'] = round($total[1] / 1024 / 1024, 2);
    $metrics['memory_used'] = round(($total[1] - $available[1]) / 1024 / 1024, 2);
    $metrics['memory_percent'] = round((1 - $available[1] / $total[1]) * 100, 1);
}

// Диск
$diskFree = disk_free_space('/');
$diskTotal = disk_total_space('/');
$metrics['disk_total'] = round($diskTotal / 1024 / 1024 / 1024, 2);
$metrics['disk_used'] = round(($diskTotal - $diskFree) / 1024 / 1024 / 1024, 2);
$metrics['disk_percent'] = round((1 - $diskFree / $diskTotal) * 100, 1);

// Сеть
exec("ip -br link show | grep UP | wc -l", $interfaces);
$metrics['interfaces'] = (int)($interfaces[0] ?? 0);

// Процессы
exec("ps aux | wc -l", $processes);
$metrics['processes'] = (int)($processes[0] ?? 0);

// MySQL
try {
    $stmt = $pdo->query("SHOW STATUS LIKE 'Threads_connected'");
    $metrics['mysql_connections'] = $stmt->fetch()['Value'];
    $stmt = $pdo->query("SHOW STATUS LIKE 'Questions'");
    $metrics['mysql_queries'] = $stmt->fetch()['Value'];
} catch (Exception $e) {
    $metrics['mysql_connections'] = 'N/A';
    $metrics['mysql_queries'] = 'N/A';
}

// Apache
exec("systemctl is-active apache2 2>/dev/null", $apacheStatus);
$metrics['apache_status'] = ($apacheStatus[0] ?? '') === 'active' ? 'running' : 'stopped';

require_once '../includes/header.php';
?>

<style>
    .metric-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }
    
    .metric-value {
        font-size: 3em;
        font-weight: 700;
    }
    
    .metric-label {
        color: #666;
        margin-top: 10px;
    }
    
    .gauge {
        width: 150px;
        height: 150px;
        margin: 0 auto;
    }
    
    .progress-circle {
        width: 120px;
        height: 120px;
    }
</style>

<div class="container-fluid">
    <h1 class="mb-4"><i class="fas fa-chart-line"></i> Мониторинг сервера</h1>
    
    <div class="row">
        <div class="col-md-3">
            <div class="metric-card">
                <div class="metric-value" style="color: <?php echo $metrics['cpu'] > 80 ? '#e74c3c' : ($metrics['cpu'] > 50 ? '#f39c12' : '#27ae60'); ?>">
                    <?php echo $metrics['cpu']; ?>%
                </div>
                <div class="metric-label">Использование CPU</div>
                <div class="progress mt-2">
                    <div class="progress-bar" style="width: <?php echo $metrics['cpu']; ?>%"></div>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="metric-card">
                <div class="metric-value" style="color: <?php echo $metrics['memory_percent'] > 80 ? '#e74c3c' : ($metrics['memory_percent'] > 50 ? '#f39c12' : '#27ae60'); ?>">
                    <?php echo $metrics['memory_percent']; ?>%
                </div>
                <div class="metric-label">Использование памяти</div>
                <div class="progress mt-2">
                    <div class="progress-bar" style="width: <?php echo $metrics['memory_percent']; ?>%"></div>
                </div>
                <small><?php echo $metrics['memory_used']; ?> GB / <?php echo $metrics['memory_total']; ?> GB</small>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="metric-card">
                <div class="metric-value" style="color: <?php echo $metrics['disk_percent'] > 80 ? '#e74c3c' : ($metrics['disk_percent'] > 50 ? '#f39c12' : '#27ae60'); ?>">
                    <?php echo $metrics['disk_percent']; ?>%
                </div>
                <div class="metric-label">Использование диска</div>
                <div class="progress mt-2">
                    <div class="progress-bar" style="width: <?php echo $metrics['disk_percent']; ?>%"></div>
                </div>
                <small><?php echo $metrics['disk_used']; ?> GB / <?php echo $metrics['disk_total']; ?> GB</small>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="metric-card">
                <div class="metric-value"><?php echo $metrics['processes']; ?></div>
                <div class="metric-label">Активных процессов</div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-database"></i> MySQL статистика</h5>
                </div>
                <div class="card-body">
                    <div class="info-row">
                        <span>Подключений:</span>
                        <strong><?php echo $metrics['mysql_connections']; ?></strong>
                    </div>
                    <div class="info-row">
                        <span>Всего запросов:</span>
                        <strong><?php echo number_format($metrics['mysql_queries']); ?></strong>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-globe"></i> Apache статус</h5>
                </div>
                <div class="card-body">
                    <div class="info-row">
                        <span>Статус:</span>
                        <strong class="text-<?php echo $metrics['apache_status'] === 'running' ? 'success' : 'danger'; ?>">
                            <?php echo $metrics['apache_status'] === 'running' ? 'Работает' : 'Остановлен'; ?>
                        </strong>
                    </div>
                    <div class="info-row">
                        <span>Сетевых интерфейсов:</span>
                        <strong><?php echo $metrics['interfaces']; ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Автообновление каждые 30 секунд
setTimeout(() => location.reload(), 30000);
</script>

<?php require_once '../includes/footer.php'; ?> 
