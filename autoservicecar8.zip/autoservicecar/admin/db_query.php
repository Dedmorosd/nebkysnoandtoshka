<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$pageTitle = "SQL запросы";
$query = '';
$result = null;
$error = null;
$affectedRows = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $query = trim($_POST['query']);
    
    if (!empty($query)) {
        try {
            $startTime = microtime(true);
            
            // Определение типа запроса
            $queryType = strtoupper(substr(trim($query), 0, strpos(trim($query) . ' ', ' ')));
            
            if ($queryType === 'SELECT' || $queryType === 'SHOW' || $queryType === 'DESCRIBE') {
                $stmt = $pdo->query($query);
                $result = $stmt->fetchAll();
                $affectedRows = count($result);
            } else {
                $affectedRows = $pdo->exec($query);
                $result = true;
            }
            
            $executionTime = round((microtime(true) - $startTime) * 1000, 2);
            $success = "Запрос выполнен за {$executionTime} мс. Затронуто строк: {$affectedRows}";
            
        } catch (PDOException $e) {
            $error = $e->getMessage();
        }
    }
}

require_once '../includes/header.php';
?>

<style>
    .query-editor {
        background: #1e1e1e;
        color: #d4d4d4;
        font-family: 'Courier New', monospace;
        font-size: 14px;
        padding: 15px;
        border-radius: 8px;
        width: 100%;
        min-height: 200px;
        resize: vertical;
    }
    
    .result-table {
        font-size: 0.85em;
    }
    
    .result-table td, .result-table th {
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    
    .saved-queries {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .saved-query {
        background: #f8f9fa;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 8px;
        cursor: pointer;
        font-family: monospace;
        font-size: 12px;
        transition: all 0.3s;
    }
    
    .saved-query:hover {
        background: #e9ecef;
        transform: translateX(5px);
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-terminal"></i> SQL запросы</h1>
        <a href="db_manager.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Назад
        </a>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- Редактор запросов -->
    <div class="form-container">
        <h4><i class="fas fa-code"></i> Редактор SQL запросов</h4>
        <form method="POST">
            <textarea name="query" class="query-editor" placeholder="Введите SQL запрос..."><?php echo htmlspecialchars($query); ?></textarea>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-play"></i> Выполнить
                </button>
                <button type="button" class="btn btn-secondary" onclick="clearEditor()">
                    <i class="fas fa-eraser"></i> Очистить
                </button>
            </div>
        </form>
    </div>
    
    <!-- Сохраненные запросы -->
    <div class="saved-queries">
        <h5><i class="fas fa-bookmark"></i> Часто используемые запросы</h5>
        <div class="row">
            <div class="col-md-6">
                <div class="saved-query" onclick="setQuery('SELECT * FROM users LIMIT 10;')">
                    SELECT * FROM users LIMIT 10;
                </div>
                <div class="saved-query" onclick="setQuery('SELECT * FROM cars LIMIT 10;')">
                    SELECT * FROM cars LIMIT 10;
                </div>
                <div class="saved-query" onclick="setQuery('SELECT * FROM orders ORDER BY id DESC LIMIT 10;')">
                    SELECT * FROM orders ORDER BY id DESC LIMIT 10;
                </div>
            </div>
            <div class="col-md-6">
                <div class="saved-query" onclick="setQuery('SHOW TABLES;')">
                    SHOW TABLES;
                </div>
                <div class="saved-query" onclick="setQuery('DESCRIBE users;')">
                    DESCRIBE users;
                </div>
                <div class="saved-query" onclick="setQuery('SHOW PROCESSLIST;')">
                    SHOW PROCESSLIST;
                </div>
            </div>
        </div>
    </div>
    
    <!-- Результаты -->
    <?php if ($result && is_array($result) && !empty($result)): ?>
    <div class="form-container">
        <h4><i class="fas fa-table"></i> Результаты (<?php echo count($result); ?> строк)</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-striped result-table">
                <thead>
                    <tr>
                        <?php foreach (array_keys($result[0]) as $column): ?>
                        <th><?php echo htmlspecialchars($column); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($result as $row): ?>
                    <tr>
                        <?php foreach ($row as $value): ?>
                        <td title="<?php echo htmlspecialchars($value); ?>">
                            <?php echo htmlspecialchars(mb_substr($value, 0, 100)); ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php elseif ($result === true && $affectedRows > 0): ?>
    <div class="alert alert-info">
        <i class="fas fa-check-circle"></i> Запрос выполнен успешно. Затронуто строк: <?php echo $affectedRows; ?>
    </div>
    <?php endif; ?>
</div>

<script>
function setQuery(query) {
    document.querySelector('textarea[name="query"]').value = query;
}

function clearEditor() {
    document.querySelector('textarea[name="query"]').value = '';
}
</script>

<?php require_once '../includes/footer.php'; ?> 
