<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Аудит базы данных";

// Получение статистики аудита
$stats = [];
try {
    // Статистика за 24 часа
    $stmt = $pdo->query("
        SELECT 
            (SELECT COUNT(*) FROM audit_db.connection_audit WHERE connection_time >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as connections_24h,
            (SELECT COUNT(*) FROM audit_db.data_audit WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as operations_24h,
            (SELECT COUNT(*) FROM audit_db.data_audit WHERE action = 'INSERT' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as inserts_24h,
            (SELECT COUNT(*) FROM audit_db.data_audit WHERE action = 'UPDATE' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as updates_24h,
            (SELECT COUNT(*) FROM audit_db.data_audit WHERE action = 'DELETE' AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as deletes_24h,
            (SELECT COUNT(*) FROM audit_db.error_audit WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as errors_24h,
            (SELECT COUNT(*) FROM audit_db.slow_query_audit WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as slow_queries_24h,
            (SELECT ROUND(AVG(query_time), 2) FROM audit_db.slow_query_audit WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as avg_slow_time
    ");
    $stats = $stmt->fetch();
    
    // Общий размер аудита
    $stmt = $pdo->query("
        SELECT 
            ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
        FROM information_schema.tables
        WHERE table_schema = 'audit_db'
    ");
    $auditSize = $stmt->fetch()['size_mb'] ?? 0;
    
    // Подозрительная активность
    $suspicious = $pdo->query("
        SELECT 
            username,
            host,
            COUNT(*) as failed_attempts,
            MAX(connection_time) as last_attempt
        FROM audit_db.connection_audit
        WHERE status = 'FAILED' 
            AND connection_time >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        GROUP BY username, host
        HAVING failed_attempts > 5
        ORDER BY failed_attempts DESC
        LIMIT 10
    ")->fetchAll();
    
    // Последние операции
    $recentOperations = $pdo->query("
        SELECT * FROM audit_db.data_audit 
        ORDER BY created_at DESC 
        LIMIT 10
    ")->fetchAll();
    
} catch (PDOException $e) {
    $error = "Ошибка получения статистики: " . $e->getMessage();
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --audit-primary: #2c3e50;
        --audit-success: #27ae60;
        --audit-warning: #f39c12;
        --audit-danger: #e74c3c;
        --audit-info: #3498db;
    }
    
    .dashboard-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: transform 0.3s;
        border-left: 4px solid var(--audit-primary);
        cursor: pointer;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2.5em;
        font-weight: 700;
        color: var(--audit-primary);
    }
    
    .stat-label {
        color: #666;
        font-size: 0.85em;
        margin-top: 5px;
    }
    
    .cards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .info-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .info-card-header {
        background: linear-gradient(135deg, var(--audit-primary), #34495e);
        color: white;
        padding: 15px 20px;
        font-weight: 600;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .info-card-body {
        padding: 20px;
    }
    
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .info-row:last-child {
        border-bottom: none;
    }
    
    .alert-suspicious {
        background: #fff3cd;
        border-left: 4px solid var(--audit-warning);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    
    .alert-suspicious h5 {
        color: #856404;
        margin-bottom: 10px;
    }
    
    .recent-table {
        font-size: 0.9em;
    }
    
    .recent-table table {
        width: 100%;
    }
    
    .recent-table td {
        padding: 8px;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .badge-action {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 0.75em;
        font-weight: 600;
    }
    
    .badge-insert {
        background: rgba(39, 174, 96, 0.15);
        color: #27ae60;
    }
    
    .badge-update {
        background: rgba(243, 156, 18, 0.15);
        color: #f39c12;
    }
    
    .badge-delete {
        background: rgba(231, 76, 60, 0.15);
        color: #e74c3c;
    }
    
    .nav-menu {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }
    
    .nav-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        background: #ecf0f1;
        color: var(--audit-primary);
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
    }
    
    .nav-btn:hover {
        background: var(--audit-primary);
        color: white;
    }
    
    .btn-refresh {
        background: var(--audit-info);
        color: white;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-clipboard-list"></i> Аудит базы данных
        </h1>
        <div>
            <button class="btn btn-primary" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <!-- Навигация -->
    <div class="nav-menu">
        <a href="audit_connections.php" class="nav-btn">
            <i class="fas fa-plug"></i> Подключения
        </a>
        <a href="audit_operations.php" class="nav-btn">
            <i class="fas fa-database"></i> Операции с данными
        </a>
        <a href="audit_slow.php" class="nav-btn">
            <i class="fas fa-turtle"></i> Медленные запросы
        </a>
        <a href="audit_errors.php" class="nav-btn">
            <i class="fas fa-exclamation-circle"></i> Журнал ошибок
        </a>
        <a href="audit_settings.php" class="nav-btn">
            <i class="fas fa-cog"></i> Настройки аудита
        </a>
    </div>
    
    <!-- Статистика -->
    <div class="dashboard-stats">
        <div class="stat-card" onclick="window.location.href='audit_connections.php'">
            <div class="stat-value"><?php echo number_format($stats['connections_24h'] ?? 0); ?></div>
            <div class="stat-label">Подключений за 24ч</div>
        </div>
        <div class="stat-card" onclick="window.location.href='audit_operations.php'">
            <div class="stat-value"><?php echo number_format($stats['operations_24h'] ?? 0); ?></div>
            <div class="stat-label">Операций с данными</div>
        </div>
        <div class="stat-card" onclick="window.location.href='audit_slow.php'">
            <div class="stat-value"><?php echo number_format($stats['slow_queries_24h'] ?? 0); ?></div>
            <div class="stat-label">Медленных запросов</div>
        </div>
        <div class="stat-card" onclick="window.location.href='audit_errors.php'">
            <div class="stat-value"><?php echo number_format($stats['errors_24h'] ?? 0); ?></div>
            <div class="stat-label">Ошибок</div>
        </div>
    </div>
    
    <!-- Размер аудита -->
    <div class="info-card mb-4">
        <div class="info-card-header">
            <span><i class="fas fa-database"></i> Информация об аудите</span>
            <span><?php echo round($auditSize, 2); ?> MB</span>
        </div>
        <div class="info-card-body">
            <div class="info-row">
                <span>INSERT операции:</span>
                <span><?php echo number_format($stats['inserts_24h'] ?? 0); ?></span>
            </div>
            <div class="info-row">
                <span>UPDATE операции:</span>
                <span><?php echo number_format($stats['updates_24h'] ?? 0); ?></span>
            </div>
            <div class="info-row">
                <span>DELETE операции:</span>
                <span><?php echo number_format($stats['deletes_24h'] ?? 0); ?></span>
            </div>
            <div class="info-row">
                <span>Среднее время медленных запросов:</span>
                <span><?php echo $stats['avg_slow_time'] ?? 0; ?> сек</span>
            </div>
        </div>
    </div>
    
    <!-- Подозрительная активность -->
    <?php if (!empty($suspicious)): ?>
    <div class="alert-suspicious">
        <h5><i class="fas fa-exclamation-triangle"></i> Подозрительная активность</h5>
        <ul class="mb-0">
            <?php foreach ($suspicious as $s): ?>
            <li>
                Пользователь <strong><?php echo htmlspecialchars($s['username']); ?></strong> с хоста 
                <strong><?php echo htmlspecialchars($s['host']); ?></strong> совершил 
                <strong><?php echo $s['failed_attempts']; ?></strong> неудачных попыток входа.
                Последняя попытка: <?php echo $s['last_attempt']; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <!-- Последние операции -->
    <div class="info-card">
        <div class="info-card-header">
            <span><i class="fas fa-history"></i> Последние операции</span>
            <a href="audit_operations.php" class="btn btn-sm btn-light">Все операции →</a>
        </div>
        <div class="info-card-body">
            <div class="recent-table">
                <table>
                    <thead>
                        <tr>
                            <th>Время</th>
                            <th>Таблица</th>
                            <th>Действие</th>
                            <th>Пользователь</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentOperations as $op): ?>
                        <tr>
                            <td><?php echo date('d.m.Y H:i:s', strtotime($op['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($op['table_name']); ?></td>
                            <td>
                                <span class="badge-action badge-<?php echo strtolower($op['action']); ?>">
                                    <?php echo $op['action']; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($op['username']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($recentOperations)): ?>
                        <tr>
                            <td colspan="4" class="text-center">Нет записей</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?> 
