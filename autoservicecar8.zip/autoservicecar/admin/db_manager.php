<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'clear_table':
                $table = $input['table'] ?? '';
                $response = clearTable($pdo, $table);
                break;
                
            case 'delete_table':
                $table = $input['table'] ?? '';
                $response = deleteTable($pdo, $table);
                break;
                
            case 'backup':
                $type = $input['type'] ?? 'full';
                $compression = $input['compression'] ?? 'gzip';
                $response = createBackup($pdo, $type, $compression);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'get_table_data':
                $table = $_GET['table'] ?? '';
                $response = getTableData($pdo, $table);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

function clearTable($pdo, $table)
{
    if (empty($table)) {
        return ['error' => 'Имя таблицы не указано'];
    }
    
    $pdo->exec("TRUNCATE TABLE `$table`");
    return ['success' => true];
}

function deleteTable($pdo, $table)
{
    if (empty($table)) {
        return ['error' => 'Имя таблицы не указано'];
    }
    
    $pdo->exec("DROP TABLE IF EXISTS `$table`");
    return ['success' => true];
}

function getTableData($pdo, $table)
{
    if (empty($table)) {
        return ['error' => 'Имя таблицы не указано'];
    }
    
    $stmt = $pdo->query("DESCRIBE `$table`");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $stmt = $pdo->query("SELECT * FROM `$table` LIMIT 500");
    $rows = $stmt->fetchAll();
    
    return ['success' => true, 'columns' => $columns, 'rows' => $rows];
}

function createBackup($pdo, $type, $compression)
{
    $backupDir = __DIR__ . '/../backups/';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    
    $date = date('Y-m-d_H-i-s');
    $filename = "backup_{$date}.sql";
    
    $dumpOptions = '--single-transaction --routines --triggers --events';
    
    if ($type === 'structure') {
        $dumpOptions .= ' --no-data';
    } elseif ($type === 'data') {
        $dumpOptions .= ' --no-create-info';
    }
    
    $command = sprintf(
        'mysqldump -u%s -p%s %s %s > %s 2>&1',
        escapeshellarg($GLOBALS['db_user'] ?? 'Karachkin'),
        escapeshellarg($GLOBALS['db_password'] ?? '*iNPsB2D[4NO!Hfx'),
        $dumpOptions,
        'project_Karachkin',
        escapeshellarg($backupDir . $filename)
    );
    
    exec($command, $output, $returnCode);
    
    if ($returnCode !== 0) {
        return ['error' => 'Ошибка создания бэкапа'];
    }
    
    if ($compression === 'gzip') {
        $gzFile = $backupDir . $filename . '.gz';
        $content = file_get_contents($backupDir . $filename);
        file_put_contents($gzFile, gzencode($content));
        unlink($backupDir . $filename);
        $filename .= '.gz';
    }
    
    return ['success' => true, 'filename' => $filename];
}
?>