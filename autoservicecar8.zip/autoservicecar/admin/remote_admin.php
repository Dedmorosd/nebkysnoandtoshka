<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Удаленное администрирование";

// Получение информации о системе
$systemInfo = [];

// Информация о сервере
$systemInfo['hostname'] = gethostname();
$systemInfo['ip'] = $_SERVER['SERVER_ADDR'];
$systemInfo['os'] = php_uname();
$systemInfo['php_version'] = phpversion();
$systemInfo['server_software'] = $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown';

// Информация о дисках
$diskFree = disk_free_space('/');
$diskTotal = disk_total_space('/');
if ($diskFree !== false && $diskTotal !== false) {
    $systemInfo['disk_free'] = round($diskFree / 1024 / 1024 / 1024, 2);
    $systemInfo['disk_total'] = round($diskTotal / 1024 / 1024 / 1024, 2);
    $systemInfo['disk_used_percent'] = round((1 - $diskFree / $diskTotal) * 100, 2);
}

// Информация о памяти (Linux)
if (file_exists('/proc/meminfo')) {
    $memData = file_get_contents('/proc/meminfo');
    preg_match('/MemTotal:\s+(\d+)/', $memData, $total);
    preg_match('/MemAvailable:\s+(\d+)/', $memData, $available);
    $systemInfo['mem_total'] = round($total[1] / 1024 / 1024, 2);
    $systemInfo['mem_available'] = round($available[1] / 1024 / 1024, 2);
    $systemInfo['mem_used_percent'] = round((1 - $available[1] / $total[1]) * 100, 2);
}

// Информация о загрузке CPU
if (file_exists('/proc/loadavg')) {
    $loadData = file_get_contents('/proc/loadavg');
    $load = explode(' ', $loadData);
    $systemInfo['load_1min'] = $load[0];
    $systemInfo['load_5min'] = $load[1];
    $systemInfo['load_15min'] = $load[2];
}

// Информация о MySQL
try {
    $stmt = $pdo->query("SHOW STATUS LIKE 'Threads_connected'");
    $systemInfo['mysql_connections'] = $stmt->fetch()['Value'];
    $stmt = $pdo->query("SHOW STATUS LIKE 'Uptime'");
    $uptime = $stmt->fetch()['Value'];
    $systemInfo['mysql_uptime_days'] = floor($uptime / 86400);
    $systemInfo['mysql_uptime_hours'] = floor(($uptime % 86400) / 3600);
} catch (Exception $e) {
    $systemInfo['mysql_connections'] = 'N/A';
    $systemInfo['mysql_uptime_days'] = 0;
    $systemInfo['mysql_uptime_hours'] = 0;
}

// Получение активных SSH сессий
$sshSessions = [];
exec("who | grep -E '\([0-9\.]+\)' 2>/dev/null", $sshSessions);

// Получение последних логов
$logs = [];
if (file_exists('../logs/admin_actions.log')) {
    $logLines = file('../logs/admin_actions.log');
    $logs = array_slice($logLines, -30);
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --remote-primary: #1a237e;
        --remote-secondary: #0d47a1;
        --remote-success: #1b5e20;
        --remote-warning: #e65100;
        --remote-danger: #b71c1c;
        --remote-info: #01579b;
    }
    
    .dashboard-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: transform 0.3s;
        border-left: 4px solid var(--remote-primary);
        cursor: pointer;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2em;
        font-weight: 700;
        color: var(--remote-primary);
    }
    
    .stat-label {
        color: #666;
        font-size: 0.85em;
        margin-top: 5px;
    }
    
    .progress-container {
        height: 8px;
        background: #e0e0e0;
        border-radius: 4px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--remote-success), var(--remote-primary));
        width: 0%;
        border-radius: 4px;
        transition: width 0.3s;
    }
    
    .cards-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .info-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .info-card-header {
        background: linear-gradient(135deg, var(--remote-primary), var(--remote-secondary));
        color: white;
        padding: 15px 20px;
        font-weight: 600;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .info-card-body {
        padding: 20px;
    }
    
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .info-row:last-child {
        border-bottom: none;
    }
    
    .action-buttons {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-top: 15px;
    }
    
    .btn-remote {
        padding: 8px 15px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 0.9em;
        transition: all 0.3s;
        background: var(--remote-primary);
        color: white;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
    }
    
    .btn-remote:hover {
        transform: translateY(-2px);
        opacity: 0.9;
    }
    
    .btn-success { background: var(--remote-success); }
    .btn-warning { background: var(--remote-warning); }
    .btn-danger { background: var(--remote-danger); }
    .btn-info { background: var(--remote-info); }
    
    .log-container {
        background: #1e1e1e;
        color: #0f0;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        max-height: 300px;
        overflow-y: auto;
    }
    
    .log-line {
        padding: 3px 0;
        border-bottom: 1px solid #333;
        font-family: monospace;
        font-size: 11px;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 700px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        background: var(--remote-primary);
        color: white;
        border-radius: 15px 15px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #e0e0e0;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: white;
    }
    
    .form-group {
        margin-bottom: 15px;
    }
    
    .form-label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    
    .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-family: monospace;
    }
    
    .command-output {
        background: #1e1e1e;
        color: #0f0;
        padding: 15px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        max-height: 300px;
        overflow-y: auto;
        margin-top: 15px;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
        border-left: 4px solid var(--remote-success);
    }
    
    .toast.error {
        border-left-color: var(--remote-danger);
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75em;
        font-weight: 600;
    }
    
    .status-online {
        background: rgba(27, 94, 32, 0.15);
        color: #1b5e20;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-globe"></i> Удаленное администрирование
        </h1>
        <div>
            <button class="btn btn-primary" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="dashboard-stats">
        <div class="stat-card" onclick="showSystemInfo()">
            <div class="stat-value"><?php echo $systemInfo['hostname']; ?></div>
            <div class="stat-label">Имя сервера</div>
        </div>
        <div class="stat-card" onclick="showDiskInfo()">
            <div class="stat-value"><?php echo $systemInfo['disk_used_percent']; ?>%</div>
            <div class="stat-label">Использование диска</div>
            <div class="progress-container">
                <div class="progress-fill" style="width: <?php echo $systemInfo['disk_used_percent']; ?>%"></div>
            </div>
        </div>
        <div class="stat-card" onclick="showMemoryInfo()">
            <div class="stat-value"><?php echo $systemInfo['mem_used_percent'] ?? 0; ?>%</div>
            <div class="stat-label">Использование памяти</div>
            <div class="progress-container">
                <div class="progress-fill" style="width: <?php echo $systemInfo['mem_used_percent'] ?? 0; ?>%"></div>
            </div>
        </div>
        <div class="stat-card" onclick="showLoadInfo()">
            <div class="stat-value"><?php echo $systemInfo['load_1min'] ?? '0'; ?></div>
            <div class="stat-label">Load Average (1 мин)</div>
        </div>
    </div>
    
    <!-- Карточки управления -->
    <div class="cards-grid">
        <!-- Системная информация -->
        <div class="info-card">
            <div class="info-card-header">
                <span><i class="fas fa-server"></i> Системная информация</span>
                <span class="status-badge status-online">
                    <i class="fas fa-circle" style="font-size: 8px;"></i> Онлайн
                </span>
            </div>
            <div class="info-card-body">
                <div class="info-row">
                    <span>ОС:</span>
                    <span><?php echo $systemInfo['os']; ?></span>
                </div>
                <div class="info-row">
                    <span>IP адрес:</span>
                    <span><?php echo $systemInfo['ip']; ?></span>
                </div>
                <div class="info-row">
                    <span>PHP версия:</span>
                    <span><?php echo $systemInfo['php_version']; ?></span>
                </div>
                <div class="info-row">
                    <span>Web-сервер:</span>
                    <span><?php echo $systemInfo['server_software']; ?></span>
                </div>
                <div class="info-row">
                    <span>MySQL:</span>
                    <span>Время работы: <?php echo $systemInfo['mysql_uptime_days']; ?> дн, <?php echo $systemInfo['mysql_uptime_hours']; ?> ч</span>
                </div>
            </div>
        </div>
        
        <!-- Управление сервером -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-cog"></i> Управление сервером
            </div>
            <div class="info-card-body">
                <div class="action-buttons">
                    <button class="btn-remote btn-info" onclick="showCommandModal()">
                        <i class="fas fa-terminal"></i> Выполнить команду
                    </button>
                    <button class="btn-remote" onclick="restartService('php')">
                        <i class="fab fa-php"></i> PHP-FPM
                    </button>
                    <button class="btn-remote" onclick="restartService('mysql')">
                        <i class="fas fa-database"></i> MySQL
                    </button>
                    <button class="btn-remote" onclick="restartService('apache')">
                        <i class="fas fa-globe"></i> Apache
                    </button>
                </div>
                <div class="action-buttons">
                    <a href="remote_ssh.php" class="btn-remote">
                        <i class="fas fa-key"></i> SSH ключи
                    </a>
                    <a href="remote_monitor.php" class="btn-remote btn-success">
                        <i class="fas fa-chart-line"></i> Мониторинг
                    </a>
                    <a href="remote_logs.php" class="btn-remote btn-warning">
                        <i class="fas fa-history"></i> Логи сервера
                    </a>
                    <button class="btn-remote btn-danger" onclick="rebootServer()">
                        <i class="fas fa-power-off"></i> Перезагрузка
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Активные сессии -->
        <div class="info-card">
            <div class="info-card-header">
                <i class="fas fa-users"></i> Активные SSH сессии
            </div>
            <div class="info-card-body">
                <?php if (!empty($sshSessions)): ?>
                    <?php foreach ($sshSessions as $session): ?>
                        <div class="info-row">
                            <span><?php echo htmlspecialchars($session); ?></span>
                            <button class="btn-remote btn-danger btn-sm" onclick="killSession('<?php echo addslashes($session); ?>')" style="padding: 4px 8px; font-size: 11px;">
                                <i class="fas fa-times"></i> Завершить
                            </button>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="info-row">
                        <span>Нет активных SSH сессий</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Лог действий -->
    <div class="info-card">
        <div class="info-card-header">
            <i class="fas fa-history"></i> Журнал действий
        </div>
        <div class="info-card-body">
            <div class="log-container">
                <?php foreach ($logs as $log): ?>
                    <div class="log-line"><?php echo htmlspecialchars($log); ?></div>
                <?php endforeach; ?>
                <?php if (empty($logs)): ?>
                    <div class="log-line">Нет записей в журнале</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Модальное окно выполнения команды -->
<div id="commandModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-terminal"></i> Выполнение команды</h5>
            <span class="close" onclick="closeModal('commandModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Команда</label>
                <input type="text" class="form-control" id="commandInput" 
                       placeholder="например: df -h">
            </div>
            <div id="commandOutput" class="command-output" style="display: none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal('commandModal')">Отмена</button>
            <button class="btn btn-primary" onclick="executeCommand()">Выполнить</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
// Выполнение команды
function executeCommand() {
    const command = document.getElementById('commandInput').value;
    if (!command) {
        showToast('Введите команду', 'error');
        return;
    }
    
    const outputDiv = document.getElementById('commandOutput');
    outputDiv.style.display = 'block';
    outputDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Выполнение...';
    
    fetch('../api/remote_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'execute', command: command })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            outputDiv.innerHTML = data.output;
            showToast('Команда выполнена', 'success');
        } else {
            outputDiv.innerHTML = `<span style="color: #e74c3c;">Ошибка: ${data.error}</span>`;
            showToast('Ошибка выполнения', 'error');
        }
    });
}

// Перезапуск сервиса
function restartService(service) {
    const serviceNames = {
        'php': 'PHP-FPM',
        'mysql': 'MySQL',
        'apache': 'Apache'
    };
    
    if (confirm(`Перезапустить ${serviceNames[service]}? Это может временно прервать работу.`)) {
        showToast(`Перезапуск ${serviceNames[service]}...`, 'info');
        
        fetch('../api/remote_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'restart', service: service })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`${serviceNames[service]} перезапущен успешно`, 'success');
            } else {
                showToast(`Ошибка: ${data.error}`, 'error');
            }
        });
    }
}

// Завершение SSH сессии
function killSession(session) {
    if (confirm(`Завершить сессию: ${session}?`)) {
        // Извлечение PID из строки сессии
        const parts = session.trim().split(/\s+/);
        const pid = parts[1];
        
        fetch('../api/remote_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'kill_session', pid: pid })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Сессия завершена', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast(`Ошибка: ${data.error}`, 'error');
            }
        });
    }
}

// Перезагрузка сервера
function rebootServer() {
    if (confirm('ВНИМАНИЕ! Перезагрузка сервера. Все несохраненные данные будут потеряны. Продолжить?')) {
        showToast('Перезагрузка сервера...', 'warning');
        
        fetch('../api/remote_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'reboot' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Сервер перезагружается...', 'warning');
                setTimeout(() => { window.location.href = '/'; }, 5000);
            } else {
                showToast(`Ошибка: ${data.error}`, 'error');
            }
        });
    }
}

// Информационные модальные окна
function showSystemInfo() {
    showToast(`Хост: ${'<?php echo $systemInfo['hostname']; ?>'}, IP: ${'<?php echo $systemInfo['ip']; ?>'}`, 'info');
}

function showDiskInfo() {
    showToast(`Диск: ${'<?php echo $systemInfo['disk_free']; ?>'} GB свободно из ${'<?php echo $systemInfo['disk_total']; ?>'} GB`, 'info');
}

function showMemoryInfo() {
    showToast(`Память: ${'<?php echo $systemInfo['mem_available']; ?>'} GB доступно из ${'<?php echo $systemInfo['mem_total']; ?>'} GB`, 'info');
}

function showLoadInfo() {
    showToast(`Load Average: 1мин: ${'<?php echo $systemInfo['load_1min']; ?>'}, 5мин: ${'<?php echo $systemInfo['load_5min']; ?>'}, 15мин: ${'<?php echo $systemInfo['load_15min']; ?>'}`, 'info');
}

function showCommandModal() {
    document.getElementById('commandModal').style.display = 'flex';
    document.getElementById('commandInput').value = '';
    document.getElementById('commandOutput').style.display = 'none';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type === 'error' ? 'error' : ''}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}
</script>

<?php require_once '../includes/footer.php'; ?> 
