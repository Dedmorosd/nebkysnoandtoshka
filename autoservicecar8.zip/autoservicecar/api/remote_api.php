<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

function logAction($action, $details = '')
{
    $logFile = __DIR__ . '/../logs/admin_actions.log';
    if (!is_dir(dirname($logFile))) {
        mkdir(dirname($logFile), 0777, true);
    }
    
    $logEntry = sprintf(
        "[%s] %s (%s) - %s%s\n",
        date('Y-m-d H:i:s'),
        $_SESSION['username'] ?? 'unknown',
        $_SERVER['REMOTE_ADDR'],
        $action,
        $details ? " - $details" : ''
    );
    
    file_put_contents($logFile, $logEntry, FILE_APPEND);
}

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'execute':
                $command = $input['command'] ?? '';
                $response = executeCommand($command);
                break;
                
            case 'restart':
                $service = $input['service'] ?? '';
                $response = restartService($service);
                break;
                
            case 'reboot':
                $response = rebootServer();
                break;
                
            case 'kill_session':
                $pid = $input['pid'] ?? 0;
                $response = killSession($pid);
                break;
                
            case 'add_ssh_key':
                $key = $input['key'] ?? '';
                $comment = $input['comment'] ?? '';
                $response = addSSHKey($key, $comment);
                break;
                
            case 'delete_ssh_key':
                $index = $input['index'] ?? 0;
                $response = deleteSSHKey($index);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

function executeCommand($command)
{
    $allowedCommands = [
        'df -h', 'free -h', 'uptime', 'who', 'w',
        'systemctl status mysql', 'systemctl status apache2',
        'systemctl status php.*-fpm', 'top -b -n 1'
    ];
    
    $allowed = false;
    foreach ($allowedCommands as $allowedCmd) {
        if (strpos($command, $allowedCmd) === 0) {
            $allowed = true;
            break;
        }
    }
    
    if (!$allowed) {
        logAction("BLOCKED_COMMAND", $command);
        return ['error' => 'Команда не разрешена'];
    }
    
    $output = [];
    $returnCode = 0;
    exec($command . ' 2>&1', $output, $returnCode);
    
    logAction("EXECUTE_COMMAND", $command);
    
    return [
        'success' => $returnCode === 0,
        'output' => implode("\n", $output)
    ];
}

function restartService($service)
{
    $services = [
        'php' => ['php7.4-fpm', 'php8.1-fpm', 'php-fpm'],
        'mysql' => ['mysql', 'mysqld'],
        'apache' => ['apache2', 'httpd']
    ];
    
    if (!isset($services[$service])) {
        return ['error' => 'Неизвестная служба'];
    }
    
    foreach ($services[$service] as $svc) {
        exec("systemctl restart $svc 2>&1", $output, $code);
        if ($code === 0) {
            logAction("RESTART_SERVICE", $svc);
            return ['success' => true, 'message' => "Служба $service перезапущена"];
        }
    }
    
    return ['error' => "Не удалось перезапустить службу $service"];
}

function rebootServer()
{
    logAction("REBOOT_SERVER");
    exec("sudo shutdown -r +1 'Сервер будет перезагружен через 1 минуту' > /dev/null 2>&1 &");
    return ['success' => true, 'message' => 'Сервер будет перезагружен через 1 минуту'];
}

function killSession($pid)
{
    if (!$pid) {
        return ['error' => 'PID не указан'];
    }
    
    exec("kill -9 $pid 2>&1", $output, $code);
    
    if ($code === 0) {
        logAction("KILL_SESSION", "PID: $pid");
        return ['success' => true];
    }
    
    return ['error' => 'Не удалось завершить процесс'];
}

function addSSHKey($key, $comment)
{
    if (empty($key)) {
        return ['error' => 'Ключ не может быть пустым'];
    }
    
    $authorizedKeysFile = '/home/admin/.ssh/authorized_keys';
    $keyLine = $key . ($comment ? " $comment" : '');
    
    file_put_contents($authorizedKeysFile, $keyLine . "\n", FILE_APPEND);
    logAction("ADD_SSH_KEY", $comment ?: 'без комментария');
    
    return ['success' => true];
}

function deleteSSHKey($index)
{
    $authorizedKeysFile = '/home/admin/.ssh/authorized_keys';
    $content = file_get_contents($authorizedKeysFile);
    $lines = explode("\n", $content);
    
    $keyIndex = 0;
    $newLines = [];
    foreach ($lines as $line) {
        if (trim($line) && strpos($line, 'ssh-rsa') !== false) {
            if ($keyIndex != $index) {
                $newLines[] = $line;
            }
            $keyIndex++;
        } else {
            $newLines[] = $line;
        }
    }
    
    file_put_contents($authorizedKeysFile, implode("\n", $newLines));
    logAction("DELETE_SSH_KEY", "Index: $index");
    
    return ['success' => true];
}
?>