<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'update_settings':
                $settings = $input['settings'] ?? [];
                $response = updateAuditSettings($pdo, $settings);
                break;
                
            case 'clear_logs':
                $response = clearAuditLogs($pdo);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'get_data':
                $type = $_GET['type'] ?? '';
                $id = (int)($_GET['id'] ?? 0);
                $response = getAuditData($pdo, $type, $id);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

function updateAuditSettings($pdo, $settings)
{
    foreach ($settings as $key => $value) {
        try {
            $pdo->exec("SET GLOBAL $key = '$value'");
        } catch (PDOException $e) {
            // Пропускаем ошибки, если переменная не может быть установлена динамически
        }
    }
    
    return ['success' => true];
}

function clearAuditLogs($pdo)
{
    $pdo->exec("TRUNCATE TABLE audit_db.connection_audit");
    $pdo->exec("TRUNCATE TABLE audit_db.data_audit");
    $pdo->exec("TRUNCATE TABLE audit_db.slow_query_audit");
    $pdo->exec("TRUNCATE TABLE audit_db.error_audit");
    
    // Ротация логов MySQL
    $pdo->exec("SET GLOBAL general_log = OFF");
    $pdo->exec("SET GLOBAL general_log = ON");
    $pdo->exec("FLUSH LOGS");
    
    return ['success' => true];
}

function getAuditData($pdo, $type, $id)
{
    $table = $type == 'old' || $type == 'new' ? 'data_audit' : null;
    $column = $type == 'old' ? 'old_data' : ($type == 'new' ? 'new_data' : null);
    
    if (!$table || !$column) {
        return ['error' => 'Неверный тип данных'];
    }
    
    $stmt = $pdo->prepare("SELECT $column FROM audit_db.$table WHERE id = ?");
    $stmt->execute([$id]);
    $data = $stmt->fetch();
    
    return ['success' => true, 'data' => json_decode($data[$column] ?? '{}', true)];
}
?> 
