<?php
// config/config.php - Упрощенная версия без Dotenv и Monolog

// Конфигурация
$config = [
    'app_url' => 'http://localhost:3000',
    
    'webdriver' => [
        'host' => 'http://localhost:9515',
        'browser' => 'chrome',
        'headless' => false,
        'window_size' => [
            'width' => 1920,
            'height' => 1080
        ]
    ],
    
    'timeouts' => [
        'implicit' => 10,
        'explicit' => 15,
        'page_load' => 30,
        'script' => 10
    ],
    
    'test_users' => [
        'admin' => [
            'username' => 'admin',
            'password' => 'admin123',
            'role' => 'admin'
        ],
        'client' => [
            'username' => 'client',
            'password' => 'client123',
            'role' => 'client'
        ],
        'mechanic' => [
            'username' => 'mechanic',
            'password' => 'mechanic123',
            'role' => 'mechanic'
        ]
    ],
    
    'paths' => [
        'screenshots' => __DIR__ . '/../screenshots/',
        'reports' => __DIR__ . '/../reports/',
        'logs' => __DIR__ . '/../logs/'
    ],
    
    'screenshot_on_failure' => true,
    'retry_on_failure' => 3
];

// Простой логгер вместо Monolog
class SimpleLogger
{
    private $logFile;
    
    public function __construct($logFile)
    {
        $this->logFile = $logFile;
        if (!is_dir(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
    }
    
    public function info($message, $context = [])
    {
        $this->write('INFO', $message, $context);
    }
    
    public function debug($message, $context = [])
    {
        $this->write('DEBUG', $message, $context);
    }
    
    public function error($message, $context = [])
    {
        $this->write('ERROR', $message, $context);
    }
    
    public function warning($message, $context = [])
    {
        $this->write('WARNING', $message, $context);
    }
    
    private function write($level, $message, $context)
    {
        $logEntry = sprintf(
            "[%s] [%s] %s %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            !empty($context) ? json_encode($context) : ''
        );
        
        file_put_contents($this->logFile, $logEntry, FILE_APPEND);
    }
}

$logFile = $config['paths']['logs'] . 'test_' . date('Y-m-d') . '.log';
$config['logger'] = new SimpleLogger($logFile);

return $config;