#!/usr/bin/env php
<?php
// Удалите все пробелы перед этой строкой!

echo "\n";
echo "═══════════════════════════════════════════════════════════\n";
echo "     АВТОМАТИЗАЦИЯ ТЕСТИРОВАНИЯ ВЕБ-ПРИЛОЖЕНИЯ\n";
echo "                 Selenium WebDriver\n";
echo "═══════════════════════════════════════════════════════════\n\n";

$config = require __DIR__ . '/config/config.php';
$logger = $config['logger'];

echo "📋 Конфигурация:\n";
echo "   • URL: {$config['app_url']}\n";
echo "   • Браузер: {$config['webdriver']['browser']}\n";
echo "   • Headless: " . ($config['webdriver']['headless'] ? 'Да' : 'Нет') . "\n";
echo "   • Таймаут: {$config['timeouts']['explicit']} сек\n\n";

// Проверка ChromeDriver (используем file_get_contents вместо curl)
echo "🔍 Проверка ChromeDriver... ";
$context = stream_context_create(['http' => ['timeout' => 2]]);
$response = @file_get_contents($config['webdriver']['host'] . '/status', false, $context);

if ($response !== false) {
    echo "✅ Запущен\n\n";
} else {
    echo "❌ Не запущен!\n\n";
    echo "Пожалуйста, запустите ChromeDriver:\n";
    echo "   chromedriver --port=9515\n\n";
    exit(1);
}

// Проверка сайта
echo "🔍 Проверка сайта... ";
$response = @file_get_contents($config['app_url'] . '/login.php', false, $context);
$httpCode = $http_response_header[0] ?? '';

if ($response !== false && strpos($httpCode, '200') !== false) {
    echo "✅ Доступен\n\n";
} else {
    echo "❌ Недоступен\n\n";
    exit(1);
}

// Создание директорий
foreach (['screenshots', 'reports', 'logs'] as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
        echo "📁 Создана директория: $dir\n";
    }
}
echo "\n";

// Запуск тестов
echo "🚀 Запуск тестов...\n\n";

$phpunit = __DIR__ . '/vendor/bin/phpunit';
$reportFile = __DIR__ . '/reports/test_report_' . date('Y-m-d_H-i-s') . '.html';
$logFile = __DIR__ . '/reports/test_results_' . date('Y-m-d_H-i-s') . '.xml';

$command = sprintf(
    '%s --testdox-html %s --log-junit %s --colors=always 2>&1',
    $phpunit,
    $reportFile,
    $logFile
);

echo "Выполнение: $command\n\n";

system($command, $returnCode);

echo "\n";
echo "═══════════════════════════════════════════════════════════\n";
echo "                     РЕЗУЛЬТАТЫ\n";
echo "═══════════════════════════════════════════════════════════\n\n";

if (file_exists($logFile)) {
    $xml = simplexml_load_file($logFile);
    
    $tests = $xml->xpath('//testcase');
    $total = count($tests);
    $failures = count($xml->xpath('//failure'));
    $errors = count($xml->xpath('//error'));
    $skipped = count($xml->xpath('//skipped'));
    $passed = $total - $failures - $errors - $skipped;
    
    echo "✅ Пройдено: $passed\n";
    echo "❌ Ошибок: $failures\n";
    echo "⚠️  Сбоев: $errors\n";
    echo "⏭️  Пропущено: $skipped\n";
    echo "📊 Всего: $total\n";
    echo "⏱️  Время: " . $xml['time'] . " сек\n\n";
    
    if ($failures > 0 || $errors > 0) {
        echo "❌ НЕКОТОРЫЕ ТЕСТЫ НЕ ПРОЙДЕНЫ!\n";
        echo "📁 HTML отчет: $reportFile\n";
        echo "📁 JUnit отчет: $logFile\n";
        echo "📁 Скриншоты: " . __DIR__ . "/screenshots/\n";
        echo "📁 Логи: " . __DIR__ . "/logs/\n\n";
        exit(1);
    } else {
        echo "🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!\n\n";
        echo "📁 HTML отчет: $reportFile\n";
        echo "📁 Скриншоты: " . __DIR__ . "/screenshots/\n\n";
    }
}

echo "═══════════════════════════════════════════════════════════\n";