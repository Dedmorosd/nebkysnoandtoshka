<?php
namespace Autoservice\Tests;

use Autoservice\Pages\CarsPage;

class CarsTest extends BaseTest
{
    /**
     * @test
     * @group cars
     * @group critical
     */
    public function testAddCar()
    {
        $dashboard = $this->loginAsClient();
        $this->assertTrue($dashboard->isLoaded());
        
        $carsPage = $dashboard->goToAddCar();
        $this->assertTrue($carsPage->isOnPage());
        
        $initialCount = $dashboard->getCarsCount();
        
        $carData = [
            'brand' => 'Toyota',
            'model' => 'Camry',
            'year' => '2020',
            'license_plate' => $this->generateUniquePlate(),
            'vin' => 'JTDBE32KX' . rand(10000000, 99999999)
        ];
        
        $carsPage->addCar($carData);
        
        $this->assertTrue($carsPage->hasSuccess(), "Сообщение об успехе не появилось");
        
        $successMessage = $carsPage->getSuccessMessage();
        $this->assertStringContainsString('Автомобиль успешно добавлен', $successMessage);
        
        // Проверка увеличения счетчика
        $dashboard->refresh();
        $newCount = $dashboard->getCarsCount();
        $this->assertEquals($initialCount + 1, $newCount);
        
        // Проверка наличия в списке
        $this->assertTrue($carsPage->findCarByPlate($carData['license_plate']));
        
        $carsPage->takeScreenshot('car_added');
    }
    
    /**
     * @test
     * @group cars
     */
    public function testAddCarWithDuplicatePlate()
    {
        $dashboard = $this->loginAsClient();
        $carsPage = $dashboard->goToAddCar();
        
        $plate = $this->generateUniquePlate();
        
        // Добавляем первый автомобиль
        $carsPage->addCar([
            'brand' => 'Toyota',
            'model' => 'Camry',
            'year' => '2020',
            'license_plate' => $plate
        ]);
        
        $this->assertTrue($carsPage->hasSuccess());
        
        // Пытаемся добавить второй с тем же номером
        $carsPage->addCar([
            'brand' => 'Honda',
            'model' => 'Accord',
            'year' => '2021',
            'license_plate' => $plate
        ]);
        
        $this->assertTrue($carsPage->hasError(), "Дубликат госномера не заблокирован");
        
        $errorMessage = $carsPage->getErrorMessage();
        $this->assertStringContainsString('существует', $errorMessage);
        
        $carsPage->takeScreenshot('duplicate_plate');
    }
    
    /**
     * @test
     * @group cars
     */
    public function testAddCarWithInvalidLicensePlateFormat()
    {
        $dashboard = $this->loginAsClient();
        $carsPage = $dashboard->goToAddCar();
        
        $carsPage->addCar([
            'brand' => 'Toyota',
            'model' => 'Camry',
            'year' => '2020',
            'license_plate' => '123456'
        ]);
        
        $this->assertTrue($carsPage->hasError(), "Некорректный госномер не заблокирован");
        
        $errorMessage = $carsPage->getErrorMessage();
        $this->assertStringContainsString('формат', $errorMessage);
        
        $carsPage->takeScreenshot('invalid_plate_format');
    }
    
    /**
     * @test
     * @group cars
     */
    public function testAddCarWithInvalidYear()
    {
        $dashboard = $this->loginAsClient();
        $carsPage = $dashboard->goToAddCar();
        
        $carsPage->addCar([
            'brand' => 'Toyota',
            'model' => 'Camry',
            'year' => '1800',
            'license_plate' => $this->generateUniquePlate()
        ]);
        
        $this->assertTrue($carsPage->hasError(), "Некорректный год не заблокирован");
        
        $errorMessage = $carsPage->getErrorMessage();
        $this->assertStringContainsString('год', $errorMessage);
        
        $carsPage->takeScreenshot('invalid_year');
    }
    
    /**
     * @test
     * @group cars
     */
    public function testAddCarWithMissingRequiredFields()
    {
        $dashboard = $this->loginAsClient();
        $carsPage = $dashboard->goToAddCar();
        
        // Открываем модальное окно и пытаемся сохранить без заполнения
        $carsPage->openAddCarModal()->save();
        
        // Проверка HTML5 валидации
        $brandField = $this->driver->findElement(\Facebook\WebDriver\WebDriverBy::name('brand'));
        $this->assertNotEmpty($brandField->getAttribute('required'));
        
        // Закрываем модальное окно
        $this->driver->findElement(\Facebook\WebDriver\WebDriverBy::xpath("//button[@data-bs-dismiss='modal']"))->click();
        
        $carsPage->takeScreenshot('missing_fields');
    }
    
    /**
     * @test
     * @group cars
     */
    public function testDeleteCar()
    {
        $dashboard = $this->loginAsClient();
        $carsPage = $dashboard->goToAddCar();
        
        $plate = $this->generateUniquePlate();
        
        // Добавляем автомобиль
        $carsPage->addCar([
            'brand' => 'Toyota',
            'model' => 'Camry',
            'year' => '2020',
            'license_plate' => $plate
        ]);
        
        $this->assertTrue($carsPage->hasSuccess());
        
        $initialCount = $dashboard->getCarsCount();
        
        // Удаляем автомобиль
        $carsPage->deleteFirstCar();
        
        // Ждем обновления
        $this->pause(1);
        $dashboard->refresh();
        
        $newCount = $dashboard->getCarsCount();
        $this->assertEquals($initialCount - 1, $newCount);
        
        // Проверка, что автомобиль удален из списка
        $this->assertFalse($carsPage->findCarByPlate($plate));
        
        $carsPage->takeScreenshot('car_deleted');
    }
    
    /**
     * @test
     * @group cars
     */
    public function testEmptyCarsList()
    {
        $dashboard = $this->loginAsClient();
        $carsPage = $dashboard->goToAddCar();
        
        // Удаляем все автомобили
        while (!$carsPage->isEmpty()) {
            $carsPage->deleteFirstCar();
            $this->pause(1);
        }
        
        $this->assertTrue($carsPage->isEmpty(), "Список автомобилей не пуст");
        
        $dashboard->refresh();
        $this->assertEquals(0, $dashboard->getCarsCount());
        
        $carsPage->takeScreenshot('empty_cars_list');
    }
}
