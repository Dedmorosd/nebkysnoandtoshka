<?php
namespace Autoservice\Tests;

use PHPUnit\Framework\TestCase;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Chrome\ChromeOptions;
use Facebook\WebDriver\WebDriverDimension;
use Autoservice\Pages\LoginPage;
use Autoservice\Pages\DashboardPage;

abstract class BaseTest extends TestCase
{
    protected $driver;
    protected $config;
    protected $loginPage;
    protected $dashboardPage;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        $this->config = require __DIR__ . '/../config/config.php';
        
        $options = new ChromeOptions();
        
        if ($this->config['webdriver']['headless']) {
            $options->addArguments([
                '--headless',
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu'
            ]);
        }
        
        $options->addArguments([
            '--start-maximized',
            '--disable-extensions',
            '--disable-popup-blocking'
        ]);
        
        $capabilities = DesiredCapabilities::chrome();
        $capabilities->setCapability(ChromeOptions::CAPABILITY, $options);
        
        $this->driver = RemoteWebDriver::create(
            $this->config['webdriver']['host'],
            $capabilities
        );
        
        $this->driver->manage()->timeouts()->implicitlyWait(
            $this->config['timeouts']['implicit']
        );
        
        $this->driver->manage()->timeouts()->pageLoadTimeout(
            $this->config['timeouts']['page_load']
        );
        
        $this->driver->manage()->window()->setSize(
            new WebDriverDimension(
                $this->config['webdriver']['window_size']['width'],
                $this->config['webdriver']['window_size']['height']
            )
        );
        
        $this->loginPage = new LoginPage($this->driver, $this->config);
        $this->dashboardPage = new DashboardPage($this->driver, $this->config);
    }
    
    protected function tearDown(): void
    {
        if ($this->hasFailed() && $this->config['screenshot_on_failure']) {
            $screenshotPath = $this->config['paths']['screenshots'];
            if (!is_dir($screenshotPath)) {
                mkdir($screenshotPath, 0777, true);
            }
            $filename = $screenshotPath . 'failure_' . $this->getName() . '_' . date('Y-m-d_H-i-s') . '.png';
            $this->driver->takeScreenshot($filename);
        }
        
        if ($this->driver) {
            $this->driver->quit();
        }
        
        parent::tearDown();
    }
    
    protected function loginAsAdmin()
    {
        $admin = $this->config['test_users']['admin'];
        return $this->loginPage->login($admin['username'], $admin['password']);
    }
    
    protected function loginAsClient()
    {
        $client = $this->config['test_users']['client'];
        return $this->loginPage->login($client['username'], $client['password']);
    }
    
    protected function generateUniqueUsername()
    {
        return 'testuser_' . uniqid();
    }
    
    protected function generateUniqueEmail()
    {
        return 'test_' . uniqid() . '@example.com';
    }
    
    protected function generateUniquePlate()
    {
        $letters = ['А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х'];
        $num = rand(100, 999);
        $letter1 = $letters[array_rand($letters)];
        $letter2 = $letters[array_rand($letters)];
        $region = rand(10, 199);
        
        return $letter1 . $num . $letter2 . $letter2 . $region;
    }
    
    protected function pause($seconds = 1)
    {
        sleep($seconds);
    }
}