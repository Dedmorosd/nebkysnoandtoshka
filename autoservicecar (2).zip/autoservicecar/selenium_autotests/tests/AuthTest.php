<?php
namespace Autoservice\Tests;

use Autoservice\Pages\RegisterPage;

class AuthTest extends BaseTest
{
    /**
     * @test
     * @group auth
     * @group critical
     */
    public function testSuccessfulLoginAsAdmin()
    {
        $dashboard = $this->loginAsAdmin();
        
        $this->assertTrue($dashboard->isLoaded(), "Dashboard не загрузился");
        $this->assertStringContainsString(
            $this->config['test_users']['admin']['username'],
            $dashboard->getUserName(),
            "Имя пользователя не отображается"
        );
        $this->assertTrue($dashboard->hasAdminPanel(), "Админ-панель недоступна для администратора");
        
        // Скриншот для отчета
        $dashboard->takeScreenshot('admin_dashboard');
    }
    
    /**
     * @test
     * @group auth
     * @group critical
     */
    public function testSuccessfulLoginAsClient()
    {
        $dashboard = $this->loginAsClient();
        
        $this->assertTrue($dashboard->isLoaded(), "Dashboard не загрузился");
        $this->assertStringContainsString(
            $this->config['test_users']['client']['username'],
            $dashboard->getUserName(),
            "Имя пользователя не отображается"
        );
        $this->assertFalse($dashboard->hasAdminPanel(), "Клиент видит админ-панель");
        
        $dashboard->takeScreenshot('client_dashboard');
    }
    
    /**
     * @test
     * @group auth
     * @group critical
     */
    public function testLoginWithInvalidPassword()
    {
        $admin = $this->config['test_users']['admin'];
        
        $this->loginPage->open()
            ->setUsername($admin['username'])
            ->setPassword('wrongpassword')
            ->submit();
        
        $this->assertTrue($this->loginPage->hasError(), "Сообщение об ошибке не появилось");
        
        $errorMessage = $this->loginPage->getErrorMessage();
        $this->assertStringContainsString('Неверный пароль', $errorMessage);
        $this->assertTrue($this->loginPage->isOnPage(), "Редирект с страницы входа");
        
        $this->loginPage->takeScreenshot('invalid_password');
    }
    
    /**
     * @test
     * @group auth
     */
    public function testLoginWithNonExistentUser()
    {
        $this->loginPage->open()
            ->setUsername('nonexistent_user_12345')
            ->setPassword('anypassword')
            ->submit();
        
        $this->assertTrue($this->loginPage->hasError(), "Сообщение об ошибке не появилось");
        
        $errorMessage = $this->loginPage->getErrorMessage();
        $this->assertStringContainsString('Пользователь не найден', $errorMessage);
    }
    
    /**
     * @test
     * @group auth
     */
    public function testLoginWithEmptyFields()
    {
        $this->loginPage->open()->submit();
        
        $this->assertTrue($this->loginPage->isOnPage(), "Страница изменилась");
        
        // Проверка атрибута required
        $usernameField = $this->driver->findElement(\Facebook\WebDriver\WebDriverBy::name('username'));
        $passwordField = $this->driver->findElement(\Facebook\WebDriver\WebDriverBy::name('password'));
        
        $this->assertEquals('true', $usernameField->getAttribute('required'));
        $this->assertEquals('true', $passwordField->getAttribute('required'));
    }
    
    /**
     * @test
     * @group auth
     * @group critical
     */
    public function testLogout()
    {
        $dashboard = $this->loginAsClient();
        $this->assertTrue($dashboard->isLoaded());
        
        $loginPage = $dashboard->logout();
        
        $this->assertTrue($loginPage->isOnPage(), "Не перенаправлено на страницу входа");
        
        // Проверка, что нельзя вернуться на dashboard
        $this->driver->get($this->config['app_url'] . '/dashboard.php');
        $this->assertTrue($loginPage->isOnPage(), "Доступ к dashboard после выхода");
        
        $loginPage->takeScreenshot('after_logout');
    }
    
    /**
     * @test
     * @group auth
     * @group register
     */
    public function testSuccessfulRegistration()
    {
        $registerPage = new RegisterPage($this->driver, $this->config);
        
        $newUser = [
            'username' => $this->generateUniqueUsername(),
            'email' => $this->generateUniqueEmail(),
            'password' => 'Test123!@#',
            'full_name' => 'Тестовый Пользователь',
            'phone' => '+79991234567'
        ];
        
        $registerPage->register($newUser);
        
        $this->assertTrue($registerPage->hasSuccess(), "Сообщение об успехе не появилось");
        
        $successMessage = $registerPage->getSuccessMessage();
        $this->assertStringContainsString('Регистрация успешна', $successMessage);
        
        // Проверка входа
        $dashboard = $this->loginPage->login($newUser['username'], $newUser['password']);
        $this->assertTrue($dashboard->isLoaded(), "Не удалось войти после регистрации");
        
        $dashboard->takeScreenshot('registration_success');
    }
    
    /**
     * @test
     * @group auth
     * @group register
     */
    public function testRegistrationWithExistingUsername()
    {
        $registerPage = new RegisterPage($this->driver, $this->config);
        $admin = $this->config['test_users']['admin'];
        
        $registerPage->register([
            'username' => $admin['username'],
            'email' => $this->generateUniqueEmail(),
            'password' => 'Test123!@#',
            'full_name' => 'Test User',
            'phone' => '+79991234567'
        ]);
        
        $this->assertTrue($registerPage->hasError(), "Сообщение об ошибке не появилось");
        
        $errorMessage = $registerPage->getErrorMessage();
        $this->assertStringContainsString('уже существует', $errorMessage);
        
        $registerPage->takeScreenshot('duplicate_username');
    }
    
    /**
     * @test
     * @group auth
     * @group register
     */
    public function testRegistrationWithMismatchedPasswords()
    {
        $registerPage = new RegisterPage($this->driver, $this->config);
        
        $registerPage->open()
            ->setUsername($this->generateUniqueUsername())
            ->setEmail($this->generateUniqueEmail())
            ->setPassword('Password123')
            ->setConfirmPassword('Password456')
            ->setFullName('Test User')
            ->setPhone('+79991234567')
            ->submit();
        
        $this->assertTrue($registerPage->hasError(), "Сообщение об ошибке не появилось");
        
        $errorMessage = $registerPage->getErrorMessage();
        $this->assertStringContainsString('не совпадают', $errorMessage);
    }
    
    /**
     * @test
     * @group auth
     * @group register
     */
    public function testRegistrationWithWeakPassword()
    {
        $registerPage = new RegisterPage($this->driver, $this->config);
        
        $registerPage->register([
            'username' => $this->generateUniqueUsername(),
            'email' => $this->generateUniqueEmail(),
            'password' => '123',
            'full_name' => 'Test User',
            'phone' => '+79991234567'
        ]);
        
        $this->assertTrue($registerPage->hasError(), "Сообщение об ошибке не появилось");
        
        $errorMessage = $registerPage->getErrorMessage();
        $this->assertStringContainsString('6 символов', $errorMessage);
    }
    
    /**
     * @test
     * @group auth
     * @group security
     */
    public function testLoginWithSQLInjectionAttempt()
    {
        $sqlInjection = "' OR '1'='1' -- ";
        
        $this->loginPage->open()
            ->setUsername($sqlInjection)
            ->setPassword($sqlInjection)
            ->submit();
        
        $this->assertTrue($this->loginPage->hasError(), "SQL-инъекция должна быть заблокирована");
        $this->assertTrue($this->loginPage->isOnPage(), "Не остались на странице входа");
        
        // Проверка, что таблица users не повреждена
        $this->retry(function() {
            $this->loginPage->open();
            $this->assertTrue($this->loginPage->isOnPage(), "Страница входа недоступна");
        });
        
        $this->loginPage->takeScreenshot('sql_injection_protection');
    }
    
    /**
     * @test
     * @group auth
     * @group security
     */
    public function testLoginWithXSSAttempt()
    {
        $xssString = '<script>alert("XSS")</script>';
        
        $this->loginPage->open()
            ->setUsername($xssString)
            ->setPassword($xssString)
            ->submit();
        
        $this->assertTrue($this->loginPage->hasError(), "XSS-атака должна быть заблокирована");
        
        $pageSource = $this->driver->getPageSource();
        $this->assertStringNotContainsString('<script>', $pageSource);
        
        $this->loginPage->takeScreenshot('xss_protection');
    }
}
