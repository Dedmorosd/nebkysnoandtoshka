<?php
namespace Autoservice\Tests;

use Autoservice\Pages\CreateOrderPage;

class OrdersTest extends BaseTest
{
    /**
     * @test
     * @group orders
     * @group critical
     */
    public function testCreateOrder()
    {
        $dashboard = $this->loginAsClient();
        $this->assertTrue($dashboard->isLoaded());
        
        $initialOrdersCount = $dashboard->getOrdersCount();
        
        // Добавляем автомобиль, если нет
        if ($dashboard->getCarsCount() == 0) {
            $carsPage = $dashboard->goToAddCar();
            $carsPage->addCar([
                'brand' => 'Toyota',
                'model' => 'Camry',
                'year' => '2020',
                'license_plate' => $this->generateUniquePlate()
            ]);
            $this->assertTrue($carsPage->hasSuccess());
            $dashboard->refresh();
        }
        
        $createOrderPage = $dashboard->goToCreateOrder();
        $this->assertTrue($createOrderPage->isOnPage());
        
        $services = $createOrderPage->getServicesList();
        $this->assertNotEmpty($services, "Нет доступных услуг");
        
        // Создаем заказ
        $orderData = [
            'car_id' => '1',
            'services' => ['1', '2'],
            'description' => 'Тестовый заказ через Selenium',
            'preferred_date' => date('Y-m-d', strtotime('+3 days'))
        ];
        
        $initialTotal = $createOrderPage->getTotalAmount();
        $this->assertGreaterThan(0, $initialTotal, "Общая сумма не рассчитана");
        
        $createOrderPage->createOrder($orderData);
        
        $this->assertTrue($createOrderPage->hasSuccess(), "Заказ не создан");
        
        $successMessage = $createOrderPage->getSuccessMessage();
        $this->assertStringContainsString('Заказ успешно создан', $successMessage);
        
        // Проверка увеличения счетчика
        $dashboard->refresh();
        $newOrdersCount = $dashboard->getOrdersCount();
        $this->assertEquals($initialOrdersCount + 1, $newOrdersCount);
        
        $createOrderPage->takeScreenshot('order_created');
    }
    
    /**
     * @test
     * @group orders
     */
    public function testTotalPriceCalculation()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        $createOrderPage->selectCar('1');
        
        // Получаем начальную сумму
        $initialTotal = $createOrderPage->getTotalAmount();
        
        // Выбираем услуги
        $createOrderPage->selectServices(['1']);
        $totalWithOne = $createOrderPage->getTotalAmount();
        
        $this->assertGreaterThan($initialTotal, $totalWithOne, "Сумма не увеличилась после выбора услуги");
        
        // Добавляем вторую услугу
        $createOrderPage->selectServices(['1', '2']);
        $totalWithTwo = $createOrderPage->getTotalAmount();
        
        $this->assertGreaterThan($totalWithOne, $totalWithTwo, "Сумма не увеличилась после добавления услуги");
        
        // Снимаем услугу
        $createOrderPage->selectServices(['2']);
        $totalWithOneAgain = $createOrderPage->getTotalAmount();
        
        $this->assertEquals($totalWithOne, $totalWithOneAgain, "Сумма не вернулась к исходной после снятия услуги");
        
        $createOrderPage->takeScreenshot('price_calculation');
    }
    
    /**
     * @test
     * @group orders
     */
    public function testCreateOrderWithoutCar()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        // Не выбираем автомобиль, пытаемся отправить
        $createOrderPage->selectServices(['1', '2'])
            ->setDescription('Тестовый заказ')
            ->setPreferredDate(date('Y-m-d', strtotime('+3 days')))
            ->submit();
        
        // Проверка валидации
        $this->assertTrue($createOrderPage->isOnPage(), "Форма отправилась без выбора автомобиля");
        
        $createOrderPage->takeScreenshot('order_without_car');
    }
    
    /**
     * @test
     * @group orders
     */
    public function testCreateOrderWithoutServices()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        // Выбираем автомобиль, но не выбираем услуги
        $createOrderPage->selectCar('1')
            ->setDescription('Тестовый заказ')
            ->setPreferredDate(date('Y-m-d', strtotime('+3 days')))
            ->submit();
        
        $this->assertTrue($createOrderPage->hasError(), "Заказ создан без услуг");
        
        $errorMessage = $createOrderPage->getErrorMessage();
        $this->assertStringContainsString('услуг', $errorMessage);
        
        $createOrderPage->takeScreenshot('order_without_services');
    }
    
    /**
     * @test
     * @group orders
     */
    public function testCreateOrderWithPastDate()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        $createOrderPage->selectCar('1')
            ->selectServices(['1', '2'])
            ->setDescription('Тестовый заказ')
            ->setPreferredDate(date('Y-m-d', strtotime('-1 day')))
            ->submit();
        
        $this->assertTrue($createOrderPage->hasError(), "Заказ создан с прошедшей датой");
        
        $errorMessage = $createOrderPage->getErrorMessage();
        $this->assertStringContainsString('прошлом', $errorMessage);
        
        $createOrderPage->takeScreenshot('order_past_date');
    }
}
