<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;
use Facebook\WebDriver\WebDriverWait;
use Facebook\WebDriver\Exception\TimeoutException;

abstract class BasePage
{
    protected $driver;
    protected $wait;
    protected $config;
    protected $url;
    protected $timeouts;
    
    public function __construct(RemoteWebDriver $driver, array $config)
    {
        $this->driver = $driver;
        $this->config = $config;
        $this->timeouts = $config['timeouts'];
        
        $this->wait = new WebDriverWait(
            $driver,
            $this->timeouts['explicit']
        );
        
        $this->driver->manage()->timeouts()->implicitlyWait(
            $this->timeouts['implicit']
        );
        
        $this->driver->manage()->timeouts()->pageLoadTimeout(
            $this->timeouts['page_load']
        );
        
        $this->driver->manage()->window()->setSize(
            new \Facebook\WebDriver\WebDriverDimension(
                $config['webdriver']['window_size']['width'],
                $config['webdriver']['window_size']['height']
            )
        );
    }
    
    public function open()
    {
        if ($this->url) {
            $fullUrl = $this->config['app_url'] . $this->url;
            $this->driver->get($fullUrl);
        }
        return $this;
    }
    
    protected function findElement($selector, $timeout = null)
    {
        $wait = $timeout ? new WebDriverWait($this->driver, $timeout) : $this->wait;
        
        try {
            return $wait->until(
                WebDriverExpectedCondition::presenceOfElementLocated($selector)
            );
        } catch (TimeoutException $e) {
            $this->takeScreenshot('element_not_found');
            throw $e;
        }
    }
    
    protected function click($selector)
    {
        $element = $this->findElement($selector);
        $element->click();
        return $this;
    }
    
    protected function type($selector, $text)
    {
        $element = $this->findElement($selector);
        $element->clear();
        $element->sendKeys($text);
        return $this;
    }
    
    protected function getText($selector)
    {
        $element = $this->findElement($selector);
        return $element->getText();
    }
    
    protected function getAttribute($selector, $attribute)
    {
        $element = $this->findElement($selector);
        return $element->getAttribute($attribute);
    }
    
    protected function isElementPresent($selector, $timeout = 3)
    {
        try {
            $wait = new WebDriverWait($this->driver, $timeout);
            $wait->until(
                WebDriverExpectedCondition::presenceOfElementLocated($selector)
            );
            return true;
        } catch (TimeoutException $e) {
            return false;
        }
    }
    
    protected function isElementVisible($selector, $timeout = 3)
    {
        try {
            $wait = new WebDriverWait($this->driver, $timeout);
            $wait->until(
                WebDriverExpectedCondition::visibilityOfElementLocated($selector)
            );
            return true;
        } catch (TimeoutException $e) {
            return false;
        }
    }
    
    protected function waitForElement($selector, $timeout = null)
    {
        $wait = $timeout ? new WebDriverWait($this->driver, $timeout) : $this->wait;
        $wait->until(
            WebDriverExpectedCondition::presenceOfElementLocated($selector)
        );
        return $this;
    }
    
    protected function waitForElementVisible($selector, $timeout = null)
    {
        $wait = $timeout ? new WebDriverWait($this->driver, $timeout) : $this->wait;
        $wait->until(
            WebDriverExpectedCondition::visibilityOfElementLocated($selector)
        );
        return $this;
    }
    
    protected function waitForElementToDisappear($selector, $timeout = null)
    {
        $wait = $timeout ? new WebDriverWait($this->driver, $timeout) : $this->wait;
        $wait->until(
            WebDriverExpectedCondition::invisibilityOfElementLocated($selector)
        );
        return $this;
    }
    
    protected function waitForUrl($partialUrl)
    {
        $this->wait->until(
            WebDriverExpectedCondition::urlContains($partialUrl)
        );
        return $this;
    }
    
    protected function scrollToElement($element)
    {
        $this->driver->executeScript(
            'arguments[0].scrollIntoView({behavior: "smooth", block: "center"});',
            [$element]
        );
        return $this;
    }
    
    protected function executeScript($script, $args = [])
    {
        return $this->driver->executeScript($script, $args);
    }
    
    public function takeScreenshot($name)
    {
        $path = $this->config['paths']['screenshots'];
        if (!is_dir($path)) {
            mkdir($path, 0777, true);
        }
        
        $filename = $path . date('Y-m-d_H-i-s') . '_' . $name . '.png';
        $this->driver->takeScreenshot($filename);
        return $filename;
    }
    
    public function getCurrentUrl()
    {
        return $this->driver->getCurrentURL();
    }
    
    public function getTitle()
    {
        return $this->driver->getTitle();
    }
    
    public function refresh()
    {
        $this->driver->navigate()->refresh();
        return $this;
    }
    
    abstract public function isOnPage();
}