<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverSelect;

class CreateOrderPage extends BasePage
{
    protected $url = '/create_order.php';
    
    // Селекторы
    private $carSelect = WebDriverBy::name('car_id');
    private $serviceCheckboxes = WebDriverBy::xpath("//input[@name='services[]']");
    private $descriptionInput = WebDriverBy::name('description');
    private $preferredDateInput = WebDriverBy::name('preferred_date');
    private $submitButton = WebDriverBy::xpath("//button[@type='submit'][contains(text(), 'Создать заказ')]");
    private $totalAmount = WebDriverBy::id('totalAmount');
    private $successMessage = WebDriverBy::className('alert-success');
    private $errorMessage = WebDriverBy::className('alert-danger');
    private $serviceLabels = WebDriverBy::cssSelector('.service-checkbox label');
    
    /**
     * Создать заказ
     */
    public function createOrder($orderData)
    {
        $this->logger->info("Создание заказа");
        
        $this->open()
             ->selectCar($orderData['car_id'])
             ->selectServices($orderData['services'])
             ->setDescription($orderData['description'] ?? '')
             ->setPreferredDate($orderData['preferred_date'])
             ->submit();
        
        return $this;
    }
    
    /**
     * Выбрать автомобиль
     */
    public function selectCar($carId)
    {
        $select = new WebDriverSelect($this->findElement($this->carSelect));
        $select->selectByValue($carId);
        $this->logger->debug("Выбран автомобиль ID: $carId");
        return $this;
    }
    
    /**
     * Выбрать услуги
     */
    public function selectServices($serviceIds)
    {
        $checkboxes = $this->driver->findElements($this->serviceCheckboxes);
        
        foreach ($checkboxes as $checkbox) {
            $value = $checkbox->getAttribute('value');
            if (in_array($value, $serviceIds)) {
                if (!$checkbox->isSelected()) {
                    $checkbox->click();
                    $this->logger->debug("Выбрана услуга ID: $value");
                }
            } else {
                if ($checkbox->isSelected()) {
                    $checkbox->click();
                }
            }
        }
        
        // Обновляем общую сумму
        sleep(1);
        
        return $this;
    }
    
    /**
     * Установить описание
     */
    public function setDescription($description)
    {
        $this->type($this->descriptionInput, $description);
        return $this;
    }
    
    /**
     * Установить предпочтительную дату
     */
    public function setPreferredDate($date)
    {
        $this->type($this->preferredDateInput, $date);
        return $this;
    }
    
    /**
     * Отправить форму
     */
    public function submit()
    {
        $this->click($this->submitButton);
        return $this;
    }
    
    /**
     * Получить общую сумму
     */
    public function getTotalAmount()
    {
        $text = $this->getText($this->totalAmount);
        $amount = (float)str_replace([' ', '₽', ','], ['.', '', '.'], $text);
        $this->logger->debug("Общая сумма: $amount");
        return $amount;
    }
    
    /**
     * Получить список доступных услуг
     */
    public function getServicesList()
    {
        $services = [];
        $labels = $this->driver->findElements($this->serviceLabels);
        
        foreach ($labels as $label) {
            $services[] = $label->getText();
        }
        
        return $services;
    }
    
    /**
     * Получить сообщение об успехе
     */
    public function getSuccessMessage()
    {
        if ($this->isElementVisible($this->successMessage, 5)) {
            return $this->getText($this->successMessage);
        }
        return null;
    }
    
    /**
     * Получить сообщение об ошибке
     */
    public function getErrorMessage()
    {
        if ($this->isElementVisible($this->errorMessage, 5)) {
            return $this->getText($this->errorMessage);
        }
        return null;
    }
    
    /**
     * Есть ли сообщение об успехе
     */
    public function hasSuccess()
    {
        return $this->isElementVisible($this->successMessage);
    }
    
    /**
     * Есть ли сообщение об ошибке
     */
    public function hasError()
    {
        return $this->isElementVisible($this->errorMessage);
    }
    
    /**
     * Проверить, что на странице создания заказа
     */
    public function isOnPage()
    {
        return $this->isElementVisible($this->submitButton);
    }
}
