<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;

class DashboardPage extends BasePage
{
    protected $url = '/dashboard.php';
    
    // Селекторы
    private $pageTitle = WebDriverBy::xpath("//h1[contains(text(), 'Панель управления')]");
    private $userName = WebDriverBy::cssSelector('.navbar .user-name, .navbar .nav-link .fa-user + span');
    private $userRole = WebDriverBy::cssSelector('.navbar .role-badge, .navbar .nav-link .fa-user ~ span');
    private $logoutLink = WebDriverBy::linkText('Выход');
    private $addCarButton = WebDriverBy::xpath("//a[contains(text(), 'Добавить автомобиль')]");
    private $createOrderButton = WebDriverBy::xpath("//a[contains(text(), 'Создать заказ')]");
    private $viewServicesButton = WebDriverBy::xpath("//a[contains(text(), 'Посмотреть услуги')]");
    private $myOrdersCard = WebDriverBy::xpath("//h6[contains(text(), 'Мои заказы')]/../h2");
    private $myCarsCard = WebDriverBy::xpath("//h6[contains(text(), 'Мои автомобили')]/../h2");
    private $adminPanelLink = WebDriverBy::xpath("//a[contains(text(), 'Админ панель')]");
    private $statCards = WebDriverBy::className('stat-card');
    
    /**
     * Проверить загрузку dashboard
     */
    public function isLoaded()
    {
        return $this->isElementVisible($this->pageTitle);
    }
    
    /**
     * Получить имя пользователя
     */
    public function getUserName()
    {
        return $this->getText($this->userName);
    }
    
    /**
     * Получить роль пользователя
     */
    public function getUserRole()
    {
        if ($this->isElementVisible($this->userRole, 2)) {
            return $this->getText($this->userRole);
        }
        return null;
    }
    
    /**
     * Выйти из системы
     */
    public function logout()
    {
        $this->click($this->logoutLink);
        return new LoginPage($this->driver, $this->config);
    }
    
    /**
     * Перейти на страницу добавления автомобиля
     */
    public function goToAddCar()
    {
        $this->click($this->addCarButton);
        return new CarsPage($this->driver, $this->config);
    }
    
    /**
     * Перейти на страницу создания заказа
     */
    public function goToCreateOrder()
    {
        $this->click($this->createOrderButton);
        return new CreateOrderPage($this->driver, $this->config);
    }
    
    /**
     * Перейти на страницу услуг
     */
    public function goToServices()
    {
        $this->click($this->viewServicesButton);
        return new ServicesPage($this->driver, $this->config);
    }
    
    /**
     * Получить количество заказов
     */
    public function getOrdersCount()
    {
        if ($this->isElementVisible($this->myOrdersCard)) {
            return (int)$this->getText($this->myOrdersCard);
        }
        return 0;
    }
    
    /**
     * Получить количество автомобилей
     */
    public function getCarsCount()
    {
        if ($this->isElementVisible($this->myCarsCard)) {
            return (int)$this->getText($this->myCarsCard);
        }
        return 0;
    }
    
    /**
     * Есть ли доступ к админ-панели
     */
    public function hasAdminPanel()
    {
        return $this->isElementVisible($this->adminPanelLink);
    }
    
    /**
     * Перейти в админ-панель
     */
    public function goToAdminPanel()
    {
        $this->click($this->adminPanelLink);
        return new AdminPage($this->driver, $this->config);
    }
    
    /**
     * Получить все статистические карточки
     */
    public function getStatCards()
    {
        $cards = [];
        $elements = $this->driver->findElements($this->statCards);
        
        foreach ($elements as $element) {
            $cards[] = $element->getText();
        }
        
        return $cards;
    }
    
    /**
     * Проверить, что на dashboard
     */
    public function isOnPage()
    {
        return $this->isElementVisible($this->pageTitle);
    }
}
