<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverSelect;

class CarsPage extends BasePage
{
    protected $url = '/cars.php';
    
    // Селекторы
    private $addCarButton = WebDriverBy::xpath("//button[contains(text(), 'Добавить автомобиль')]");
    private $addCarModal = WebDriverBy::id('addCarModal');
    private $brandInput = WebDriverBy::name('brand');
    private $modelInput = WebDriverBy::name('model');
    private $yearSelect = WebDriverBy::name('year');
    private $licensePlateInput = WebDriverBy::name('license_plate');
    private $vinInput = WebDriverBy::name('vin');
    private $saveButton = WebDriverBy::xpath("//button[@type='submit'][contains(text(), 'Сохранить')]");
    private $carCards = WebDriverBy::className('car-card');
    private $carCardTitle = WebDriverBy::className('card-title');
    private $successMessage = WebDriverBy::className('alert-success');
    private $errorMessage = WebDriverBy::className('alert-danger');
    private $deleteButtons = WebDriverBy::xpath("//button[contains(text(), 'Удалить')]");
    private $emptyState = WebDriverBy::xpath("//p[contains(text(), 'У вас пока нет автомобилей')]");
    
    /**
     * Открыть модальное окно добавления
     */
    public function openAddCarModal()
    {
        $this->click($this->addCarButton);
        $this->waitForElementVisible($this->addCarModal);
        return $this;
    }
    
    /**
     * Добавить автомобиль
     */
    public function addCar($carData)
    {
        $this->openAddCarModal()
             ->setBrand($carData['brand'])
             ->setModel($carData['model'])
             ->setYear($carData['year'])
             ->setLicensePlate($carData['license_plate']);
        
        if (isset($carData['vin'])) {
            $this->setVin($carData['vin']);
        }
        
        $this->save();
        
        // Закрываем модальное окно, если оно еще открыто
        $this->waitForElementToDisappear($this->addCarModal, 5);
        
        return $this;
    }
    
    public function setBrand($brand)
    {
        $this->type($this->brandInput, $brand);
        return $this;
    }
    
    public function setModel($model)
    {
        $this->type($this->modelInput, $model);
        return $this;
    }
    
    public function setYear($year)
    {
        $select = new WebDriverSelect($this->findElement($this->yearSelect));
        $select->selectByValue($year);
        return $this;
    }
    
    public function setLicensePlate($plate)
    {
        $this->type($this->licensePlateInput, $plate);
        return $this;
    }
    
    public function setVin($vin)
    {
        $this->type($this->vinInput, $vin);
        return $this;
    }
    
    public function save()
    {
        $this->click($this->saveButton);
        return $this;
    }
    
    /**
     * Получить список автомобилей
     */
    public function getCarsList()
    {
        $cars = [];
        $carElements = $this->driver->findElements($this->carCards);
        
        foreach ($carElements as $carElement) {
            $cars[] = $carElement->getText();
        }
        
        return $cars;
    }
    
    /**
     * Получить количество автомобилей
     */
    public function getCarsCount()
    {
        $cars = $this->driver->findElements($this->carCards);
        return count($cars);
    }
    
    /**
     * Найти автомобиль по госномеру
     */
    public function findCarByPlate($plate)
    {
        $cars = $this->getCarsList();
        foreach ($cars as $car) {
            if (strpos($car, $plate) !== false) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Удалить первый автомобиль
     */
    public function deleteFirstCar()
    {
        $deleteButtons = $this->driver->findElements($this->deleteButtons);
        if (count($deleteButtons) > 0) {
            $deleteButtons[0]->click();
            $this->driver->switchTo()->alert()->accept();
            $this->waitForElementToDisappear($this->deleteButtons[0], 5);
        }
        return $this;
    }
    
    /**
     * Получить сообщение об успехе
     */
    public function getSuccessMessage()
    {
        if ($this->isElementVisible($this->successMessage, 3)) {
            return $this->getText($this->successMessage);
        }
        return null;
    }
    
    /**
     * Получить сообщение об ошибке
     */
    public function getErrorMessage()
    {
        if ($this->isElementVisible($this->errorMessage, 3)) {
            return $this->getText($this->errorMessage);
        }
        return null;
    }
    
    /**
     * Есть ли сообщение об успехе
     */
    public function hasSuccess()
    {
        return $this->isElementVisible($this->successMessage);
    }
    
    /**
     * Есть ли сообщение об ошибке
     */
    public function hasError()
    {
        return $this->isElementVisible($this->errorMessage);
    }
    
    /**
     * Пустой ли список автомобилей
     */
    public function isEmpty()
    {
        return $this->isElementVisible($this->emptyState);
    }
    
    /**
     * Проверить, что на странице автомобилей
     */
    public function isOnPage()
    {
        return $this->isElementVisible($this->addCarButton) || 
               $this->isElementVisible($this->emptyState);
    }
}
