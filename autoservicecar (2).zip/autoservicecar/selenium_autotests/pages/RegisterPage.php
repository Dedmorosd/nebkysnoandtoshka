<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;

class RegisterPage extends BasePage
{
    protected $url = '/register.php';
    
    // Селекторы
    private $usernameInput = WebDriverBy::name('username');
    private $emailInput = WebDriverBy::name('email');
    private $passwordInput = WebDriverBy::name('password');
    private $confirmPasswordInput = WebDriverBy::name('confirm_password');
    private $fullNameInput = WebDriverBy::name('full_name');
    private $phoneInput = WebDriverBy::name('phone');
    private $registerButton = WebDriverBy::xpath("//button[@type='submit']");
    private $loginLink = WebDriverBy::linkText('Войти');
    private $errorMessage = WebDriverBy::className('alert-danger');
    private $successMessage = WebDriverBy::className('alert-success');
    
    /**
     * Зарегистрировать нового пользователя
     */
    public function register($userData)
    {
        $this->logger->info("Регистрация пользователя: {$userData['username']}");
        
        $this->open()
             ->setUsername($userData['username'])
             ->setEmail($userData['email'])
             ->setPassword($userData['password'])
             ->setConfirmPassword($userData['password'])
             ->setFullName($userData['full_name'])
             ->setPhone($userData['phone'])
             ->submit();
        
        return $this;
    }
    
    public function setUsername($username)
    {
        $this->type($this->usernameInput, $username);
        return $this;
    }
    
    public function setEmail($email)
    {
        $this->type($this->emailInput, $email);
        return $this;
    }
    
    public function setPassword($password)
    {
        $this->type($this->passwordInput, $password);
        return $this;
    }
    
    public function setConfirmPassword($password)
    {
        $this->type($this->confirmPasswordInput, $password);
        return $this;
    }
    
    public function setFullName($fullName)
    {
        $this->type($this->fullNameInput, $fullName);
        return $this;
    }
    
    public function setPhone($phone)
    {
        $this->type($this->phoneInput, $phone);
        return $this;
    }
    
    public function submit()
    {
        $this->click($this->registerButton);
        return $this;
    }
    
    public function goToLogin()
    {
        $this->click($this->loginLink);
        return new LoginPage($this->driver, $this->config);
    }
    
    public function getErrorMessage()
    {
        if ($this->isElementVisible($this->errorMessage, 3)) {
            return $this->getText($this->errorMessage);
        }
        return null;
    }
    
    public function getSuccessMessage()
    {
        if ($this->isElementVisible($this->successMessage, 3)) {
            return $this->getText($this->successMessage);
        }
        return null;
    }
    
    public function hasError()
    {
        return $this->isElementVisible($this->errorMessage);
    }
    
    public function hasSuccess()
    {
        return $this->isElementVisible($this->successMessage);
    }
    
    public function isOnPage()
    {
        return $this->isElementVisible($this->registerButton);
    }
}
