<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverSelect;

class OrdersPage extends BasePage
{
    protected $url = '/orders.php';
    
    // Селекторы
    private $orderRows = WebDriverBy::cssSelector('table tbody tr');
    private $orderStatuses = WebDriverBy::cssSelector('table tbody tr .badge');
    private $cancelButtons = WebDriverBy::xpath("//a[contains(@href, 'cancel=')]");
    private $viewButtons = WebDriverBy::xpath("//a[contains(text(), 'Просмотр')]");
    private $statusFilter = WebDriverBy::id('statusFilter');
    private $searchInput = WebDriverBy::id('searchInput');
    private $createOrderButton = WebDriverBy::xpath("//a[contains(text(), 'Новый заказ')]");
    private $emptyState = WebDriverBy::xpath("//p[contains(text(), 'Заказов пока нет')]");
    
    /**
     * Получить все заказы
     */
    public function getOrders()
    {
        $orders = [];
        $rows = $this->driver->findElements($this->orderRows);
        
        foreach ($rows as $row) {
            $orders[] = $row->getText();
        }
        
        return $orders;
    }
    
    /**
     * Получить количество заказов
     */
    public function getOrdersCount()
    {
        return count($this->driver->findElements($this->orderRows));
    }
    
    /**
     * Получить статусы всех заказов
     */
    public function getOrderStatuses()
    {
        $statuses = [];
        $elements = $this->driver->findElements($this->orderStatuses);
        
        foreach ($elements as $element) {
            $statuses[] = $element->getText();
        }
        
        return $statuses;
    }
    
    /**
     * Фильтр по статусу
     */
    public function filterByStatus($status)
    {
        $select = new WebDriverSelect($this->findElement($this->statusFilter));
        $select->selectByVisibleText($status);
        $this->waitForElement($this->orderRows);
        return $this;
    }
    
    /**
     * Поиск по тексту
     */
    public function search($text)
    {
        $this->type($this->searchInput, $text);
        $this->waitForElement($this->orderRows);
        return $this;
    }
    
    /**
     * Отменить первый заказ
     */
    public function cancelFirstOrder()
    {
        $cancelButtons = $this->driver->findElements($this->cancelButtons);
        if (count($cancelButtons) > 0) {
            $cancelButtons[0]->click();
            $this->driver->switchTo()->alert()->accept();
            $this->waitForElementToDisappear($cancelButtons[0]);
            $this->logger->info("Заказ отменен");
        }
        return $this;
    }
    
    /**
     * Просмотреть первый заказ
     */
    public function viewFirstOrder()
    {
        $viewButtons = $this->driver->findElements($this->viewButtons);
        if (count($viewButtons) > 0) {
            $viewButtons[0]->click();
        }
        return $this;
    }
    
    /**
     * Перейти к созданию заказа
     */
    public function goToCreateOrder()
    {
        $this->click($this->createOrderButton);
        return new CreateOrderPage($this->driver, $this->config);
    }
    
    /**
     * Проверить наличие заказа с текстом
     */
    public function hasOrderWithText($text)
    {
        $orders = $this->getOrders();
        foreach ($orders as $order) {
            if (strpos($order, $text) !== false) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Проверить, что заказов нет
     */
    public function isEmpty()
    {
        return $this->isElementVisible($this->emptyState);
    }
    
    /**
     * Проверить, что на странице заказов
     */
    public function isOnPage()
    {
        return $this->isElementVisible($this->createOrderButton) || 
               $this->isElementVisible($this->emptyState);
    }
}