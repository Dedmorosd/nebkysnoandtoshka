<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;

class LoginPage extends BasePage
{
    protected $url = '/login.php';
    
    // Селекторы
    private $usernameInput = WebDriverBy::name('username');
    private $passwordInput = WebDriverBy::name('password');
    private $loginButton = WebDriverBy::xpath("//button[@type='submit']");
    private $registerLink = WebDriverBy::linkText('Регистрация');
    private $errorMessage = WebDriverBy::className('alert-danger');
    private $successMessage = WebDriverBy::className('alert-success');
    private $forgotPasswordLink = WebDriverBy::linkText('Забыли пароль?');
    
    /**
     * Выполнить вход
     */
    public function login($username, $password)
    {
        $this->logger->info("Попытка входа: $username");
        
        $this->open()
             ->setUsername($username)
             ->setPassword($password)
             ->submit();
        
        return new DashboardPage($this->driver, $this->config);
    }
    
    /**
     * Ввести логин
     */
    public function setUsername($username)
    {
        $this->type($this->usernameInput, $username);
        return $this;
    }
    
    /**
     * Ввести пароль
     */
    public function setPassword($password)
    {
        $this->type($this->passwordInput, $password);
        return $this;
    }
    
    /**
     * Нажать кнопку входа
     */
    public function submit()
    {
        $this->click($this->loginButton);
        return $this;
    }
    
    /**
     * Перейти на страницу регистрации
     */
    public function goToRegister()
    {
        $this->click($this->registerLink);
        return new RegisterPage($this->driver, $this->config);
    }
    
    /**
     * Перейти на страницу восстановления пароля
     */
    public function goToForgotPassword()
    {
        $this->click($this->forgotPasswordLink);
        return $this;
    }
    
    /**
     * Получить сообщение об ошибке
     */
    public function getErrorMessage()
    {
        if ($this->isElementVisible($this->errorMessage, 3)) {
            return $this->getText($this->errorMessage);
        }
        return null;
    }
    
    /**
     * Есть ли ошибка
     */
    public function hasError()
    {
        return $this->isElementVisible($this->errorMessage);
    }
    
    /**
     * Есть ли успешное сообщение
     */
    public function hasSuccess()
    {
        return $this->isElementVisible($this->successMessage);
    }
    
    /**
     * Проверить, что на странице входа
     */
    public function isOnPage()
    {
        return $this->isElementVisible($this->loginButton);
    }
}
