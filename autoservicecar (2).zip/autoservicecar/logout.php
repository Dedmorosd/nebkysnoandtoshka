<?php
// Принудительно завершаем сессию
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Очищаем все данные сессии
$_SESSION = array();

// Удаляем cookie сессии
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Уничтожаем сессию
session_destroy();

// Перенаправляем на главную
header('Location: index.php');
exit();
?>