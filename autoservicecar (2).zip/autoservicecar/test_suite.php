 <?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Только администратор может запускать тесты
checkAdmin();

$pageTitle = "Тестирование системы";
$user_id = $_SESSION['user_id'];

require_once 'includes/header.php';
?>

<style>
    :root {
        --primary: #4361ee;
        --success: #06d6a0;
        --danger: #ef476f;
        --warning: #ffd166;
        --dark: #073b4c;
        --light: #f8f9fa;
    }
    
    .test-container {
        max-width: 1400px;
        margin: 30px auto;
    }
    
    .test-header {
        background: linear-gradient(135deg, var(--primary), #3a0ca3);
        color: white;
        padding: 30px;
        border-radius: 15px;
        margin-bottom: 30px;
        box-shadow: 0 10px 30px rgba(67, 97, 238, 0.3);
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 25px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        transition: all 0.3s;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .stat-value {
        font-size: 3em;
        font-weight: 700;
        color: var(--dark);
    }
    
    .stat-label {
        color: #666;
        font-size: 0.9em;
        text-transform: uppercase;
    }
    
    .test-actions {
        display: flex;
        gap: 15px;
        margin-bottom: 30px;
        flex-wrap: wrap;
    }
    
    .test-btn {
        padding: 15px 30px;
        border: none;
        border-radius: 10px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-size: 1.1em;
    }
    
    .btn-primary {
        background: var(--primary);
        color: white;
    }
    
    .btn-success {
        background: var(--success);
        color: white;
    }
    
    .btn-danger {
        background: var(--danger);
        color: white;
    }
    
    .btn-warning {
        background: var(--warning);
        color: var(--dark);
    }
    
    .test-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .test-progress {
        background: linear-gradient(135deg, #f5f7fa, #e9ecef);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 30px;
        display: none;
    }
    
    .progress {
        height: 30px;
        border-radius: 15px;
        margin-top: 10px;
    }
    
    .progress-bar {
        background: linear-gradient(90deg, var(--primary), var(--success));
        color: white;
        font-weight: 600;
        line-height: 30px;
    }
    
    .test-suite {
        background: white;
        border-radius: 15px;
        margin-bottom: 20px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    }
    
    .suite-header {
        padding: 20px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background 0.3s;
    }
    
    .suite-header:hover {
        background: rgba(67, 97, 238, 0.05);
    }
    
    .suite-title {
        font-size: 1.3em;
        font-weight: 600;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .suite-badge {
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: 600;
    }
    
    .badge-pass {
        background: var(--success);
        color: white;
    }
    
    .badge-fail {
        background: var(--danger);
        color: white;
    }
    
    .badge-pending {
        background: #e9ecef;
        color: #666;
    }
    
    .suite-stats {
        display: flex;
        gap: 20px;
        align-items: center;
    }
    
    .suite-body {
        padding: 20px;
        border-top: 1px solid #e9ecef;
        display: none;
    }
    
    .test-row {
        padding: 15px;
        margin-bottom: 10px;
        border-radius: 10px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .test-row.pass {
        background: rgba(6, 214, 160, 0.1);
        border-left: 4px solid var(--success);
    }
    
    .test-row.fail {
        background: rgba(239, 71, 111, 0.1);
        border-left: 4px solid var(--danger);
    }
    
    .test-name {
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .test-time {
        color: #666;
        font-size: 0.9em;
    }
    
    .test-message {
        color: #666;
        font-size: 0.95em;
        margin-top: 5px;
    }
    
    .log-container {
        background: var(--dark);
        color: #0f0;
        padding: 20px;
        border-radius: 10px;
        font-family: 'Courier New', monospace;
        max-height: 400px;
        overflow-y: auto;
        margin-top: 30px;
    }
    
    .log-line {
        margin: 5px 0;
        font-size: 0.9em;
    }
    
    .log-time {
        color: #0ff;
        margin-right: 10px;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
    
    .running {
        animation: pulse 1.5s infinite;
    }
    
    .spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255,255,255,0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>

<div class="container-fluid test-container">
    <div class="test-header">
        <h1><i class="fas fa-flask"></i> Система тестирования автосервиса</h1>
        <p class="mb-0">Автоматическая проверка всех компонентов системы</p>
    </div>
    
    <div class="stats-grid" id="stats">
        <div class="stat-card">
            <i class="fas fa-vial fa-2x mb-3" style="color: var(--primary)"></i>
            <div class="stat-value" id="totalTests">0</div>
            <div class="stat-label">Всего тестов</div>
        </div>
        <div class="stat-card">
            <i class="fas fa-check-circle fa-2x mb-3" style="color: var(--success)"></i>
            <div class="stat-value" id="passedTests">0</div>
            <div class="stat-label">Пройдено</div>
        </div>
        <div class="stat-card">
            <i class="fas fa-times-circle fa-2x mb-3" style="color: var(--danger)"></i>
            <div class="stat-value" id="failedTests">0</div>
            <div class="stat-label">Ошибок</div>
        </div>
        <div class="stat-card">
            <i class="fas fa-clock fa-2x mb-3" style="color: var(--warning)"></i>
            <div class="stat-value" id="totalTime">0</div>
            <div class="stat-label">Время (ms)</div>
        </div>
        <div class="stat-card">
            <i class="fas fa-chart-pie fa-2x mb-3" style="color: var(--dark)"></i>
            <div class="stat-value" id="successRate">0%</div>
            <div class="stat-label">Успешность</div>
        </div>
    </div>
    
    <div class="test-actions">
        <button class="test-btn btn-primary" onclick="runAllTests()">
            <i class="fas fa-play"></i> Запустить все тесты
        </button>
        <button class="test-btn btn-success" onclick="runSuite('database')">
            <i class="fas fa-database"></i> База данных
        </button>
        <button class="test-btn btn-success" onclick="runSuite('auth')">
            <i class="fas fa-key"></i> Авторизация
        </button>
        <button class="test-btn btn-success" onclick="runSuite('cars')">
            <i class="fas fa-car"></i> Автомобили
        </button>
        <button class="test-btn btn-success" onclick="runSuite('orders')">
            <i class="fas fa-clipboard-list"></i> Заказы
        </button>
        <button class="test-btn btn-success" onclick="runSuite('security')">
            <i class="fas fa-shield-alt"></i> Безопасность
        </button>
        <button class="test-btn btn-warning" onclick="toggleLogs()">
            <i class="fas fa-terminal"></i> Показать логи
        </button>
        <button class="test-btn btn-danger" onclick="clearResults()">
            <i class="fas fa-trash"></i> Очистить
        </button>
    </div>
    
    <div class="test-progress" id="testProgress">
        <div class="d-flex justify-content-between mb-2">
            <span id="currentTest">Подготовка...</span>
            <span id="progressPercent">0%</span>
        </div>
        <div class="progress">
            <div class="progress-bar" id="progressBar" style="width: 0%;">0%</div>
        </div>
    </div>
    
    <div id="testResults"></div>
    
    <div class="log-container" id="logContainer" style="display: none;">
        <div class="d-flex justify-content-between mb-3">
            <h5 style="color: white;"><i class="fas fa-terminal"></i> Лог выполнения</h5>
            <button class="btn btn-sm btn-outline-light" onclick="clearLog()">Очистить лог</button>
        </div>
        <div id="logContent"></div>
    </div>
</div>

<script>
let currentLogs = [];

function runAllTests() {
    runTest('all');
}

function runSuite(suite) {
    runTest(suite);
}

function runTest(suite) {
    showProgress();
    
    document.getElementById('testResults').innerHTML = '';
    addLog('🚀 Запуск тестов: ' + suite);
    
    fetch('test_runner.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'action=run&suite=' + suite
    })
    .then(response => response.json())
    .then(data => {
        hideProgress();
        displayResults(data);
        updateStats(data.summary);
        
        data.logs.forEach(log => addLog(log.message));
        addLog('✅ Тесты завершены за ' + data.total_time + 'ms');
        
        if (data.summary.failed > 0) {
            addLog('❌ Обнаружены ошибки: ' + data.summary.failed, 'error');
        } else {
            addLog('🎉 Все тесты пройдены успешно!', 'success');
        }
    })
    .catch(error => {
        hideProgress();
        addLog('❌ Ошибка: ' + error, 'error');
    });
}

function displayResults(data) {
    const container = document.getElementById('testResults');
    container.innerHTML = '';
    
    for (let [key, suite] of Object.entries(data.suites)) {
        const suiteDiv = document.createElement('div');
        suiteDiv.className = 'test-suite';
        
        const passed = suite.passed;
        const failed = suite.failed;
        const status = failed === 0 ? 'pass' : 'fail';
        
        suiteDiv.innerHTML = `
            <div class="suite-header" onclick="toggleSuite(this)">
                <div class="suite-title">
                    <i class="fas ${getSuiteIcon(key)}"></i>
                    ${suite.name}
                    <span class="suite-badge ${status === 'pass' ? 'badge-pass' : 'badge-fail'}">
                        ${status === 'pass' ? '✓' : '✗'}
                    </span>
                </div>
                <div class="suite-stats">
                    <span>✓ ${suite.passed}</span>
                    <span>✗ ${suite.failed}</span>
                    <span>⏱️ ${suite.total}</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
            </div>
            <div class="suite-body">
                ${suite.tests.map(test => `
                    <div class="test-row ${test.status}">
                        <div>
                            <div class="test-name">
                                <i class="fas ${test.status === 'pass' ? 'fa-check-circle' : 'fa-times-circle'}" 
                                   style="color: ${test.status === 'pass' ? 'var(--success)' : 'var(--danger)'}"></i>
                                ${test.name}
                            </div>
                            <div class="test-message">${test.message}</div>
                        </div>
                        <div class="test-time">${test.time}ms</div>
                    </div>
                `).join('')}
            </div>
        `;
        
        container.appendChild(suiteDiv);
    }
}

function getSuiteIcon(suite) {
    const icons = {
        'database': 'fa-database',
        'auth': 'fa-key',
        'cars': 'fa-car',
        'orders': 'fa-clipboard-list',
        'security': 'fa-shield-alt'
    };
    return icons[suite] || 'fa-flask';
}

function toggleSuite(header) {
    const body = header.nextElementSibling;
    const icon = header.querySelector('.fa-chevron-down');
    
    if (body.style.display === 'none' || body.style.display === '') {
        body.style.display = 'block';
        icon.style.transform = 'rotate(180deg)';
    } else {
        body.style.display = 'none';
        icon.style.transform = '';
    }
}

function updateStats(summary) {
    document.getElementById('totalTests').textContent = summary.total;
    document.getElementById('passedTests').textContent = summary.passed;
    document.getElementById('failedTests').textContent = summary.failed;
    document.getElementById('successRate').textContent = summary.success_rate + '%';
}

function showProgress() {
    document.getElementById('testProgress').style.display = 'block';
    let percent = 0;
    const interval = setInterval(() => {
        if (percent < 90) {
            percent += Math.random() * 10;
            if (percent > 90) percent = 90;
            updateProgress(percent);
        }
    }, 300);
    
    window.progressInterval = interval;
}

function hideProgress() {
    clearInterval(window.progressInterval);
    updateProgress(100);
    setTimeout(() => {
        document.getElementById('testProgress').style.display = 'none';
        document.getElementById('progressBar').style.width = '0%';
        document.getElementById('progressBar').textContent = '0%';
        document.getElementById('progressPercent').textContent = '0%';
    }, 500);
}

function updateProgress(percent) {
    document.getElementById('progressBar').style.width = percent + '%';
    document.getElementById('progressBar').textContent = Math.round(percent) + '%';
    document.getElementById('progressPercent').textContent = Math.round(percent) + '%';
}

function addLog(message, type = 'info') {
    const logContent = document.getElementById('logContent');
    const time = new Date().toLocaleTimeString();
    
    const logLine = document.createElement('div');
    logLine.className = 'log-line';
    logLine.innerHTML = `<span class="log-time">[${time}]</span> ${message}`;
    
    if (type === 'error') logLine.style.color = '#f66';
    if (type === 'success') logLine.style.color = '#6f6';
    
    logContent.appendChild(logLine);
    logContent.scrollTop = logContent.scrollHeight;
    
    currentLogs.push({ time, message, type });
}

function toggleLogs() {
    const container = document.getElementById('logContainer');
    if (container.style.display === 'none') {
        container.style.display = 'block';
    } else {
        container.style.display = 'none';
    }
}

function clearLog() {
    document.getElementById('logContent').innerHTML = '';
    currentLogs = [];
}

function clearResults() {
    if (confirm('Очистить все результаты тестов?')) {
        document.getElementById('testResults').innerHTML = '';
        document.getElementById('stats').innerHTML = `
            <div class="stat-card">
                <div class="stat-value" id="totalTests">0</div>
                <div class="stat-label">Всего тестов</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="passedTests">0</div>
                <div class="stat-label">Пройдено</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="failedTests">0</div>
                <div class="stat-label">Ошибок</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="totalTime">0</div>
                <div class="stat-label">Время</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="successRate">0%</div>
                <div class="stat-label">Успешность</div>
            </div>
        `;
        clearLog();
        addLog('🧹 Результаты очищены');
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>
