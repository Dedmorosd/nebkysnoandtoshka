<?php
namespace Tests;

class DatabaseTest extends BaseTest {
    protected $name = "База данных";
    
    public function testConnection() {
        $result = $this->pdo->query("SELECT 1")->fetch();
        $this->assertTrue($result !== false, "Не удалось выполнить запрос к БД");
    }
    
    public function testUsersTable() {
        $tables = $this->pdo->query("SHOW TABLES LIKE 'users'")->rowCount();
        $this->assertTrue($tables > 0, "Таблица users не существует");
        
        $columns = $this->pdo->query("DESCRIBE users")->fetchAll();
        $required = ['id', 'username', 'password', 'email', 'role'];
        
        foreach ($required as $field) {
            $found = false;
            foreach ($columns as $col) {
                if ($col['Field'] == $field) $found = true;
            }
            $this->assertTrue($found, "Поле '$field' отсутствует в таблице users");
        }
    }
    
    public function testClientsTable() {
        $tables = $this->pdo->query("SHOW TABLES LIKE 'clients'")->rowCount();
        $this->assertTrue($tables > 0, "Таблица clients не существует");
        
        $columns = $this->pdo->query("DESCRIBE clients")->fetchAll();
        $required = ['id', 'user_id', 'full_name', 'phone'];
        
        foreach ($required as $field) {
            $found = false;
            foreach ($columns as $col) {
                if ($col['Field'] == $field) $found = true;
            }
            $this->assertTrue($found, "Поле '$field' отсутствует в таблице clients");
        }
    }
    
    public function testCarsTable() {
        $tables = $this->pdo->query("SHOW TABLES LIKE 'cars'")->rowCount();
        $this->assertTrue($tables > 0, "Таблица cars не существует");
        
        $columns = $this->pdo->query("DESCRIBE cars")->fetchAll();
        $required = ['id', 'client_id', 'brand', 'model', 'license_plate'];
        
        foreach ($required as $field) {
            $found = false;
            foreach ($columns as $col) {
                if ($col['Field'] == $field) $found = true;
            }
            $this->assertTrue($found, "Поле '$field' отсутствует в таблице cars");
        }
    }
    
    public function testOrdersTable() {
        $tables = $this->pdo->query("SHOW TABLES LIKE 'orders'")->rowCount();
        $this->assertTrue($tables > 0, "Таблица orders не существует");
        
        $columns = $this->pdo->query("DESCRIBE orders")->fetchAll();
        $required = ['id', 'client_id', 'car_id', 'status', 'created_at'];
        
        foreach ($required as $field) {
            $found = false;
            foreach ($columns as $col) {
                if ($col['Field'] == $field) $found = true;
            }
            $this->assertTrue($found, "Поле '$field' отсутствует в таблице orders");
        }
    }
    
    public function testServicesTable() {
        $tables = $this->pdo->query("SHOW TABLES LIKE 'services'")->rowCount();
        $this->assertTrue($tables > 0, "Таблица services не существует");
        
        $columns = $this->pdo->query("DESCRIBE services")->fetchAll();
        $required = ['id', 'name', 'price', 'duration'];
        
        foreach ($required as $field) {
            $found = false;
            foreach ($columns as $col) {
                if ($col['Field'] == $field) $found = true;
            }
            $this->assertTrue($found, "Поле '$field' отсутствует в таблице services");
        }
    }
    
    public function testForeignKeys() {
        // Проверка внешних ключей
        $fkQuery = "
            SELECT 
                k.CONSTRAINT_NAME,
                k.TABLE_NAME,
                k.COLUMN_NAME,
                k.REFERENCED_TABLE_NAME,
                k.REFERENCED_COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE k
            WHERE k.REFERENCED_TABLE_SCHEMA = ?
                AND k.TABLE_SCHEMA = ?
        ";
        
        $stmt = $this->pdo->prepare($fkQuery);
        $stmt->execute(['project_Karachkin', 'project_Karachkin']);
        $foreignKeys = $stmt->fetchAll();
        
        $this->assertTrue(count($foreignKeys) > 0, "Нет внешних ключей в базе данных");
    }
}
