<?php
namespace Tests;

class OrdersTest extends BaseTest {
    protected $name = "Заказы";
    private $testClientId = null;
    private $testCarId = null;
    private $testServiceIds = [];
    
    public function setUp() {
        // Создаем тестового клиента
        $stmt = $this->pdo->prepare("
            INSERT INTO users (username, password, email, full_name, role) 
            VALUES (?, ?, ?, ?, 'client')
        ");
        
        $username = 'test_order_user_' . time();
        $hash = password_hash('test123', PASSWORD_DEFAULT);
        $stmt->execute([$username, $hash, $username . '@test.com', 'Test Order User']);
        $userId = $this->pdo->lastInsertId();
        
        $stmt = $this->pdo->prepare("INSERT INTO clients (user_id, full_name, phone) VALUES (?, ?, ?)");
        $stmt->execute([$userId, 'Test Order User', '+79991234567']);
        $this->testClientId = $this->pdo->lastInsertId();
        
        // Создаем тестовый автомобиль
        $stmt = $this->pdo->prepare("
            INSERT INTO cars (client_id, brand, model, year, license_plate) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$this->testClientId, 'Toyota', 'Camry', 2020, 'ORDER001']);
        $this->testCarId = $this->pdo->lastInsertId();
        
        // Создаем тестовые услуги
        $services = [
            ['Замена масла', 2500, 60],
            ['Диагностика', 1500, 30],
            ['Шиномонтаж', 2000, 45]
        ];
        
        foreach ($services as $s) {
            $stmt = $this->pdo->prepare("
                INSERT INTO services (name, price, duration, category) 
                VALUES (?, ?, ?, 'Тест')
            ");
            $stmt->execute([$s[0], $s[1], $s[2]]);
            $this->testServiceIds[] = $this->pdo->lastInsertId();
        }
    }
    
    public function tearDown() {
        // Очищаем тестовые данные
        if ($this->testClientId) {
            $this->pdo->prepare("DELETE FROM order_services WHERE order_id IN (SELECT id FROM orders WHERE client_id = ?)")
                ->execute([$this->testClientId]);
            $this->pdo->prepare("DELETE FROM orders WHERE client_id = ?")->execute([$this->testClientId]);
            $this->pdo->prepare("DELETE FROM cars WHERE id = ?")->execute([$this->testCarId]);
            
            $stmt = $this->pdo->prepare("SELECT user_id FROM clients WHERE id = ?");
            $stmt->execute([$this->testClientId]);
            $client = $stmt->fetch();
            
            if ($client) {
                $this->pdo->prepare("DELETE FROM clients WHERE id = ?")->execute([$this->testClientId]);
                $this->pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$client['user_id']]);
            }
        }
        
        foreach ($this->testServiceIds as $serviceId) {
            $this->pdo->prepare("DELETE FROM services WHERE id = ?")->execute([$serviceId]);
        }
    }
    
    public function testCreateOrder() {
        $orderData = [
            'client_id' => $this->testClientId,
            'car_id' => $this->testCarId,
            'description' => 'Тестовый заказ',
            'preferred_date' => date('Y-m-d', strtotime('+1 day')),
            'status' => 'new'
        ];
        
        $stmt = $this->pdo->prepare("
            INSERT INTO orders (client_id, car_id, description, preferred_date, status) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $orderData['client_id'],
            $orderData['car_id'],
            $orderData['description'],
            $orderData['preferred_date'],
            $orderData['status']
        ]);
        
        $this->assertTrue($result, "Не удалось создать заказ");
        $orderId = $this->pdo->lastInsertId();
        
        // Проверяем что заказ создан
        $stmt = $this->pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();
        
        $this->assertNotNull($order, "Заказ не найден после создания");
        $this->assertEquals('new', $order['status'], "Статус заказа не 'new'");
        
        // Очищаем
        $this->pdo->prepare("DELETE FROM orders WHERE id = ?")->execute([$orderId]);
    }
    
    public function testAddServicesToOrder() {
        // Создаем заказ
        $stmt = $this->pdo->prepare("
            INSERT INTO orders (client_id, car_id, preferred_date, status) 
            VALUES (?, ?, ?, 'new')
        ");
        $stmt->execute([$this->testClientId, $this->testCarId, date('Y-m-d', strtotime('+1 day'))]);
        $orderId = $this->pdo->lastInsertId();
        
        // Добавляем услуги
        $totalPrice = 0;
        foreach ($this->testServiceIds as $serviceId) {
            $stmt = $this->pdo->prepare("SELECT price FROM services WHERE id = ?");
            $stmt->execute([$serviceId]);
            $price = $stmt->fetchColumn();
            
            $stmt = $this->pdo->prepare("
                INSERT INTO order_services (order_id, service_id, price_at_time) 
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$orderId, $serviceId, $price]);
            
            $totalPrice += $price;
        }
        
        // Обновляем общую сумму
        $stmt = $this->pdo->prepare("UPDATE orders SET total_price = ? WHERE id = ?");
        $stmt->execute([$totalPrice, $orderId]);
        
        // Проверяем что услуги добавились
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM order_services WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $count = $stmt->fetchColumn();
        
        $this->assertEquals(count($this->testServiceIds), $count, "Не все услуги добавились к заказу");
        
        // Проверяем общую сумму
        $stmt = $this->pdo->prepare("SELECT total_price FROM orders WHERE id = ?");
        $stmt->execute([$orderId]);
        $dbTotal = $stmt->fetchColumn();
        
        $this->assertEquals($totalPrice, $dbTotal, "Общая сумма заказа не совпадает");
        
        // Очищаем
        $this->pdo->prepare("DELETE FROM order_services WHERE order_id = ?")->execute([$orderId]);
        $this->pdo->prepare("DELETE FROM orders WHERE id = ?")->execute([$orderId]);
    }
    
    public function testOrderStatusFlow() {
        // Создаем заказ
        $stmt = $this->pdo->prepare("
            INSERT INTO orders (client_id, car_id, preferred_date, status) 
            VALUES (?, ?, ?, 'new')
        ");
        $stmt->execute([$this->testClientId, $this->testCarId, date('Y-m-d', strtotime('+1 day'))]);
        $orderId = $this->pdo->lastInsertId();
        
        $statuses = ['new', 'in_progress', 'completed', 'cancelled'];
        
        foreach ($statuses as $status) {
            $stmt = $this->pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
            $stmt->execute([$status, $orderId]);
            
            $stmt = $this->pdo->prepare("SELECT status FROM orders WHERE id = ?");
            $stmt->execute([$orderId]);
            $currentStatus = $stmt->fetchColumn();
            
            $this->assertEquals($status, $currentStatus, "Статус не изменился на '$status'");
        }
        
        // Очищаем
        $this->pdo->prepare("DELETE FROM orders WHERE id = ?")->execute([$orderId]);
    }
}
