<?php
namespace Tests;

class SecurityTest extends BaseTest {
    protected $name = "Безопасность";
    
    public function testSQLInjection() {
        // Попытка SQL-инъекции
        $malicious = "'; DROP TABLE users; --";
        
        // Должно быть экранировано или использовать подготовленные запросы
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ?");
        $result = $stmt->execute([$malicious]);
        
        $this->assertTrue($result, "SQL запрос с потенциальной инъекцией не должен ломаться");
        
        // Проверяем что таблица users все еще существует
        $tables = $this->pdo->query("SHOW TABLES LIKE 'users'")->rowCount();
        $this->assertTrue($tables > 0, "Таблица users была удалена через SQL-инъекцию");
    }
    
    public function testXSSProtection() {
        // Проверка что XSS атаки не проходят
        $xss = "<script>alert('XSS')</script>";
        
        // Экранирование при вставке
        $username = 'xss_test_' . time();
        $hash = password_hash('test123', PASSWORD_DEFAULT);
        
        $stmt = $this->pdo->prepare("
            INSERT INTO users (username, password, email, full_name, role) 
            VALUES (?, ?, ?, ?, 'client')
        ");
        $stmt->execute([$username, $hash, $username . '@test.com', $xss]);
        
        // Проверяем что данные сохранены как есть (не выполнены)
        $stmt = $this->pdo->prepare("SELECT full_name FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $savedXss = $stmt->fetchColumn();
        
        $this->assertEquals($xss, $savedXss, "XSS данные должны сохраняться как есть");
        
        // При выводе они должны экранироваться, но это проверяется на уровне приложения
        
        // Очищаем
        $this->pdo->prepare("DELETE FROM users WHERE username = ?")->execute([$username]);
    }
    
    public function testPasswordHashingStrength() {
        $password = 'SecurePass123!@#';
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        // Проверяем что хеш начинается с правильного алгоритма
        $info = password_get_info($hash);
        $this->assertEquals(PASSWORD_DEFAULT, $info['algo'], "Используется неправильный алгоритм хеширования");
        
        // Проверяем что пароль не хранится в открытом виде
        $this->assertNotEquals($password, $hash, "Пароль хранится в открытом виде!");
        
        // Проверяем длину хеша (должна быть значительной)
        $this->assertTrue(strlen($hash) > 20, "Хеш пароля слишком короткий");
    }
    
    public function testCsrfProtection() {
        // Проверка наличия CSRF токенов в формах
        $loginContent = @file_get_contents('../login.php');
        $registerContent = @file_get_contents('../register.php');
        
        if ($loginContent) {
            $hasCsrf = strpos($loginContent, 'csrf_token') !== false;
            // Не обязательно, но рекомендуется
            // $this->assertTrue($hasCsrf, "Форма входа не имеет CSRF защиты");
        }
    }
    
    public function testSessionSecurity() {
        // Проверка настроек сессии
        $sessionName = session_name();
        $this->assertNotEmpty($sessionName, "Имя сессии не установлено");
        
        // Проверка что сессия не передается через URL
        $this->assertTrue(ini_get('session.use_only_cookies'), "Сессия может передаваться через URL");
        
        // Проверка httponly для cookie сессии
        // Это сложно проверить в тесте, но можно рекомендовать
    }
    
    public function testFilePermissions() {
        // Проверка прав доступа к критическим файлам
        $criticalFiles = [
            '../config/database.php',
            '../includes/auth.php'
        ];
        
        foreach ($criticalFiles as $file) {
            if (file_exists($file)) {
                $perms = fileperms($file);
                // Проверяем что файл не доступен для записи всем
                $isWorldWritable = ($perms & 0x0002) != 0;
                $this->assertFalse($isWorldWritable, "Файл $file доступен для записи всем!");
            }
        }
    }
}
