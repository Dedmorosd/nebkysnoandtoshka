<?php
namespace Tests;

// Базовый класс для всех тестов
abstract class BaseTest {
    protected $pdo;
    protected $name;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function getName() {
        return $this->name;
    }
    
    public function setUp() {}
    public function tearDown() {}
    
    protected function assertTrue($condition, $message = '') {
        if (!$condition) {
            throw new \Exception($message ?: 'Assertion failed: expected true');
        }
    }
    
    protected function assertFalse($condition, $message = '') {
        if ($condition) {
            throw new \Exception($message ?: 'Assertion failed: expected false');
        }
    }
    
    protected function assertEquals($expected, $actual, $message = '') {
        if ($expected != $actual) {
            throw new \Exception($message ?: "Assertion failed: expected '$expected', got '$actual'");
        }
    }
    
    protected function assertNotEquals($expected, $actual, $message = '') {
        if ($expected == $actual) {
            throw new \Exception($message ?: "Assertion failed: expected not equal to '$expected'");
        }
    }
    
    protected function assertNotNull($value, $message = '') {
        if ($value === null) {
            throw new \Exception($message ?: 'Assertion failed: expected not null');
        }
    }
    
    protected function assertNotEmpty($value, $message = '') {
        if (empty($value)) {
            throw new \Exception($message ?: 'Assertion failed: expected not empty');
        }
    }
}

class TestRunner {
    private $results = [];
    private $logs = [];
    private $startTime;
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function runAllTests() {
        $this->startTime = microtime(true);
        $this->log("🚀 ЗАПУСК ВСЕХ ТЕСТОВ");
        
        // Проверяем существование классов
        $testClasses = [
            'database' => 'Tests\\DatabaseTest',
            'auth' => 'Tests\\AuthTest',
            'cars' => 'Tests\\CarsTest',
            'orders' => 'Tests\\OrdersTest',
            'security' => 'Tests\\SecurityTest'
        ];
        
        foreach ($testClasses as $name => $class) {
            if (class_exists($class)) {
                $test = new $class($this->pdo);
                $this->runTestSuite($name, $test);
            } else {
                $this->log("⚠️ Класс $class не найден");
            }
        }
        
        $totalTime = round((microtime(true) - $this->startTime) * 1000);
        $this->log("✅ Все тесты завершены за {$totalTime}ms");
        
        return $this->getResults();
    }
    
    public function runSuite($suite) {
        $this->startTime = microtime(true);
        $this->log("📋 Запуск набора тестов: $suite");
        
        $class = 'Tests\\' . ucfirst($suite) . 'Test';
        
        if (!class_exists($class)) {
            $this->log("❌ Класс $class не найден");
            return ['error' => "Test suite $suite not found"];
        }
        
        $test = new $class($this->pdo);
        $this->runTestSuite($suite, $test);
        
        $totalTime = round((microtime(true) - $this->startTime) * 1000);
        $this->log("✅ Тесты завершены за {$totalTime}ms");
        
        return $this->getResults();
    }
    
    public function runSingleTest($suite, $method) {
        $this->startTime = microtime(true);
        $this->log("🎯 Запуск отдельного теста: $suite::$method");
        
        $class = 'Tests\\' . ucfirst($suite) . 'Test';
        
        if (!class_exists($class)) {
            return ['error' => "Test class $class not found"];
        }
        
        $test = new $class($this->pdo);
        $test->setUp();
        
        $start = microtime(true);
        try {
            $test->$method();
            $status = 'pass';
            $message = 'Тест пройден успешно';
        } catch (\Exception $e) {
            $status = 'fail';
            $message = $e->getMessage();
            $this->log("    ✗ Ошибка: " . $e->getMessage());
        }
        $time = round((microtime(true) - $start) * 1000);
        
        $test->tearDown();
        
        $this->results[$suite] = [
            'name' => $test->getName(),
            'tests' => [[
                'name' => $this->formatTestName($method),
                'method' => $method,
                'status' => $status,
                'message' => $message,
                'time' => $time
            ]],
            'passed' => $status === 'pass' ? 1 : 0,
            'failed' => $status === 'fail' ? 1 : 0,
            'total' => 1
        ];
        
        $totalTime = round((microtime(true) - $this->startTime) * 1000);
        
        return $this->getResults();
    }
    
    public function runTestSuite($name, $test) {
        $this->log("📋 Запуск набора тестов: $name");
        
        $methods = get_class_methods($test);
        $testMethods = array_filter($methods, function($method) {
            return strpos($method, 'test') === 0;
        });
        
        $suiteResults = [];
        foreach ($testMethods as $method) {
            $result = $this->executeTest($test, $method);
            $suiteResults[] = $result;
        }
        
        $this->results[$name] = [
            'name' => $test->getName(),
            'tests' => $suiteResults,
            'passed' => count(array_filter($suiteResults, fn($r) => $r['status'] === 'pass')),
            'failed' => count(array_filter($suiteResults, fn($r) => $r['status'] === 'fail')),
            'total' => count($suiteResults)
        ];
    }
    
    private function executeTest($test, $method) {
        $start = microtime(true);
        $this->log("  • Выполнение: $method");
        
        $test->setUp();
        
        try {
            $test->$method();
            $status = 'pass';
            $message = 'Тест пройден успешно';
        } catch (\Exception $e) {
            $status = 'fail';
            $message = $e->getMessage();
            $this->log("    ✗ Ошибка: " . $e->getMessage());
        }
        
        $test->tearDown();
        
        $time = round((microtime(true) - $start) * 1000);
        
        return [
            'name' => $this->formatTestName($method),
            'method' => $method,
            'status' => $status,
            'message' => $message,
            'time' => $time
        ];
    }
    
    private function formatTestName($method) {
        $name = str_replace('test', '', $method);
        $name = preg_replace('/([A-Z])/', ' $1', $name);
        return trim($name);
    }
    
    private function log($message) {
        $this->logs[] = [
            'time' => date('H:i:s'),
            'message' => $message
        ];
    }
    
    public function getResults() {
        $totalTests = 0;
        $totalPassed = 0;
        $totalFailed = 0;
        
        foreach ($this->results as $suite) {
            $totalTests += $suite['total'];
            $totalPassed += $suite['passed'];
            $totalFailed += $suite['failed'];
        }
        
        return [
            'timestamp' => date('Y-m-d H:i:s'),
            'total_time' => round((microtime(true) - ($this->startTime ?? microtime(true))) * 1000),
            'summary' => [
                'total' => $totalTests,
                'passed' => $totalPassed,
                'failed' => $totalFailed,
                'success_rate' => $totalTests > 0 ? round(($totalPassed / $totalTests) * 100) : 0
            ],
            'suites' => $this->results,
            'logs' => $this->logs
        ];
    }
}