<?php
namespace Tests;

class CarsTest extends BaseTest {
    protected $name = "Автомобили";
    private $testClientId = null;
    
    public function setUp() {
        // Создаем тестового клиента
        $stmt = $this->pdo->prepare("
            INSERT INTO users (username, password, email, full_name, role) 
            VALUES (?, ?, ?, ?, 'client')
        ");
        
        $username = 'test_car_user_' . time();
        $hash = password_hash('test123', PASSWORD_DEFAULT);
        $stmt->execute([$username, $hash, $username . '@test.com', 'Test Car User']);
        $userId = $this->pdo->lastInsertId();
        
        $stmt = $this->pdo->prepare("INSERT INTO clients (user_id, full_name, phone) VALUES (?, ?, ?)");
        $stmt->execute([$userId, 'Test Car User', '+79991234567']);
        $this->testClientId = $this->pdo->lastInsertId();
    }
    
    public function tearDown() {
        // Очищаем тестовые данные
        if ($this->testClientId) {
            $this->pdo->prepare("DELETE FROM cars WHERE client_id = ?")->execute([$this->testClientId]);
            
            $stmt = $this->pdo->prepare("SELECT user_id FROM clients WHERE id = ?");
            $stmt->execute([$this->testClientId]);
            $client = $stmt->fetch();
            
            if ($client) {
                $this->pdo->prepare("DELETE FROM clients WHERE id = ?")->execute([$this->testClientId]);
                $this->pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$client['user_id']]);
            }
        }
    }
    
    public function testAddCar() {
        $carData = [
            'client_id' => $this->testClientId,
            'brand' => 'Toyota',
            'model' => 'Camry',
            'year' => 2020,
            'license_plate' => 'A123BC777',
            'vin' => 'JTDBE32KX12345678'
        ];
        
        $stmt = $this->pdo->prepare("
            INSERT INTO cars (client_id, brand, model, year, license_plate, vin) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $carData['client_id'],
            $carData['brand'],
            $carData['model'],
            $carData['year'],
            $carData['license_plate'],
            $carData['vin']
        ]);
        
        $this->assertTrue($result, "Не удалось добавить автомобиль");
        
        // Проверяем что автомобиль добавился
        $stmt = $this->pdo->prepare("SELECT * FROM cars WHERE license_plate = ?");
        $stmt->execute([$carData['license_plate']]);
        $car = $stmt->fetch();
        
        $this->assertNotNull($car, "Автомобиль не найден после добавления");
        $this->assertEquals($carData['brand'], $car['brand'], "Марка не совпадает");
        $this->assertEquals($carData['model'], $car['model'], "Модель не совпадает");
    }
    
    public function testUniqueLicensePlate() {
        $plate = 'B456DE123';
        
        // Добавляем первый автомобиль
        $stmt = $this->pdo->prepare("
            INSERT INTO cars (client_id, brand, model, year, license_plate) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$this->testClientId, 'Toyota', 'Camry', 2020, $plate]);
        
        // Пытаемся добавить второй с таким же номером
        $caught = false;
        try {
            $stmt->execute([$this->testClientId, 'Honda', 'Accord', 2021, $plate]);
        } catch (\Exception $e) {
            $caught = true;
        }
        
        $this->assertTrue($caught, "Система позволила создать дубликат госномера");
    }
    
    public function testCarValidation() {
        // Проверка обязательных полей
        $required = ['brand', 'model', 'year', 'license_plate'];
        
        foreach ($required as $field) {
            $data = [
                'client_id' => $this->testClientId,
                'brand' => 'Test',
                'model' => 'Test',
                'year' => 2020,
                'license_plate' => 'TEST123'
            ];
            
            // Удаляем обязательное поле
            $data[$field] = null;
            
            $caught = false;
            try {
                $stmt = $this->pdo->prepare("
                    INSERT INTO cars (client_id, brand, model, year, license_plate) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $data['client_id'],
                    $data['brand'],
                    $data['model'],
                    $data['year'],
                    $data['license_plate']
                ]);
            } catch (\Exception $e) {
                $caught = true;
            }
            
            $this->assertTrue($caught, "Поле '$field' должно быть обязательным");
        }
    }
    
    public function testYearValidation() {
        $currentYear = date('Y');
        
        // Проверка что год не может быть в будущем (больше чем +1)
        $invalidYears = [1800, $currentYear + 2];
        
        foreach ($invalidYears as $year) {
            $caught = false;
            try {
                $stmt = $this->pdo->prepare("
                    INSERT INTO cars (client_id, brand, model, year, license_plate) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$this->testClientId, 'Test', 'Test', $year, 'TEST' . $year]);
            } catch (\Exception $e) {
                $caught = true;
            }
            
            $this->assertTrue($caught, "Год $year не должен быть допустимым");
        }
    }
}
