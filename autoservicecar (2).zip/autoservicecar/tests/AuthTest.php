<?php
namespace Tests;

class AuthTest extends BaseTest {
    protected $name = "Авторизация";
    
    public function testLoginPageExists() {
        $this->assertTrue(file_exists('../login.php'), "Файл login.php не найден");
    }
    
    public function testRegisterPageExists() {
        $this->assertTrue(file_exists('../register.php'), "Файл register.php не найден");
    }
    
    public function testPasswordHashing() {
        $password = 'test123';
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        $this->assertTrue(password_verify($password, $hash), "Password verify не работает");
        $this->assertFalse(password_verify('wrong', $hash), "Password verify пропустил неверный пароль");
    }
    
    public function testUserRegistration() {
        // Создаем тестового пользователя
        $username = 'test_' . time();
        $email = $username . '@test.com';
        $hash = password_hash('test123', PASSWORD_DEFAULT);
        
        $stmt = $this->pdo->prepare("
            INSERT INTO users (username, password, email, full_name, role) 
            VALUES (?, ?, ?, ?, 'client')
        ");
        
        $result = $stmt->execute([$username, $hash, $email, 'Test User']);
        $this->assertTrue($result, "Не удалось создать тестового пользователя");
        
        // Проверяем что пользователь создан
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        $this->assertNotNull($user, "Пользователь не найден после регистрации");
        $this->assertEquals($email, $user['email'], "Email не совпадает");
        
        // Очищаем тестовые данные
        $this->pdo->prepare("DELETE FROM users WHERE username = ?")->execute([$username]);
    }
    
    public function testDuplicateUser() {
        // Пытаемся создать двух пользователей с одинаковым логином
        $username = 'duplicate_test';
        $email1 = $username . '@test.com';
        $email2 = $username . '2@test.com';
        $hash = password_hash('test123', PASSWORD_DEFAULT);
        
        // Первый пользователь
        $stmt = $this->pdo->prepare("
            INSERT INTO users (username, password, email, full_name, role) 
            VALUES (?, ?, ?, ?, 'client')
        ");
        $stmt->execute([$username, $hash, $email1, 'Test User 1']);
        
        // Пытаемся создать второго с тем же логином
        $caught = false;
        try {
            $stmt->execute([$username, $hash, $email2, 'Test User 2']);
        } catch (\Exception $e) {
            $caught = true;
        }
        
        $this->assertTrue($caught, "Система позволила создать дубликат пользователя");
        
        // Очищаем
        $this->pdo->prepare("DELETE FROM users WHERE username = ?")->execute([$username]);
    }
    
    public function testRoleEnum() {
        // Проверяем что роль может быть только admin/mechanic/client
        $validRoles = ['admin', 'mechanic', 'client'];
        
        $stmt = $this->pdo->query("SHOW COLUMNS FROM users WHERE Field = 'role'");
        $column = $stmt->fetch();
        
        preg_match("/^enum\('(.*)'\)$/", $column['Type'], $matches);
        
        if (isset($matches[1])) {
            $enumValues = explode("','", $matches[1]);
            foreach ($validRoles as $role) {
                $this->assertTrue(in_array($role, $enumValues), "Роль '$role' отсутствует в enum");
            }
        }
    }
    
    public function testSessionStart() {
        // Проверяем что сессия правильно инициализируется
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $_SESSION['test'] = 'value';
        $this->assertEquals('value', $_SESSION['test'], "Сессия не работает");
        
        unset($_SESSION['test']);
    }
}
