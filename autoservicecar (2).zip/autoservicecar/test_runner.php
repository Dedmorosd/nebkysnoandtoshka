<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Только администратор
checkAdmin();

// Автозагрузка классов тестов
spl_autoload_register(function ($class) {
    $prefix = 'Tests\\';
    $base_dir = __DIR__ . '/tests/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

require_once 'tests/TestRunner.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? '';
$suite = $_POST['suite'] ?? 'all';

$runner = new Tests\TestRunner($pdo);

switch ($action) {
    case 'run':
        if ($suite === 'all') {
            $results = $runner->runAllTests();
        } else {
            $results = $runner->runSuite($suite);
        }
        echo json_encode($results);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}