<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Управление сервером базы данных";

// Получение статистики БД
$dbStats = [];
try {
    // Размер базы данных
    $stmt = $pdo->query("
        SELECT 
            table_schema AS 'database',
            ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'size_mb',
            ROUND(SUM(data_length) / 1024 / 1024, 2) AS 'data_mb',
            ROUND(SUM(index_length) / 1024 / 1024, 2) AS 'index_mb',
            COUNT(*) AS 'tables'
        FROM information_schema.tables
        WHERE table_schema = 'project_Karachkin'
        GROUP BY table_schema
    ");
    $dbStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Статистика подключений
    $stmt = $pdo->query("SHOW STATUS LIKE 'Threads_connected'");
    $connections = $stmt->fetch();
    $dbStats['connections'] = $connections['Value'];
    
    // Статистика запросов
    $stmt = $pdo->query("SHOW STATUS LIKE 'Questions'");
    $questions = $stmt->fetch();
    $dbStats['questions'] = $questions['Value'];
    
    // Время работы сервера
    $stmt = $pdo->query("SHOW STATUS LIKE 'Uptime'");
    $uptime = $stmt->fetch();
    $dbStats['uptime'] = $uptime['Value'];
    
    // Версия MySQL
    $version = $pdo->query("SELECT VERSION() as version")->fetch();
    $dbStats['version'] = $version['version'];
    
} catch (PDOException $e) {
    $error = "Ошибка получения статистики: " . $e->getMessage();
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --db-primary: #2c3e50;
        --db-success: #27ae60;
        --db-warning: #f39c12;
        --db-danger: #e74c3c;
        --db-info: #3498db;
        --db-dark: #1a1a2e;
    }
    
    .db-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .db-stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s, box-shadow 0.3s;
        border-left: 4px solid var(--db-primary);
    }
    
    .db-stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.12);
    }
    
    .db-stat-card.success { border-left-color: var(--db-success); }
    .db-stat-card.warning { border-left-color: var(--db-warning); }
    .db-stat-card.danger { border-left-color: var(--db-danger); }
    .db-stat-card.info { border-left-color: var(--db-info); }
    
    .db-stat-value {
        font-size: 2.5em;
        font-weight: 700;
        color: var(--db-dark);
        margin-bottom: 5px;
    }
    
    .db-stat-label {
        color: #7f8c8d;
        font-size: 0.9em;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .db-stat-icon {
        float: right;
        font-size: 2.5em;
        opacity: 0.3;
    }
    
    .db-actions {
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
        margin-bottom: 30px;
    }
    
    .db-btn {
        padding: 12px 25px;
        border: none;
        border-radius: 10px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
    }
    
    .db-btn-primary {
        background: linear-gradient(135deg, var(--db-primary), #34495e);
        color: white;
    }
    
    .db-btn-success {
        background: linear-gradient(135deg, var(--db-success), #219a52);
        color: white;
    }
    
    .db-btn-warning {
        background: linear-gradient(135deg, var(--db-warning), #e67e22);
        color: white;
    }
    
    .db-btn-danger {
        background: linear-gradient(135deg, var(--db-danger), #c0392b);
        color: white;
    }
    
    .db-btn-info {
        background: linear-gradient(135deg, var(--db-info), #2980b9);
        color: white;
    }
    
    .db-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .db-tables-container {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .db-tables-header {
        background: linear-gradient(135deg, var(--db-primary), #34495e);
        color: white;
        padding: 15px 20px;
        font-weight: 600;
    }
    
    .db-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .db-table th,
    .db-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .db-table th {
        background: #f8f9fa;
        font-weight: 600;
        color: var(--db-primary);
    }
    
    .db-table tr:hover {
        background: #f8f9fa;
    }
    
    .db-status {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        margin-right: 8px;
    }
    
    .db-status.up { background: var(--db-success); box-shadow: 0 0 5px var(--db-success); }
    .db-status.down { background: var(--db-danger); box-shadow: 0 0 5px var(--db-danger); }
    
    .progress {
        height: 8px;
        background: #ecf0f1;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .progress-bar {
        height: 100%;
        background: linear-gradient(90deg, var(--db-success), var(--db-info));
        border-radius: 4px;
        transition: width 0.3s;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
    
    .loading {
        animation: pulse 1.5s infinite;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 500px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: #7f8c8d;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
    }
    
    .toast.success { border-left: 4px solid var(--db-success); }
    .toast.error { border-left: 4px solid var(--db-danger); }
    .toast.info { border-left: 4px solid var(--db-info); }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-database"></i> Управление сервером базы данных
        </h1>
        <div>
            <span class="badge bg-primary">MySQL <?php echo $dbStats['version'] ?? 'N/A'; ?></span>
            <span class="badge bg-success">
                <span class="db-status up"></span> Онлайн
            </span>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="db-stats-grid">
        <div class="db-stat-card">
            <div class="db-stat-icon"><i class="fas fa-hdd"></i></div>
            <div class="db-stat-value"><?php echo number_format($dbStats['size_mb'] ?? 0, 2); ?> MB</div>
            <div class="db-stat-label">Размер базы данных</div>
            <div class="progress mt-2">
                <div class="progress-bar" style="width: <?php echo min(($dbStats['size_mb'] ?? 0) / 1000 * 100, 100); ?>%"></div>
            </div>
        </div>
        
        <div class="db-stat-card success">
            <div class="db-stat-icon"><i class="fas fa-table"></i></div>
            <div class="db-stat-value"><?php echo $dbStats['tables'] ?? 0; ?></div>
            <div class="db-stat-label">Таблиц в БД</div>
        </div>
        
        <div class="db-stat-card info">
            <div class="db-stat-icon"><i class="fas fa-plug"></i></div>
            <div class="db-stat-value"><?php echo $dbStats['connections'] ?? 0; ?></div>
            <div class="db-stat-label">Активных подключений</div>
        </div>
        
        <div class="db-stat-card warning">
            <div class="db-stat-icon"><i class="fas fa-chart-line"></i></div>
            <div class="db-stat-value"><?php echo number_format(($dbStats['questions'] ?? 0) / 1000, 1); ?>k</div>
            <div class="db-stat-label">Всего запросов</div>
        </div>
    </div>
    
    <!-- Быстрые действия -->
    <div class="db-actions">
        <button class="db-btn db-btn-primary" onclick="openModal('backup')">
            <i class="fas fa-database"></i> Создать бэкап
        </button>
        <button class="db-btn db-btn-success" onclick="openModal('restore')">
            <i class="fas fa-undo-alt"></i> Восстановить
        </button>
        <button class="db-btn db-btn-info" onclick="window.location.href='db_monitor.php'">
            <i class="fas fa-chart-line"></i> Мониторинг
        </button>
        <button class="db-btn db-btn-warning" onclick="optimizeDatabase()">
            <i class="fas fa-magic"></i> Оптимизация
        </button>
        <button class="db-btn db-btn-danger" onclick="analyzeDatabase()">
            <i class="fas fa-search"></i> Анализ таблиц
        </button>
    </div>
    
    <!-- Список таблиц -->
    <div class="db-tables-container">
        <div class="db-tables-header">
            <i class="fas fa-table me-2"></i> Таблицы базы данных
        </div>
        <div style="overflow-x: auto;">
            <table class="db-table" id="tablesTable">
                <thead>
                    <tr>
                        <th>Таблица</th>
                        <th>Тип</th>
                        <th>Количество записей</th>
                        <th>Размер данных</th>
                        <th>Размер индексов</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody id="tablesList">
                    <tr>
                        <td colspan="6" class="text-center">
                            <div class="loading">Загрузка...</div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Модальное окно бэкапа -->
<div id="backupModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-database"></i> Создание резервной копии</h5>
            <span class="close" onclick="closeModal('backupModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> Будет создана полная резервная копия базы данных.
            </div>
            <div class="mb-3">
                <label class="form-label">Тип бэкапа</label>
                <select class="form-control" id="backupType">
                    <option value="full">Полный бэкап</option>
                    <option value="structure">Только структура</option>
                    <option value="data">Только данные</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Компрессия</label>
                <select class="form-control" id="backupCompression">
                    <option value="gzip">GZIP (рекомендуется)</option>
                    <option value="none">Без компрессии</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="db-btn db-btn-secondary" onclick="closeModal('backupModal')">Отмена</button>
            <button class="db-btn db-btn-primary" onclick="createBackup()">Создать бэкап</button>
        </div>
    </div>
</div>

<!-- Модальное окно восстановления -->
<div id="restoreModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5><i class="fas fa-undo-alt"></i> Восстановление из бэкапа</h5>
            <span class="close" onclick="closeModal('restoreModal')">&times;</span>
        </div>
        <div class="modal-body">
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> 
                Восстановление заменит текущие данные. Убедитесь, что у вас есть свежий бэкап!
            </div>
            <div class="mb-3">
                <label class="form-label">Выберите файл бэкапа</label>
                <select class="form-control" id="backupFileList">
                    <option value="">Загрузка списка...</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="db-btn db-btn-secondary" onclick="closeModal('restoreModal')">Отмена</button>
            <button class="db-btn db-btn-warning" onclick="restoreBackup()">Восстановить</button>
        </div>
    </div>
</div>

<!-- Toast уведомления -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
// Загрузка списка таблиц
function loadTables() {
    fetch('../api/db_api.php?action=list_tables')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('tablesList');
            tbody.innerHTML = '';
            
            if (data.error) {
                tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">${data.error}</td></tr>`;
                return;
            }
            
            data.forEach(table => {
                const row = tbody.insertRow();
                row.innerHTML = `
                    <td><i class="fas fa-table me-2"></i> ${table.name}</td>
                    <td>${table.engine}</td>
                    <td>${Number(table.rows).toLocaleString()}</td>
                    <td>${table.data_size} MB</td>
                    <td>${table.index_size} MB</td>
                    <td>
                        <button class="btn btn-sm btn-info" onclick="optimizeTable('${table.name}')" title="Оптимизировать">
                            <i class="fas fa-magic"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="analyzeTable('${table.name}')" title="Анализировать">
                            <i class="fas fa-chart-line"></i>
                        </button>
                    </td>
                `;
            });
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('tablesList').innerHTML = 
                '<tr><td colspan="6" class="text-center text-danger">Ошибка загрузки таблиц</td></tr>';
        });
}

// Оптимизация всей базы данных
function optimizeDatabase() {
    if (confirm('Выполнить полную оптимизацию базы данных? Это может занять некоторое время.')) {
        showToast('Оптимизация запущена...', 'info');
        
        fetch('../api/db_api.php?action=optimize_all', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Оптимизация завершена успешно!', 'success');
                    loadTables();
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
            })
            .catch(error => showToast('Ошибка: ' + error, 'error'));
    }
}

// Оптимизация конкретной таблицы
function optimizeTable(tableName) {
    if (confirm(`Оптимизировать таблицу "${tableName}"?`)) {
        showToast(`Оптимизация таблицы ${tableName}...`, 'info');
        
        fetch(`../api/db_api.php?action=optimize_table&table=${tableName}`, { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(`Таблица ${tableName} оптимизирована!`, 'success');
                    loadTables();
                } else {
                    showToast('Ошибка: ' + data.error, 'error');
                }
            });
    }
}

// Анализ базы данных
function analyzeDatabase() {
    showToast('Анализ таблиц...', 'info');
    
    fetch('../api/db_api.php?action=analyze_all', { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Анализ завершен!', 'success');
                loadTables();
            } else {
                showToast('Ошибка: ' + data.error, 'error');
            }
        });
}

// Анализ конкретной таблицы
function analyzeTable(tableName) {
    showToast(`Анализ таблицы ${tableName}...`, 'info');
    
    fetch(`../api/db_api.php?action=analyze_table&table=${tableName}`, { method: 'POST' })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(`Таблица ${tableName} проанализирована!`, 'success');
            } else {
                showToast('Ошибка: ' + data.error, 'error');
            }
        });
}

// Создание бэкапа
function createBackup() {
    const type = document.getElementById('backupType').value;
    const compression = document.getElementById('backupCompression').value;
    
    showToast('Создание бэкапа...', 'info');
    
    fetch('../api/db_api.php?action=backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: type, compression: compression })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(`Бэкап создан: ${data.filename}`, 'success');
            closeModal('backupModal');
            loadBackupList();
        } else {
            showToast('Ошибка: ' + data.error, 'error');
        }
    })
    .catch(error => showToast('Ошибка: ' + error, 'error'));
}

// Загрузка списка бэкапов
function loadBackupList() {
    fetch('../api/db_api.php?action=list_backups')
        .then(response => response.json())
        .then(data => {
            const select = document.getElementById('backupFileList');
            select.innerHTML = '<option value="">Выберите файл бэкапа</option>';
            
            data.forEach(backup => {
                select.innerHTML += `<option value="${backup.filename}">${backup.filename} (${backup.size} MB, ${backup.date})</option>`;
            });
        });
}

// Восстановление из бэкапа
function restoreBackup() {
    const filename = document.getElementById('backupFileList').value;
    
    if (!filename) {
        showToast('Выберите файл бэкапа', 'error');
        return;
    }
    
    if (confirm('Восстановление заменит все данные! Продолжить?')) {
        showToast('Восстановление...', 'info');
        
        fetch('../api/db_api.php?action=restore', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: filename })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Восстановление завершено!', 'success');
                closeModal('restoreModal');
                loadTables();
            } else {
                showToast('Ошибка: ' + data.error, 'error');
            }
        });
    }
}

// Открытие модального окна
function openModal(type) {
    if (type === 'backup') {
        document.getElementById('backupModal').style.display = 'flex';
    } else if (type === 'restore') {
        loadBackupList();
        document.getElementById('restoreModal').style.display = 'flex';
    }
}

// Закрытие модального окна
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Показ уведомления
function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// Закрытие модального окна при клике вне его
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Загрузка данных при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    loadTables();
});
</script>

<?php require_once '../includes/footer.php'; ?> 
