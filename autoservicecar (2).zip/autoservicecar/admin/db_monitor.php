<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
checkAdmin();

$pageTitle = "Мониторинг базы данных";
require_once '../includes/header.php';
?>

<style>
    .monitor-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .monitor-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .monitor-title {
        font-weight: 600;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 2px solid #ecf0f1;
    }
    
    .metric {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        padding: 8px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .metric-value {
        font-weight: 600;
        color: var(--db-primary);
    }
    
    .query-log {
        max-height: 400px;
        overflow-y: auto;
        font-family: monospace;
        font-size: 12px;
    }
    
    .query-item {
        padding: 8px;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .query-time {
        color: var(--db-warning);
        font-weight: 600;
    }
</style>

<div class="container-fluid">
    <h1 class="mb-4"><i class="fas fa-chart-line"></i> Мониторинг базы данных</h1>
    
    <div class="monitor-grid">
        <div class="monitor-card">
            <div class="monitor-title">Загрузка системы</div>
            <div id="systemLoad">Загрузка...</div>
        </div>
        
        <div class="monitor-card">
            <div class="monitor-title">Активные процессы</div>
            <div id="processList">Загрузка...</div>
        </div>
        
        <div class="monitor-card">
            <div class="monitor-title">Медленные запросы</div>
            <div id="slowQueries">Загрузка...</div>
        </div>
    </div>
</div>

<script>
function updateMonitor() {
    fetch('../api/db_api.php?action=db_status')
        .then(response => response.json())
        .then(data => {
            document.getElementById('systemLoad').innerHTML = `
                <div class="metric"><span>Размер БД:</span><span class="metric-value">${data.size_mb} MB</span></div>
                <div class="metric"><span>Таблиц:</span><span class="metric-value">${data.tables}</span></div>
                <div class="metric"><span>Подключений:</span><span class="metric-value">${data.connections}</span></div>
                <div class="metric"><span>Время работы:</span><span class="metric-value">${Math.floor(data.uptime / 86400)} дн</span></div>
                <div class="metric"><span>Версия MySQL:</span><span class="metric-value">${data.version}</span></div>
            `;
        });
}

setInterval(updateMonitor, 5000);
updateMonitor();
</script>

<?php require_once '../includes/footer.php'; ?> 
