 <?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Управление корпоративной сетью";

// Получение статуса сети (имитация, в реальности данные из SNMP/API)
$networkStatus = [
    'internet' => ['status' => 'online', 'speed' => '98.5 Mbps', 'uptime' => '99.98%'],
    'vpn' => ['status' => 'online', 'connected' => '3/3 туннеля', 'latency' => '25 ms'],
    'firewall' => ['status' => 'active', 'blocked' => '127', 'rules' => '45'],
    'switches' => ['status' => 'online', 'active_ports' => '32/48', 'errors' => '0'],
    'wifi' => ['status' => 'online', 'clients' => '23', 'channels' => '2.4/5 GHz'],
    'servers' => ['status' => 'online', 'load' => '32%', 'memory' => '45%']
];

// Получение списка устройств
$devices = [
    ['name' => 'Core Router', 'ip' => '10.10.10.1', 'status' => 'online', 'type' => 'router', 'uptime' => '45d 12h'],
    ['name' => 'Core Switch', 'ip' => '10.10.10.2', 'status' => 'online', 'type' => 'switch', 'uptime' => '45d 12h'],
    ['name' => 'Firewall', 'ip' => '10.10.10.3', 'status' => 'online', 'type' => 'firewall', 'uptime' => '30d 8h'],
    ['name' => 'DB Server', 'ip' => '10.10.20.10', 'status' => 'online', 'type' => 'server', 'uptime' => '15d 3h'],
    ['name' => 'Web Server', 'ip' => '10.10.20.11', 'status' => 'online', 'type' => 'server', 'uptime' => '15d 3h'],
    ['name' => 'Access Point 1', 'ip' => '10.10.30.50', 'status' => 'online', 'type' => 'wifi', 'uptime' => '10d 0h'],
    ['name' => 'Access Point 2', 'ip' => '10.10.30.51', 'status' => 'online', 'type' => 'wifi', 'uptime' => '10d 0h'],
    ['name' => 'SPB Router', 'ip' => '10.20.10.1', 'status' => 'online', 'type' => 'router', 'uptime' => '20d 5h'],
];

require_once '../includes/header.php';
?>

<style>
    :root {
        --network-online: #27ae60;
        --network-offline: #e74c3c;
        --network-warning: #f39c12;
        --network-primary: #2c3e50;
        --network-secondary: #34495e;
    }
    
    .network-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .network-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s;
        border-left: 4px solid var(--network-primary);
    }
    
    .network-card:hover {
        transform: translateY(-5px);
    }
    
    .network-card.online { border-left-color: var(--network-online); }
    .network-card.offline { border-left-color: var(--network-offline); }
    .network-card.warning { border-left-color: var(--network-warning); }
    
    .network-card-title {
        font-size: 0.9em;
        text-transform: uppercase;
        color: #7f8c8d;
        margin-bottom: 10px;
    }
    
    .network-card-value {
        font-size: 2em;
        font-weight: 700;
        color: var(--network-primary);
        margin-bottom: 5px;
    }
    
    .network-card-detail {
        font-size: 0.85em;
        color: #95a5a6;
    }
    
    .status-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 0.8em;
        font-weight: 600;
    }
    
    .status-online {
        background: rgba(39, 174, 96, 0.2);
        color: #27ae60;
    }
    
    .status-offline {
        background: rgba(231, 76, 60, 0.2);
        color: #e74c3c;
    }
    
    .devices-table {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .devices-table-header {
        background: linear-gradient(135deg, var(--network-primary), var(--network-secondary));
        color: white;
        padding: 15px 20px;
        font-weight: 600;
    }
    
    .devices-table table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .devices-table th,
    .devices-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .devices-table th {
        background: #f8f9fa;
        color: var(--network-primary);
        font-weight: 600;
    }
    
    .devices-table tr:hover {
        background: #f8f9fa;
    }
    
    .action-btn {
        padding: 6px 12px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 0.85em;
        margin: 0 2px;
        transition: all 0.3s;
    }
    
    .action-btn.ping {
        background: #3498db;
        color: white;
    }
    
    .action-btn.trace {
        background: #9b59b6;
        color: white;
    }
    
    .action-btn.reboot {
        background: #e67e22;
        color: white;
    }
    
    .action-btn:hover {
        opacity: 0.8;
        transform: translateY(-2px);
    }
    
    .traffic-chart {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-top: 20px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .bandwidth-bar {
        height: 30px;
        background: #ecf0f1;
        border-radius: 15px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .bandwidth-used {
        height: 100%;
        background: linear-gradient(90deg, #3498db, #2ecc71);
        width: 0%;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        padding-right: 10px;
        color: white;
        font-size: 0.8em;
        border-radius: 15px;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 500px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #ecf0f1;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .modal-body {
        padding: 20px;
    }
    
    .modal-footer {
        padding: 15px 20px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .close {
        cursor: pointer;
        font-size: 24px;
        color: #7f8c8d;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
    }
    
    .toast.success { border-left: 4px solid #27ae60; }
    .toast.error { border-left: 4px solid #e74c3c; }
    .toast.info { border-left: 4px solid #3498db; }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-network-wired"></i> Управление корпоративной сетью
        </h1>
        <div>
            <button class="btn btn-primary" onclick="refreshStatus()">
                <i class="fas fa-sync-alt"></i> Обновить статус
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <!-- Статистика сети -->
    <div class="network-stats">
        <div class="network-card <?php echo $networkStatus['internet']['status']; ?>">
            <div class="network-card-title"><i class="fas fa-globe"></i> Интернет</div>
            <div class="network-card-value"><?php echo $networkStatus['internet']['speed']; ?></div>
            <div class="network-card-detail">Uptime: <?php echo $networkStatus['internet']['uptime']; ?></div>
        </div>
        
        <div class="network-card <?php echo $networkStatus['vpn']['status']; ?>">
            <div class="network-card-title"><i class="fas fa-lock"></i> VPN</div>
            <div class="network-card-value"><?php echo $networkStatus['vpn']['connected']; ?></div>
            <div class="network-card-detail">Задержка: <?php echo $networkStatus['vpn']['latency']; ?></div>
        </div>
        
        <div class="network-card <?php echo $networkStatus['firewall']['status']; ?>">
            <div class="network-card-title"><i class="fas fa-shield-alt"></i> Firewall</div>
            <div class="network-card-value"><?php echo $networkStatus['firewall']['blocked']; ?></div>
            <div class="network-card-detail">Активных правил: <?php echo $networkStatus['firewall']['rules']; ?></div>
        </div>
        
        <div class="network-card <?php echo $networkStatus['wifi']['status']; ?>">
            <div class="network-card-title"><i class="fas fa-wifi"></i> Wi-Fi</div>
            <div class="network-card-value"><?php echo $networkStatus['wifi']['clients']; ?></div>
            <div class="network-card-detail">Диапазоны: <?php echo $networkStatus['wifi']['channels']; ?></div>
        </div>
        
        <div class="network-card <?php echo $networkStatus['switches']['status']; ?>">
            <div class="network-card-title"><i class="fas fa-exchange-alt"></i> Коммутаторы</div>
            <div class="network-card-value"><?php echo $networkStatus['switches']['active_ports']; ?></div>
            <div class="network-card-detail">Ошибок: <?php echo $networkStatus['switches']['errors']; ?></div>
        </div>
        
        <div class="network-card <?php echo $networkStatus['servers']['status']; ?>">
            <div class="network-card-title"><i class="fas fa-server"></i> Серверы</div>
            <div class="network-card-value"><?php echo $networkStatus['servers']['load']; ?></div>
            <div class="network-card-detail">Память: <?php echo $networkStatus['servers']['memory']; ?></div>
        </div>
    </div>
    
    <!-- Трафик -->
    <div class="traffic-chart">
        <h5><i class="fas fa-chart-line"></i> Использование канала</h5>
        <div class="bandwidth-bar">
            <div class="bandwidth-used" style="width: 65%;">65%</div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <small><i class="fas fa-arrow-down text-success"></i> Входящий: 65.2 Mbps</small>
            </div>
            <div class="col-md-6">
                <small><i class="fas fa-arrow-up text-primary"></i> Исходящий: 32.8 Mbps</small>
            </div>
        </div>
    </div>
    
    <!-- Список устройств -->
    <div class="devices-table mt-4">
        <div class="devices-table-header">
            <i class="fas fa-microchip"></i> Сетевые устройства
        </div>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Устройство</th>
                        <th>IP-адрес</th>
                        <th>Тип</th>
                        <th>Статус</th>
                        <th>Uptime</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody id="devicesList">
                    <?php foreach ($devices as $device): ?>
                    <tr>
                        <td><i class="fas <?php echo $device['type'] == 'router' ? 'fa-router' : ($device['type'] == 'switch' ? 'fa-exchange-alt' : ($device['type'] == 'server' ? 'fa-server' : 'fa-wifi')); ?>"></i> <?php echo $device['name']; ?></td>
                        <td><?php echo $device['ip']; ?></td>
                        <td><?php echo ucfirst($device['type']); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $device['status']; ?>">
                                <i class="fas fa-circle" style="font-size: 8px;"></i> <?php echo ucfirst($device['status']); ?>
                            </span>
                        </td>
                        <td><?php echo $device['uptime']; ?></td>
                        <td>
                            <button class="action-btn ping" onclick="pingDevice('<?php echo $device['ip']; ?>', '<?php echo $device['name']; ?>')">
                                <i class="fas fa-network-wired"></i> Ping
                            </button>
                            <button class="action-btn trace" onclick="traceRoute('<?php echo $device['ip']; ?>', '<?php echo $device['name']; ?>')">
                                <i class="fas fa-chart-line"></i> Trace
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Модальное окно результатов -->
<div id="resultModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 id="modalTitle">Результат</h5>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <div class="modal-body">
            <pre id="modalResult" style="background: #2c3e50; color: #0f0; padding: 15px; border-radius: 8px; overflow-x: auto;"></pre>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal()">Закрыть</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
// Обновление статуса
function refreshStatus() {
    showToast('Обновление статуса...', 'info');
    
    fetch('../api/network_api.php?action=status')
        .then(response => response.json())
        .then(data => {
            showToast('Статус обновлен', 'success');
            location.reload();
        })
        .catch(error => showToast('Ошибка: ' + error, 'error'));
}

// Ping устройства
function pingDevice(ip, name) {
    showToast(`Ping ${name}...`, 'info');
    
    fetch(`../api/network_api.php?action=ping&ip=${ip}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('modalTitle').innerHTML = `<i class="fas fa-network-wired"></i> Ping: ${name} (${ip})`;
            document.getElementById('modalResult').textContent = data.result;
            document.getElementById('resultModal').style.display = 'flex';
        })
        .catch(error => {
            document.getElementById('modalTitle').innerHTML = `Ошибка Ping: ${name}`;
            document.getElementById('modalResult').textContent = error;
            document.getElementById('resultModal').style.display = 'flex';
        });
}

// Трассировка маршрута
function traceRoute(ip, name) {
    showToast(`Трассировка до ${name}...`, 'info');
    
    fetch(`../api/network_api.php?action=traceroute&ip=${ip}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('modalTitle').innerHTML = `<i class="fas fa-chart-line"></i> Трассировка: ${name} (${ip})`;
            document.getElementById('modalResult').textContent = data.result;
            document.getElementById('resultModal').style.display = 'flex';
        })
        .catch(error => {
            document.getElementById('modalTitle').innerHTML = `Ошибка трассировки: ${name}`;
            document.getElementById('modalResult').textContent = error;
            document.getElementById('resultModal').style.display = 'flex';
        });
}

// Закрытие модального окна
function closeModal() {
    document.getElementById('resultModal').style.display = 'none';
}

// Показ уведомления
function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// Закрытие модального окна при клике вне его
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
    }
}

// Автообновление каждые 30 секунд
setInterval(() => {
    refreshStatus();
}, 30000);
</script>

<?php require_once '../includes/footer.php'; ?>
