<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Только администратор
checkAdmin();

header('Content-Type: application/json');

require_once 'tests/TestRunner.php';

$action = $_GET['action'] ?? '';
$runner = new Tests\TestRunner($pdo);

switch ($action) {
    case 'list':
        // Список доступных тестов
        echo json_encode([
            'total' => 5,
            'tests' => [
                ['id' => 'database', 'name' => 'База данных'],
                ['id' => 'auth', 'name' => 'Авторизация'],
                ['id' => 'cars', 'name' => 'Автомобили'],
                ['id' => 'orders', 'name' => 'Заказы'],
                ['id' => 'security', 'name' => 'Безопасность']
            ]
        ]);
        break;
        
    case 'run':
        $suite = $_GET['suite'] ?? 'all';
        $testId = $_GET['test'] ?? '';
        
        if ($testId) {
            // Формат: suite_method (например: auth_testLogin)
            $parts = explode('_', $testId);
            $suite = $parts[0] ?? '';
            $method = $parts[1] ?? '';
            
            if ($suite && $method) {
                $result = $runner->runSingleTest($suite, $method);
                echo json_encode($result);
            } else {
                echo json_encode(['error' => 'Invalid test ID format']);
            }
        } elseif ($suite === 'all') {
            $results = $runner->runAllTests();
            echo json_encode($results);
        } else {
            $results = $runner->runSuite($suite);
            echo json_encode($results);
        }
        break;
        
    case 'results':
        // Загрузить предыдущие результаты (заглушка)
        echo json_encode([]);
        break;
        
    case 'clear':
        // Очистить результаты (заглушка)
        echo json_encode(['success' => true]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}