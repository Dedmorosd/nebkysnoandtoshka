<?php
// Включаем отображение ошибок для отладки
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключаем необходимые файлы в правильном порядке
require_once 'config/database.php';
require_once 'includes/auth.php';

// Проверяем авторизацию
checkAuth();

$pageTitle = "Панель управления";
$user_id = $_SESSION['user_id'];

// Статистика для админа/механика
if (isAdmin() || isMechanic()) {
    try {
        $orders_count = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
        $clients_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'client'")->fetchColumn();
        $pending_orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'new'")->fetchColumn();
        $total_revenue = $pdo->query("SELECT SUM(total_price) FROM orders WHERE status = 'completed'")->fetchColumn() ?? 0;
    } catch (Exception $e) {
        $orders_count = $clients_count = $pending_orders = 0;
        $total_revenue = 0;
    }
} elseif (isClient()) {
    try {
        // Получаем client_id пользователя
        $stmt = $pdo->prepare("SELECT id FROM clients WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $client = $stmt->fetch();
        
        if ($client) {
            $client_id = $client['id'];
            
            // Количество заказов клиента
            $client_orders = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE client_id = ?");
            $client_orders->execute([$client_id]);
            $my_orders = $client_orders->fetchColumn();
            
            // Количество автомобилей клиента
            $client_cars = $pdo->prepare("SELECT COUNT(*) FROM cars WHERE client_id = ?");
            $client_cars->execute([$client_id]);
            $my_cars = $client_cars->fetchColumn();
        } else {
            $my_orders = 0;
            $my_cars = 0;
        }
    } catch (Exception $e) {
        $my_orders = 0;
        $my_cars = 0;
    }
}

require_once 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <h1 class="mb-4">
                <i class="fas fa-tachometer-alt"></i> Панель управления
            </h1>
            
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <?php if (isAdmin() || isMechanic()): ?>
                    <!-- Карточки для админа/механика -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card bg-primary text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Все заказы</h6>
                                        <h2 class="mb-0"><?php echo $orders_count ?? 0; ?></h2>
                                    </div>
                                    <i class="fas fa-clipboard-list fa-3x opacity-50"></i>
                                </div>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <a class="small text-white stretched-link" href="orders.php">Подробнее</a>
                                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card bg-success text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Клиенты</h6>
                                        <h2 class="mb-0"><?php echo $clients_count ?? 0; ?></h2>
                                    </div>
                                    <i class="fas fa-users fa-3x opacity-50"></i>
                                </div>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <a class="small text-white stretched-link" href="admin_users.php">Подробнее</a>
                                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card bg-warning text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Ожидают</h6>
                                        <h2 class="mb-0"><?php echo $pending_orders ?? 0; ?></h2>
                                    </div>
                                    <i class="fas fa-clock fa-3x opacity-50"></i>
                                </div>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <a class="small text-white stretched-link" href="orders.php?status=new">Подробнее</a>
                                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card bg-info text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Выручка</h6>
                                        <h2 class="mb-0"><?php echo number_format($total_revenue ?? 0, 0, ',', ' '); ?> ₽</h2>
                                    </div>
                                    <i class="fas fa-ruble-sign fa-3x opacity-50"></i>
                                </div>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <a class="small text-white stretched-link" href="admin_reports.php">Подробнее</a>
                                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                            </div>
                        </div>
                    </div>

                    <!-- Быстрые действия для админа/механика -->
                    <div class="col-12 mb-4">
                        <div class="card">
                            <div class="card-header bg-dark text-white">
                                <h5 class="mb-0"><i class="fas fa-bolt"></i> Быстрые действия</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3 mb-2">
                                        <a href="orders.php" class="btn btn-outline-primary w-100">
                                            <i class="fas fa-clipboard-list"></i> Все заказы
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-2">
                                        <a href="admin_users.php" class="btn btn-outline-success w-100">
                                            <i class="fas fa-users"></i> Пользователи
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-2">
                                        <a href="admin_services.php" class="btn btn-outline-info w-100">
                                            <i class="fas fa-tools"></i> Услуги
                                        </a>
                                    </div>
                                    <div class="col-md-3 mb-2">
                                        <a href="admin_reports.php" class="btn btn-outline-warning w-100">
                                            <i class="fas fa-chart-bar"></i> Отчеты
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php elseif (isClient()): ?>
                    <!-- Карточки для клиента -->
                    <div class="col-xl-6 col-md-6 mb-4">
                        <div class="card bg-primary text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Мои заказы</h6>
                                        <h2 class="mb-0"><?php echo $my_orders ?? 0; ?></h2>
                                    </div>
                                    <i class="fas fa-clipboard-list fa-3x opacity-50"></i>
                                </div>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <a class="small text-white stretched-link" href="orders.php">Подробнее</a>
                                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-md-6 mb-4">
                        <div class="card bg-success text-white h-100">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="card-title">Мои автомобили</h6>
                                        <h2 class="mb-0"><?php echo $my_cars ?? 0; ?></h2>
                                    </div>
                                    <i class="fas fa-car fa-3x opacity-50"></i>
                                </div>
                            </div>
                            <div class="card-footer d-flex align-items-center justify-content-between">
                                <a class="small text-white stretched-link" href="cars.php">Подробнее</a>
                                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                            </div>
                        </div>
                    </div>

                    <!-- Быстрые действия для клиента -->
                    <div class="col-12 mb-4">
                        <div class="card">
                            <div class="card-header bg-dark text-white">
                                <h5 class="mb-0"><i class="fas fa-bolt"></i> Быстрые действия</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 mb-2">
                                        <a href="cars.php" class="btn btn-outline-primary w-100">
                                            <i class="fas fa-plus-circle"></i> Добавить автомобиль
                                        </a>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <a href="create_order.php" class="btn btn-outline-success w-100">
                                            <i class="fas fa-clipboard-list"></i> Создать заказ
                                        </a>
                                    </div>
                                    <div class="col-md-4 mb-2">
                                        <a href="services.php" class="btn btn-outline-info w-100">
                                            <i class="fas fa-search"></i> Посмотреть услуги
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Последние заказы клиента -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0"><i class="fas fa-history"></i> Последние заказы</h5>
                            </div>
                            <div class="card-body">
                                <?php
                                if (isset($client_id)) {
                                    try {
                                        $stmt = $pdo->prepare("
                                            SELECT o.*, c.brand, c.model, c.license_plate
                                            FROM orders o
                                            JOIN cars c ON o.car_id = c.id
                                            WHERE o.client_id = ?
                                            ORDER BY o.created_at DESC
                                            LIMIT 5
                                        ");
                                        $stmt->execute([$client_id]);
                                        $recent_orders = $stmt->fetchAll();
                                    } catch (Exception $e) {
                                        $recent_orders = [];
                                    }
                                } else {
                                    $recent_orders = [];
                                }
                                ?>
                                
                                <?php if (!empty($recent_orders)): ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>№ заказа</th>
                                                    <th>Автомобиль</th>
                                                    <th>Статус</th>
                                                    <th>Дата</th>
                                                    <th>Сумма</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($recent_orders as $order): ?>
                                                <tr>
                                                    <td>#<?php echo $order['id']; ?></td>
                                                    <td>
                                                        <?php echo htmlspecialchars($order['brand'] . ' ' . $order['model']); ?>
                                                        <br>
                                                        <small class="text-muted"><?php echo htmlspecialchars($order['license_plate']); ?></small>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $status_classes = [
                                                            'new' => 'badge bg-primary',
                                                            'in_progress' => 'badge bg-warning text-dark',
                                                            'completed' => 'badge bg-success',
                                                            'cancelled' => 'badge bg-secondary'
                                                        ];
                                                        $status_texts = [
                                                            'new' => 'Новый',
                                                            'in_progress' => 'В работе',
                                                            'completed' => 'Завершен',
                                                            'cancelled' => 'Отменен'
                                                        ];
                                                        $class = $status_classes[$order['status']] ?? 'badge bg-secondary';
                                                        $text = $status_texts[$order['status']] ?? $order['status'];
                                                        ?>
                                                        <span class="<?php echo $class; ?>"><?php echo $text; ?></span>
                                                    </td>
                                                    <td><?php echo date('d.m.Y', strtotime($order['created_at'])); ?></td>
                                                    <td class="text-end"><?php echo number_format($order['total_price'] ?? 0, 2, ',', ' '); ?> ₽</td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="text-end mt-3">
                                        <a href="orders.php" class="btn btn-sm btn-primary">Все заказы →</a>
                                    </div>
                                <?php else: ?>
                                    <p class="text-center text-muted my-4">
                                        <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                        У вас пока нет заказов
                                    </p>
                                    <div class="text-center">
                                        <a href="create_order.php" class="btn btn-success">
                                            <i class="fas fa-plus"></i> Создать первый заказ
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    transition: transform 0.2s, box-shadow 0.2s;
    border: none;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
}
.card:hover {
    transform: translateY(-3px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}
.card-footer {
    background: rgba(0,0,0,0.03);
    border-top: 1px solid rgba(0,0,0,0.05);
}
</style>

<?php require_once 'includes/footer.php'; ?>