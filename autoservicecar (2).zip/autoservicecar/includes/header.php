<?php
// Не запускаем сессию здесь!
// Сессия должна запускаться только там, где это действительно нужно

// Подключаем auth.php для получения функций
require_once __DIR__ . '/auth.php';

// Определяем, авторизован ли пользователь безопасно
$isLoggedIn = false;
$userName = 'Гость';
$userRole = 'guest';

// Проверяем наличие сессии и данных пользователя
if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['user_id'])) {
    $isLoggedIn = true;
    $userName = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Пользователь';
    $userRole = $_SESSION['role'] ?? 'client';
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Автосервис'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-car"></i> Автосервис
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if ($isLoggedIn): ?>
                        <!-- Для авторизованных пользователей -->
                        <li class="nav-item">
                            <span class="nav-link text-white">
                                <i class="fas fa-user"></i> 
                                <?php echo htmlspecialchars($userName); ?> 
                                (<?php echo $userRole; ?>)
                            </span>
                        </li>
                        
                        <!-- Общие пункты для всех авторизованных -->
                        <li class="nav-item">
                            <a class="nav-link" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Панель
                            </a>
                        </li>
                        
                        <!-- Специальные пункты для администратора -->
                        <?php if (isAdmin()): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-cog"></i> Администрирование
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="admin.php">
                                    <i class="fas fa-cog"></i> Админ панель
                                </a></li>
                                <li><a class="dropdown-item" href="test_suite.php">
                                    <i class="fas fa-flask"></i> Тестирование
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="admin/db_management.php">
                                    <i class="fas fa-database"></i> Управление БД
                                </a></li>
                                <li><a class="dropdown-item" href="admin/db_monitor.php">
                                    <i class="fas fa-chart-line"></i> Мониторинг БД
                                </a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="admin/network_management.php">
                                    <i class="fas fa-network-wired"></i> Управление сетью
                                </a></li>
                                <li><a class="dropdown-item" href="admin/network_monitor.php">
                                    <i class="fas fa-chart-network"></i> Мониторинг сети
                                </a></li>
                            </ul>
                        </li>
                        <?php endif; ?>
                        
                        <!-- Для механиков -->
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'mechanic'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="mechanic_panel.php">
                                <i class="fas fa-tools"></i> Рабочее место
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <!-- Выход для всех -->
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Выход
                            </a>
                        </li>
                        
                    <?php else: ?>
                        <!-- Для неавторизованных пользователей -->
                        <li class="nav-item">
                            <span class="nav-link text-white">
                                <i class="fas fa-user"></i> Гость
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">
                                <i class="fas fa-sign-in-alt"></i> Вход
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">
                                <i class="fas fa-user-plus"></i> Регистрация
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Вывод сообщений об ошибках/успехе (если есть) -->
    <?php if (isset($_SESSION['success_message'])): ?>
    <div class="container mt-3">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> 
            <?php 
            echo $_SESSION['success_message']; 
            unset($_SESSION['success_message']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
    <div class="container mt-3">
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> 
            <?php 
            echo $_SESSION['error_message']; 
            unset($_SESSION['error_message']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
    <?php endif; ?>
    
    <main class="py-4">