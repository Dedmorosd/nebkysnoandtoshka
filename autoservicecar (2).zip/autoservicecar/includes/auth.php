<?php
// Файл: includes/auth.php

// Запускаем сессию ТОЛЬКО если ее еще нет
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isMechanic() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'mechanic';
}

function isClient() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'client';
}

function checkAuth() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

function checkAdmin() {
    checkAuth();
    if (!isAdmin()) {
        header('Location: dashboard.php');
        exit();
    }
}
?>