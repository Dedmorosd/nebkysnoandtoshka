<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$action = $_GET['action'] ?? '';
$response = [];

try {
    switch ($action) {
        case 'list_tables':
            $response = getTablesList($pdo);
            break;
            
        case 'optimize_all':
            $response = optimizeAllTables($pdo);
            break;
            
        case 'optimize_table':
            $table = $_GET['table'] ?? '';
            $response = optimizeTable($pdo, $table);
            break;
            
        case 'analyze_all':
            $response = analyzeAllTables($pdo);
            break;
            
        case 'analyze_table':
            $table = $_GET['table'] ?? '';
            $response = analyzeTable($pdo, $table);
            break;
            
        case 'backup':
            $input = json_decode(file_get_contents('php://input'), true);
            $response = createBackup($pdo, $input);
            break;
            
        case 'list_backups':
            $response = listBackups();
            break;
            
        case 'restore':
            $input = json_decode(file_get_contents('php://input'), true);
            $response = restoreBackup($pdo, $input);
            break;
            
        case 'db_status':
            $response = getDbStatus($pdo);
            break;
            
        default:
            $response = ['error' => 'Неизвестное действие'];
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции
// ============================================

function getTablesList($pdo)
{
    $stmt = $pdo->query("
        SELECT 
            TABLE_NAME as name,
            ENGINE as engine,
            TABLE_ROWS as rows,
            ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as total_size,
            ROUND(DATA_LENGTH / 1024 / 1024, 2) as data_size,
            ROUND(INDEX_LENGTH / 1024 / 1024, 2) as index_size,
            ROUND(DATA_FREE / 1024 / 1024, 2) as fragmentation
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = 'project_Karachkin'
        ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC
    ");
    
    $tables = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $tables[] = [
            'name' => $row['name'],
            'engine' => $row['engine'],
            'rows' => $row['rows'],
            'data_size' => $row['data_size'],
            'index_size' => $row['index_size'],
            'fragmentation' => $row['fragmentation']
        ];
    }
    
    return $tables;
}

function optimizeAllTables($pdo)
{
    $stmt = $pdo->query("
        SELECT TABLE_NAME 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = 'project_Karachkin'
    ");
    
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($tables as $table) {
        $pdo->exec("OPTIMIZE TABLE `$table`");
    }
    
    return ['success' => true, 'message' => 'Оптимизация завершена'];
}

function optimizeTable($pdo, $table)
{
    if (empty($table)) {
        return ['error' => 'Имя таблицы не указано'];
    }
    
    $pdo->exec("OPTIMIZE TABLE `$table`");
    return ['success' => true, 'message' => "Таблица $table оптимизирована"];
}

function analyzeAllTables($pdo)
{
    $stmt = $pdo->query("
        SELECT TABLE_NAME 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = 'project_Karachkin'
    ");
    
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($tables as $table) {
        $pdo->exec("ANALYZE TABLE `$table`");
    }
    
    return ['success' => true, 'message' => 'Анализ завершен'];
}

function analyzeTable($pdo, $table)
{
    if (empty($table)) {
        return ['error' => 'Имя таблицы не указано'];
    }
    
    $pdo->exec("ANALYZE TABLE `$table`");
    return ['success' => true, 'message' => "Таблица $table проанализирована"];
}

function createBackup($pdo, $params)
{
    $backupDir = __DIR__ . '/../backups/';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0777, true);
    }
    
    $type = $params['type'] ?? 'full';
    $compression = $params['compression'] ?? 'gzip';
    $date = date('Y-m-d_H-i-s');
    $filename = "backup_{$date}.sql";
    
    // Создание дампа
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    $output = "-- Backup created: " . date('Y-m-d H:i:s') . "\n";
    $output .= "-- Database: project_Karachkin\n\n";
    
    foreach ($tables as $table) {
        // Структура таблицы
        $result = $pdo->query("SHOW CREATE TABLE `$table`");
        $row = $result->fetch();
        $output .= "DROP TABLE IF EXISTS `$table`;\n";
        $output .= $row['Create Table'] . ";\n\n";
        
        if ($type !== 'structure') {
            // Данные таблицы
            $rows = $pdo->query("SELECT * FROM `$table`");
            while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
                $output .= "INSERT INTO `$table` VALUES (";
                $values = [];
                foreach ($row as $value) {
                    $values[] = $value === null ? 'NULL' : "'" . addslashes($value) . "'";
                }
                $output .= implode(', ', $values) . ");\n";
            }
            $output .= "\n";
        }
    }
    
    // Сохранение файла
    if ($compression === 'gzip') {
        $filename .= '.gz';
        file_put_contents($backupDir . $filename, gzencode($output));
    } else {
        file_put_contents($backupDir . $filename, $output);
    }
    
    return ['success' => true, 'filename' => $filename];
}

function listBackups()
{
    $backupDir = __DIR__ . '/../backups/';
    $backups = [];
    
    if (is_dir($backupDir)) {
        $files = scandir($backupDir);
        foreach ($files as $file) {
            if (preg_match('/\.sql(\.gz)?$/', $file)) {
                $backups[] = [
                    'filename' => $file,
                    'size' => round(filesize($backupDir . $file) / 1024 / 1024, 2),
                    'date' => date('Y-m-d H:i:s', filemtime($backupDir . $file))
                ];
            }
        }
        usort($backups, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
    }
    
    return $backups;
}

function restoreBackup($pdo, $params)
{
    $filename = $params['filename'] ?? '';
    $backupDir = __DIR__ . '/../backups/';
    $filepath = $backupDir . $filename;
    
    if (!file_exists($filepath)) {
        return ['error' => 'Файл бэкапа не найден'];
    }
    
    // Очистка БД
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $pdo->exec("DROP TABLE IF EXISTS `$table`");
    }
    
    // Восстановление
    $content = file_get_contents($filepath);
    if (str_ends_with($filename, '.gz')) {
        $content = gzdecode($content);
    }
    
    $pdo->exec($content);
    
    return ['success' => true, 'message' => 'Восстановление завершено'];
}

function getDbStatus($pdo)
{
    $status = [];
    
    // Размер БД
    $stmt = $pdo->query("
        SELECT 
            ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
        FROM information_schema.tables
        WHERE table_schema = 'project_Karachkin'
    ");
    $status['size_mb'] = $stmt->fetchColumn();
    
    // Количество таблиц
    $status['tables'] = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'project_Karachkin'")->fetchColumn();
    
    // Подключения
    $status['connections'] = $pdo->query("SHOW STATUS LIKE 'Threads_connected'")->fetch()['Value'];
    
    // Время работы
    $status['uptime'] = $pdo->query("SHOW STATUS LIKE 'Uptime'")->fetch()['Value'];
    
    // Версия
    $status['version'] = $pdo->query("SELECT VERSION()")->fetchColumn();
    
    return $status;
}
?> 
