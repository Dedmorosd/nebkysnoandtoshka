 <?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$action = $_GET['action'] ?? '';
$ip = $_GET['ip'] ?? '';
$response = [];

try {
    switch ($action) {
        case 'status':
            $response = getNetworkStatus();
            break;
            
        case 'ping':
            $response = pingHost($ip);
            break;
            
        case 'traceroute':
            $response = traceRoute($ip);
            break;
            
        case 'bandwidth':
            $response = getBandwidthUsage();
            break;
            
        case 'devices':
            $response = getNetworkDevices();
            break;
            
        default:
            $response = ['error' => 'Неизвестное действие'];
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции
// ============================================

function getNetworkStatus()
{
    // В реальной системе здесь были бы запросы к SNMP/API оборудования
    return [
        'internet' => ['status' => 'online', 'speed' => '98.5 Mbps', 'uptime' => '99.98%'],
        'vpn' => ['status' => 'online', 'connected' => '3/3', 'latency' => '25 ms'],
        'firewall' => ['status' => 'active', 'blocked' => 127, 'rules' => 45],
        'switches' => ['status' => 'online', 'active_ports' => '32/48', 'errors' => 0],
        'wifi' => ['status' => 'online', 'clients' => 23, 'channels' => '2.4/5 GHz'],
        'servers' => ['status' => 'online', 'load' => '32%', 'memory' => '45%']
    ];
}

function pingHost($ip)
{
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
        return ['error' => 'Неверный IP-адрес'];
    }
    
    $output = [];
    $returnCode = 0;
    
    // Для Windows и Linux
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        exec("ping -n 4 $ip", $output, $returnCode);
    } else {
        exec("ping -c 4 $ip", $output, $returnCode);
    }
    
    $result = implode("\n", $output);
    
    if ($returnCode === 0) {
        return ['success' => true, 'result' => $result];
    } else {
        return ['success' => false, 'result' => "Хост $ip не отвечает\n\n" . $result];
    }
}

function traceRoute($ip)
{
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
        return ['error' => 'Неверный IP-адрес'];
    }
    
    $output = [];
    $returnCode = 0;
    
    // Для Windows и Linux
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        exec("tracert -d -h 15 $ip", $output, $returnCode);
    } else {
        exec("traceroute -n -m 15 $ip 2>&1", $output, $returnCode);
    }
    
    $result = implode("\n", $output);
    
    return ['success' => true, 'result' => $result];
}

function getBandwidthUsage()
{
    // В реальной системе здесь был бы запрос к SNMP
    return [
        'incoming' => 65.2,
        'outgoing' => 32.8,
        'total' => 98.0,
        'unit' => 'Mbps'
    ];
}

function getNetworkDevices()
{
    // В реальной системе здесь был бы запрос к DHCP или ARP таблице
    return [
        ['name' => 'Core Router', 'ip' => '10.10.10.1', 'type' => 'router', 'status' => 'online', 'uptime' => '45d 12h'],
        ['name' => 'Core Switch', 'ip' => '10.10.10.2', 'type' => 'switch', 'status' => 'online', 'uptime' => '45d 12h'],
        ['name' => 'Firewall', 'ip' => '10.10.10.3', 'type' => 'firewall', 'status' => 'online', 'uptime' => '30d 8h'],
        ['name' => 'DB Server', 'ip' => '10.10.20.10', 'type' => 'server', 'status' => 'online', 'uptime' => '15d 3h'],
    ];
}
?>
