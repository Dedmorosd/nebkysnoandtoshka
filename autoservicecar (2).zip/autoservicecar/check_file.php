 <?php
$file = 'config/database.php';

if (file_exists($file)) {
    echo "<h2>Проверка файла: $file</h2>";
    
    // Читаем первые 50 байт
    $handle = fopen($file, 'rb');
    $start = fread($handle, 50);
    fclose($handle);
    
    echo "<h3>Первые 50 символов (в hex):</h3>";
    echo "<pre>";
    for ($i = 0; $i < strlen($start); $i++) {
        printf("%02x ", ord($start[$i]));
    }
    echo "</pre>";
    
    echo "<h3>Первые 50 символов (текст):</h3>";
    echo "<pre>" . htmlspecialchars($start) . "</pre>";
    
    // Проверяем на BOM (EF BB BF)
    if (substr($start, 0, 3) === "\xEF\xBB\xBF") {
        echo "<p style='color:red'>❌ Обнаружен BOM маркер в начале файла!</p>";
        echo "<p>Это вызывает ошибку парсера. Файл нужно сохранить без BOM.</p>";
    } else {
        echo "<p style='color:green'>✅ BOM маркер не обнаружен</p>";
    }
    
    // Проверяем начинается ли с <?php
    if (substr($start, 0, 5) === "<?php") {
        echo "<p style='color:green'>✅ Файл начинается с &lt;?php</p>";
    } else {
        echo "<p style='color:red'>❌ Файл НЕ начинается с &lt;?php!</p>";
    }
    
    // Проверяем размер
    $size = filesize($file);
    echo "<p>Размер файла: $size байт</p>";
    
    if ($size < 10) {
        echo "<p style='color:red'>❌ Файл слишком маленький (возможно пустой)</p>";
    }
    
} else {
    echo "<p style='color:red'>Файл не найден!</p>";
}
?>
