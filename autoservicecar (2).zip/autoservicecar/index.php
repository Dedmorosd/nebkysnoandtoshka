<?php
// Включаем отображение ошибок для отладки
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Подключаем базу данных
require_once 'config/database.php';

// НЕ запускаем сессию автоматически! 
// Проверяем сессию только если она уже есть
if (session_status() === PHP_SESSION_NONE) {
    // Не запускаем сессию автоматически на главной
    // session_start(); - НЕ ЗАПУСКАЕМ!
}

$pageTitle = "Главная";

// Проверяем, авторизован ли пользователь (без автоматического запуска сессии)
$isLoggedIn = false;
$userName = 'Гость';

// Проверяем существование сессии и переменных
if (isset($_COOKIE['PHPSESSID'])) {
    // Если есть cookie сессии, тогда запускаем сессию для проверки
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['user_id'])) {
        $isLoggedIn = true;
        $userName = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Пользователь';
    } else {
        // Если сессия есть, но пользователь не авторизован - очищаем её
        session_destroy();
        setcookie('PHPSESSID', '', time() - 3600, '/');
    }
}

require_once 'includes/header.php';
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12 text-center">
            <h1 class="display-4">Добро пожаловать в Автосервис!</h1>
            <p class="lead">Профессиональное обслуживание вашего автомобиля</p>
            
            <?php if ($isLoggedIn): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> 
                    Вы вошли как <strong><?php echo htmlspecialchars($userName); ?></strong>
                </div>
                <a href="dashboard.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-tachometer-alt"></i> Перейти в панель управления
                </a>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> 
                    Пожалуйста, войдите в систему для доступа к функциям
                </div>
                <div class="mt-4">
                    <a href="login.php" class="btn btn-primary btn-lg mx-2">
                        <i class="fas fa-sign-in-alt"></i> Вход
                    </a>
                    <a href="register.php" class="btn btn-success btn-lg mx-2">
                        <i class="fas fa-user-plus"></i> Регистрация
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row mt-5">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-car fa-3x mb-3 text-primary"></i>
                    <h3>Автомобили</h3>
                    <p>Добавляйте и управляйте своими автомобилями</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-clipboard-list fa-3x mb-3 text-success"></i>
                    <h3>Заказы</h3>
                    <p>Создавайте заказы на обслуживание</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <i class="fas fa-tools fa-3x mb-3 text-warning"></i>
                    <h3>Услуги</h3>
                    <p>Просматривайте доступные услуги</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>