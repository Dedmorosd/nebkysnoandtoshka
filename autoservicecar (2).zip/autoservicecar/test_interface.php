 <?php
require_once 'config/database.php';
require_once 'includes/auth.php';

// Только администратор может видеть тесты
checkAdmin();

$pageTitle = "Интерфейс тестирования";
$user_id = $_SESSION['user_id'];

require_once 'includes/header.php';
?>

<style>
    :root {
        --primary-color: #4361ee;
        --success-color: #06d6a0;
        --danger-color: #ef476f;
        --warning-color: #ffd166;
        --dark-color: #073b4c;
        --light-color: #f8f9fa;
    }
    
    body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .test-container {
        max-width: 1400px;
        margin: 50px auto;
        padding: 30px;
        background: rgba(255,255,255,0.95);
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        backdrop-filter: blur(10px);
    }
    
    .test-header {
        text-align: center;
        margin-bottom: 40px;
        position: relative;
    }
    
    .test-header h1 {
        font-size: 3em;
        color: var(--dark-color);
        margin-bottom: 10px;
        font-weight: 700;
        background: linear-gradient(135deg, var(--primary-color), var(--success-color));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .test-header p {
        color: #666;
        font-size: 1.2em;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: transform 0.3s;
        border: 1px solid rgba(0,0,0,0.05);
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-icon {
        font-size: 2.5em;
        margin-bottom: 10px;
    }
    
    .stat-value {
        font-size: 2.5em;
        font-weight: 700;
        color: var(--dark-color);
    }
    
    .stat-label {
        color: #666;
        font-size: 0.9em;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .test-controls {
        display: flex;
        gap: 15px;
        margin-bottom: 30px;
        flex-wrap: wrap;
        justify-content: center;
    }
    
    .test-btn {
        padding: 15px 30px;
        border: none;
        border-radius: 10px;
        font-size: 1.1em;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .test-btn-primary {
        background: linear-gradient(135deg, var(--primary-color), #3a0ca3);
        color: white;
    }
    
    .test-btn-success {
        background: linear-gradient(135deg, var(--success-color), #06d6a0);
        color: white;
    }
    
    .test-btn-warning {
        background: linear-gradient(135deg, var(--warning-color), #ffb703);
        color: var(--dark-color);
    }
    
    .test-btn-danger {
        background: linear-gradient(135deg, var(--danger-color), #d9042b);
        color: white;
    }
    
    .test-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    
    .test-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none;
    }
    
    .test-progress {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 30px;
        display: none;
    }
    
    .progress-bar-container {
        width: 100%;
        height: 30px;
        background: rgba(255,255,255,0.5);
        border-radius: 15px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .progress-bar-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--primary-color), var(--success-color));
        width: 0%;
        transition: width 0.3s;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 0.9em;
    }
    
    .test-results {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 20px;
        margin-top: 30px;
    }
    
    .test-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        transition: all 0.3s;
        border: 1px solid rgba(0,0,0,0.05);
    }
    
    .test-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    
    .test-card-header {
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .test-card-header h3 {
        margin: 0;
        font-size: 1.3em;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .test-status-badge {
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: 600;
    }
    
    .status-pending {
        background: var(--warning-color);
        color: var(--dark-color);
    }
    
    .status-running {
        background: var(--primary-color);
        color: white;
        animation: pulse 1.5s infinite;
    }
    
    .status-success {
        background: var(--success-color);
        color: white;
    }
    
    .status-failed {
        background: var(--danger-color);
        color: white;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
    
    .test-card-body {
        padding: 20px;
        display: none;
    }
    
    .test-card-body.show {
        display: block;
    }
    
    .test-detail {
        margin-bottom: 15px;
        padding: 10px;
        border-radius: 8px;
        background: #f8f9fa;
    }
    
    .test-detail.pass {
        border-left: 4px solid var(--success-color);
    }
    
    .test-detail.fail {
        border-left: 4px solid var(--danger-color);
    }
    
    .test-detail-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    
    .test-detail-title {
        font-weight: 600;
        color: var(--dark-color);
    }
    
    .test-detail-status {
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 0.85em;
        font-weight: 600;
    }
    
    .test-detail-message {
        color: #666;
        font-size: 0.95em;
        margin-bottom: 10px;
    }
    
    .test-detail-time {
        color: #999;
        font-size: 0.85em;
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .test-log {
        background: var(--dark-color);
        color: #fff;
        padding: 15px;
        border-radius: 8px;
        font-family: 'Courier New', monospace;
        font-size: 0.9em;
        max-height: 200px;
        overflow-y: auto;
        margin-top: 10px;
    }
    
    .test-log-line {
        margin: 5px 0;
        color: #0f0;
    }
    
    .test-log-line.error {
        color: #f66;
    }
    
    .test-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
    }
    
    .test-actions button {
        padding: 8px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.9em;
        transition: all 0.3s;
    }
    
    .btn-view-log {
        background: var(--dark-color);
        color: white;
    }
    
    .btn-run-single {
        background: var(--primary-color);
        color: white;
    }
    
    .test-summary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 25px;
        border-radius: 15px;
        margin-bottom: 30px;
        text-align: center;
    }
    
    .summary-stats {
        display: flex;
        justify-content: center;
        gap: 50px;
        margin-top: 20px;
    }
    
    .summary-item {
        text-align: center;
    }
    
    .summary-value {
        font-size: 2.5em;
        font-weight: 700;
    }
    
    .summary-label {
        font-size: 0.9em;
        opacity: 0.9;
    }
    
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 10px;
        color: white;
        font-weight: 600;
        z-index: 9999;
        animation: slideIn 0.3s;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .notification.success { background: var(--success-color); }
    .notification.error { background: var(--danger-color); }
    .notification.info { background: var(--primary-color); }
    .notification.warning { background: var(--warning-color); color: var(--dark-color); }
    
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255,255,255,0.3);
        border-radius: 50%;
        border-top-color: white;
        animation: spin 1s ease-in-out infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
</style>

<div class="test-container">
    <div class="test-header">
        <h1><i class="fas fa-flask"></i> Интерфейс тестирования</h1>
        <p>Автоматическое тестирование функционала автосервиса</p>
    </div>
    
    <!-- Статистика тестов -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">📊</div>
            <div class="stat-value" id="totalTests">0</div>
            <div class="stat-label">Всего тестов</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">✅</div>
            <div class="stat-value" id="passedTests">0</div>
            <div class="stat-label">Пройдено</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">❌</div>
            <div class="stat-value" id="failedTests">0</div>
            <div class="stat-label">Ошибок</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">⏱️</div>
            <div class="stat-value" id="totalTime">0</div>
            <div class="stat-label">Время (сек)</div>
        </div>
    </div>
    
    <!-- Управление тестами -->
    <div class="test-controls">
        <button class="test-btn test-btn-primary" onclick="runAllTests()">
            <i class="fas fa-play"></i> Запустить все тесты
        </button>
        <button class="test-btn test-btn-success" onclick="runTestSuite('auth')">
            <i class="fas fa-key"></i> Тесты авторизации
        </button>
        <button class="test-btn test-btn-warning" onclick="runTestSuite('database')">
            <i class="fas fa-database"></i> Тесты БД
        </button>
        <button class="test-btn test-btn-danger" onclick="clearResults()">
            <i class="fas fa-trash"></i> Очистить результаты
        </button>
    </div>
    
    <!-- Прогресс выполнения -->
    <div class="test-progress" id="testProgress">
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span id="currentTestName">Подготовка...</span>
            <span id="testProgressPercent">0%</span>
        </div>
        <div class="progress-bar-container">
            <div class="progress-bar-fill" id="progressBar" style="width: 0%;">0%</div>
        </div>
    </div>
    
    <!-- Результаты тестов -->
    <div class="test-results" id="testResults"></div>
</div>

<!-- Шаблон для карточки теста -->
<template id="testCardTemplate">
    <div class="test-card">
        <div class="test-card-header" onclick="toggleTestDetails(this)">
            <h3>
                <i class="fas fa-flask"></i>
                <span class="test-name"></span>
            </h3>
            <div class="test-status-badge status-pending">Ожидание</div>
        </div>
        <div class="test-card-body">
            <div class="test-details-container"></div>
            <div class="test-log" style="display: none;"></div>
            <div class="test-actions">
                <button class="btn-view-log" onclick="toggleLog(this)">Показать лог</button>
                <button class="btn-run-single" onclick="runSingleTest(this)">Запустить</button>
            </div>
        </div>
    </div>
</template>

<script>
let testResults = {};

// Загружаем тесты при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    loadTestList();
    loadPreviousResults();
});

// Загрузка списка тестов
function loadTestList() {
    fetch('ajax_test_runner.php?action=list')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('testResults');
            container.innerHTML = '';
            
            data.tests.forEach(test => {
                const template = document.getElementById('testCardTemplate');
                const card = template.content.cloneNode(true);
                
                card.querySelector('.test-name').textContent = test.name;
                card.querySelector('.test-card').dataset.testId = test.id;
                
                container.appendChild(card);
            });
            
            document.getElementById('totalTests').textContent = data.total;
        });
}

// Загрузка предыдущих результатов
function loadPreviousResults() {
    fetch('ajax_test_runner.php?action=results')
        .then(response => response.json())
        .then(data => {
            testResults = data;
            updateStats();
            
            Object.keys(data).forEach(testId => {
                const card = document.querySelector(`[data-test-id="${testId}"]`);
                if (card) {
                    updateTestCard(card, data[testId]);
                }
            });
        });
}

// Запуск всех тестов
function runAllTests() {
    showProgress();
    runTestSuite('all');
}

// Запуск набора тестов
function runTestSuite(suite) {
    showProgress();
    
    const tests = document.querySelectorAll('.test-card');
    let completed = 0;
    
    tests.forEach(test => {
        updateTestStatus(test, 'running');
    });
    
    fetch(`ajax_test_runner.php?action=run&suite=${suite}`)
        .then(response => response.json())
        .then(data => {
            hideProgress();
            
            data.results.forEach(result => {
                const test = document.querySelector(`[data-test-id="${result.id}"]`);
                if (test) {
                    updateTestCard(test, result);
                }
            });
            
            updateStats();
            showNotification('Тесты завершены', 'success');
        })
        .catch(error => {
            hideProgress();
            showNotification('Ошибка выполнения тестов: ' + error, 'error');
        });
}

// Запуск одного теста
function runSingleTest(button) {
    const card = button.closest('.test-card');
    const testId = card.dataset.testId;
    
    showProgress();
    updateTestStatus(card, 'running');
    
    fetch(`ajax_test_runner.php?action=run&test=${testId}`)
        .then(response => response.json())
        .then(data => {
            hideProgress();
            updateTestCard(card, data);
            updateStats();
            showNotification('Тест выполнен', 'success');
        })
        .catch(error => {
            hideProgress();
            showNotification('Ошибка: ' + error, 'error');
        });
}

// Обновление карточки теста
function updateTestCard(card, result) {
    const statusBadge = card.querySelector('.test-status-badge');
    const detailsContainer = card.querySelector('.test-details-container');
    
    // Обновляем статус
    statusBadge.className = 'test-status-badge';
    if (result.status === 'passed') {
        statusBadge.classList.add('status-success');
        statusBadge.textContent = 'Пройдено';
    } else if (result.status === 'failed') {
        statusBadge.classList.add('status-failed');
        statusBadge.textContent = 'Ошибка';
    } else {
        statusBadge.classList.add('status-pending');
        statusBadge.textContent = 'Ожидание';
    }
    
    // Обновляем детали
    detailsContainer.innerHTML = '';
    result.details.forEach(detail => {
        const detailEl = document.createElement('div');
        detailEl.className = `test-detail ${detail.status}`;
        detailEl.innerHTML = `
            <div class="test-detail-header">
                <span class="test-detail-title">${detail.name}</span>
                <span class="test-detail-status ${detail.status}">
                    ${detail.status === 'pass' ? '✓' : '✗'}
                </span>
            </div>
            <div class="test-detail-message">${detail.message}</div>
            <div class="test-detail-time">
                <i class="fas fa-clock"></i> ${detail.time}ms
            </div>
        `;
        detailsContainer.appendChild(detailEl);
    });
    
    // Обновляем лог
    const logContainer = card.querySelector('.test-log');
    logContainer.innerHTML = '';
    result.log.forEach(line => {
        const logLine = document.createElement('div');
        logLine.className = `test-log-line ${line.type}`;
        logLine.textContent = `[${line.time}] ${line.message}`;
        logContainer.appendChild(logLine);
    });
}

// Обновление статуса теста
function updateTestStatus(card, status) {
    const badge = card.querySelector('.test-status-badge');
    badge.className = 'test-status-badge';
    
    if (status === 'running') {
        badge.classList.add('status-running');
        badge.innerHTML = '<span class="loading-spinner"></span> Выполняется...';
    }
}

// Переключение деталей теста
function toggleTestDetails(header) {
    const body = header.nextElementSibling;
    body.classList.toggle('show');
}

// Переключение лога
function toggleLog(button) {
    const log = button.closest('.test-card-body').querySelector('.test-log');
    if (log.style.display === 'none') {
        log.style.display = 'block';
        button.textContent = 'Скрыть лог';
    } else {
        log.style.display = 'none';
        button.textContent = 'Показать лог';
    }
}

// Обновление статистики
function updateStats() {
    let passed = 0, failed = 0;
    
    document.querySelectorAll('.test-card').forEach(card => {
        const status = card.querySelector('.test-status-badge').textContent;
        if (status === 'Пройдено') passed++;
        else if (status === 'Ошибка') failed++;
    });
    
    document.getElementById('passedTests').textContent = passed;
    document.getElementById('failedTests').textContent = failed;
}

// Показать прогресс
function showProgress() {
    document.getElementById('testProgress').style.display = 'block';
    let percent = 0;
    const interval = setInterval(() => {
        if (percent < 90) {
            percent += Math.random() * 10;
            if (percent > 90) percent = 90;
            updateProgress(percent);
        }
    }, 500);
    
    window.progressInterval = interval;
}

// Скрыть прогресс
function hideProgress() {
    clearInterval(window.progressInterval);
    updateProgress(100);
    setTimeout(() => {
        document.getElementById('testProgress').style.display = 'none';
        document.getElementById('progressBar').style.width = '0%';
        document.getElementById('progressBar').textContent = '0%';
    }, 500);
}

// Обновление прогресса
function updateProgress(percent) {
    document.getElementById('progressBar').style.width = percent + '%';
    document.getElementById('progressBar').textContent = Math.round(percent) + '%';
    document.getElementById('testProgressPercent').textContent = Math.round(percent) + '%';
}

// Очистка результатов
function clearResults() {
    if (confirm('Очистить все результаты тестов?')) {
        fetch('ajax_test_runner.php?action=clear')
            .then(() => {
                location.reload();
            });
    }
}

// Показать уведомление
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}
</script>

<?php require_once 'includes/footer.php'; ?>
