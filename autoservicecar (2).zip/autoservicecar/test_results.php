 <?php
require_once 'config/database.php';
require_once 'includes/auth.php';

checkAdmin();

$pageTitle = "История тестирования";

require_once 'includes/header.php';
?>

<div class="container mt-4">
    <h1><i class="fas fa-history"></i> История тестирования</h1>
    
    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Тест</th>
                        <th>Результат</th>
                        <th>Время</th>
                        <th>Детали</th>
                    </tr>
                </thead>
                <tbody id="historyTable">
                    <!-- Загружается через AJAX -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Загрузка истории
fetch('ajax_test_runner.php?action=history')
    .then(response => response.json())
    .then(data => {
        const tbody = document.getElementById('historyTable');
        data.forEach(item => {
            tbody.innerHTML += `
                <tr>
                    <td>${item.date}</td>
                    <td>${item.test}</td>
                    <td><span class="badge bg-${item.status === 'passed' ? 'success' : 'danger'}">${item.status}</span></td>
                    <td>${item.time}ms</td>
                    <td><button class="btn btn-sm btn-info" onclick="showDetails(${item.id})">Просмотр</button></td>
                </tr>
            `;
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>
