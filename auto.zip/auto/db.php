<?php
// db.php
$host = 'localhost';          // Обычно localhost, но если хостинг указывает другой IP, впишите его
$db   = 'project_Karachkin';  // Имя базы данных
$user = 'Karachkin';          // Логин из скриншота
$pass = '*iNPsB2D[4NO!Hfx';   // Пароль из скриншота (обязательно в кавычках!)

// Создаем подключение
$conn = new mysqli($host, $user, $pass, $db);

// Проверяем на ошибки
if ($conn->connect_error) {
    die("Ошибка подключения к БД: " . $conn->connect_error);
}

// Устанавливаем кодировку (важно для кириллицы!)
$conn->set_charset("utf8mb4");
?>