<?php
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор имеет доступ
checkAdmin();

$pageTitle = "Нагрузочное тестирование";

// Получение списка результатов
$resultsDir = __DIR__ . '/../selenium_load_tests/results/';
$reportsDir = __DIR__ . '/../selenium_load_tests/reports/';

$results = [];
if (is_dir($resultsDir)) {
    $files = glob($resultsDir . '*.json');
    foreach ($files as $file) {
        $data = json_decode(file_get_contents($file), true);
        if ($data) {
            $results[] = [
                'file' => basename($file),
                'test_name' => $data['test_name'] ?? 'Unknown',
                'start_time' => $data['start_time'] ?? '',
                'duration' => $data['duration_seconds'] ?? 0,
                'load_profile' => $data['load_profile'] ?? 'unknown',
                'total_requests' => $data['statistics']['total_requests'] ?? 0,
                'error_rate' => $data['statistics']['error_rate'] ?? 0,
                'avg_response_time' => $data['statistics']['avg_response_time_ms'] ?? 0
            ];
        }
    }
    // Сортировка по дате (новые первые)
    usort($results, function($a, $b) {
        return strtotime($b['start_time']) - strtotime($a['start_time']);
    });
}

// Получение списка отчетов
$reports = [];
if (is_dir($reportsDir)) {
    $reports = glob($reportsDir . 'report_*.html');
    $reports = array_map('basename', $reports);
    rsort($reports);
}

require_once '../includes/header.php';
?>

<style>
    :root {
        --load-primary: #2c3e50;
        --load-success: #27ae60;
        --load-warning: #f39c12;
        --load-danger: #e74c3c;
        --load-info: #3498db;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 15px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        transition: transform 0.3s;
        cursor: pointer;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
    }
    
    .stat-value {
        font-size: 2.5em;
        font-weight: 700;
        color: var(--load-primary);
    }
    
    .stat-label {
        color: #7f8c8d;
        font-size: 0.85em;
        margin-top: 5px;
    }
    
    .test-controls {
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
        margin-bottom: 30px;
    }
    
    .test-btn {
        padding: 12px 25px;
        border: none;
        border-radius: 10px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: inline-flex;
        align-items: center;
        gap: 10px;
    }
    
    .test-btn-primary {
        background: linear-gradient(135deg, var(--load-primary), #34495e);
        color: white;
    }
    
    .test-btn-success {
        background: linear-gradient(135deg, var(--load-success), #1e8449);
        color: white;
    }
    
    .test-btn-warning {
        background: linear-gradient(135deg, var(--load-warning), #d68910);
        color: white;
    }
    
    .test-btn-danger {
        background: linear-gradient(135deg, var(--load-danger), #c0392b);
        color: white;
    }
    
    .test-btn-info {
        background: linear-gradient(135deg, var(--load-info), #2980b9);
        color: white;
    }
    
    .test-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .test-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
    
    .progress-container {
        background: white;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 30px;
        display: none;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .progress-bar {
        height: 30px;
        background: #ecf0f1;
        border-radius: 15px;
        overflow: hidden;
        margin: 15px 0;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--load-success), var(--load-info));
        width: 0%;
        display: flex;
        align-items: center;
        justify-content: flex-end;
        padding-right: 10px;
        color: white;
        font-weight: 600;
        transition: width 0.3s;
        border-radius: 15px;
    }
    
    .log-container {
        background: #2c3e50;
        color: #0f0;
        padding: 20px;
        border-radius: 15px;
        font-family: 'Courier New', monospace;
        font-size: 13px;
        max-height: 400px;
        overflow-y: auto;
        margin-top: 20px;
        display: none;
    }
    
    .log-line {
        margin: 5px 0;
        padding: 3px 0;
        border-bottom: 1px solid #34495e;
    }
    
    .log-line.error { color: #e74c3c; }
    .log-line.success { color: #2ecc71; }
    .log-line.warning { color: #f39c12; }
    
    .results-table {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.08);
    }
    
    .results-table table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .results-table th,
    .results-table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .results-table th {
        background: #f8f9fa;
        color: var(--load-primary);
        font-weight: 600;
    }
    
    .results-table tr:hover {
        background: #f8f9fa;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75em;
        font-weight: 600;
    }
    
    .status-good { background: rgba(39, 174, 96, 0.15); color: #27ae60; }
    .status-warning { background: rgba(243, 156, 18, 0.15); color: #f39c12; }
    .status-bad { background: rgba(231, 76, 60, 0.15); color: #e74c3c; }
    
    .action-btn {
        padding: 5px 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 0.8em;
        margin: 0 2px;
    }
    
    .action-btn.view {
        background: #3498db;
        color: white;
    }
    
    .action-btn.delete {
        background: #e74c3c;
        color: white;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        justify-content: center;
        align-items: center;
    }
    
    .modal-content {
        background: white;
        border-radius: 15px;
        width: 90%;
        max-width: 500px;
        padding: 20px;
    }
    
    .modal-header {
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .modal-footer {
        margin-top: 20px;
        padding-top: 10px;
        border-top: 1px solid #ecf0f1;
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        display: none;
        z-index: 1100;
    }
    
    .toast.success { border-left: 4px solid var(--load-success); }
    .toast.error { border-left: 4px solid var(--load-danger); }
    .toast.info { border-left: 4px solid var(--load-info); }
    
    .report-frame {
        width: 100%;
        height: 600px;
        border: none;
        border-radius: 15px;
        background: white;
        display: none;
        margin-top: 20px;
    }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>
            <i class="fas fa-tachometer-alt"></i> Нагрузочное тестирование
        </h1>
        <div>
            <button class="btn btn-primary" onclick="refreshPage()">
                <i class="fas fa-sync-alt"></i> Обновить
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left"></i> Назад
            </a>
        </div>
    </div>
    
    <!-- Статистика -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?php echo count($results); ?></div>
            <div class="stat-label">Выполнено тестов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?php echo count($reports); ?></div>
            <div class="stat-label">Отчетов</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" id="avgResponseTime">-</div>
            <div class="stat-label">Среднее время ответа</div>
        </div>
        <div class="stat-card">
            <div class="stat-value" id="avgErrorRate">-</div>
            <div class="stat-label">Средний % ошибок</div>
        </div>
    </div>
    
    <!-- Кнопки управления -->
    <div class="test-controls">
        <button class="test-btn test-btn-primary" onclick="runLoadTest('smoke')">
            <i class="fas fa-fire"></i> Дымовой тест
        </button>
        <button class="test-btn test-btn-success" onclick="runLoadTest('load')">
            <i class="fas fa-chart-line"></i> Нагрузочный тест
        </button>
        <button class="test-btn test-btn-warning" onclick="runLoadTest('stress')">
            <i class="fas fa-bomb"></i> Стресс-тест
        </button>
        <button class="test-btn test-btn-info" onclick="runLoadTest('soak')">
            <i class="fas fa-hourglass-half"></i> Длительный тест
        </button>
        <button class="test-btn test-btn-danger" onclick="runLoadTest('spike')">
            <i class="fas fa-chart-line"></i> Spike-тест
        </button>
    </div>
    
    <!-- Прогресс выполнения -->
    <div id="progressContainer" class="progress-container">
        <div id="progressStatus">
            <i class="fas fa-spinner fa-spin"></i> Выполнение тестов...
        </div>
        <div class="progress-bar">
            <div id="progressFill" class="progress-fill" style="width: 0%;">0%</div>
        </div>
    </div>
    
    <!-- Лог выполнения -->
    <div id="logContainer" class="log-container">
        <div id="logContent"></div>
    </div>
    
    <!-- Результаты тестов -->
    <div class="results-table">
        <div style="padding: 15px 20px; background: linear-gradient(135deg, var(--load-primary), #34495e); color: white;">
            <i class="fas fa-history"></i> История тестирования
        </div>
        <div style="overflow-x: auto;">
            <table id="resultsTable">
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Тест</th>
                        <th>Профиль</th>
                        <th>Длительность</th>
                        <th>Запросов</th>
                        <th>Ошибки</th>
                        <th>Среднее время</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $result): ?>
                    <tr data-file="<?php echo htmlspecialchars($result['file']); ?>">
                        <td><?php echo date('d.m.Y H:i:s', strtotime($result['start_time'])); ?></td>
                        <td><?php echo htmlspecialchars($result['test_name']); ?></td>
                        <td>
                            <span class="status-badge status-<?php 
                                echo $result['load_profile'] == 'smoke' ? 'good' : 
                                    ($result['load_profile'] == 'load' ? 'warning' : 'bad'); 
                            ?>">
                                <?php echo ucfirst($result['load_profile']); ?>
                            </span>
                        </td>
                        <td><?php echo $result['duration']; ?> сек</td>
                        <td><?php echo number_format($result['total_requests']); ?></td>
                        <td class="<?php echo $result['error_rate'] > 5 ? 'text-danger' : 'text-success'; ?>">
                            <?php echo $result['error_rate']; ?>%
                        </td>
                        <td><?php echo round($result['avg_response_time']); ?> ms</td>
                        <td>
                            <button class="action-btn view" onclick="viewResult('<?php echo htmlspecialchars($result['file']); ?>')">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn delete" onclick="deleteResult('<?php echo htmlspecialchars($result['file']); ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($results)): ?>
                    <tr>
                        <td colspan="8" class="text-center">Нет результатов тестирования</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Отчет -->
    <iframe id="reportFrame" class="report-frame" src=""></iframe>
</div>

<!-- Модальное окно подтверждения -->
<div id="confirmModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 id="confirmTitle">Подтверждение</h5>
        </div>
        <div id="confirmMessage" class="modal-body">
            Вы уверены?
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal()">Отмена</button>
            <button id="confirmBtn" class="btn btn-danger">Подтвердить</button>
        </div>
    </div>
</div>

<!-- Toast уведомление -->
<div id="toast" class="toast">
    <span id="toastMessage"></span>
</div>

<script>
let confirmCallback = null;
let currentProgressInterval = null;

// Запуск нагрузочного теста
function runLoadTest(profile) {
    const profiles = {
        'smoke': 'Дымовой тест (5 пользователей, 1 мин)',
        'load': 'Нагрузочный тест (50 пользователей, 5 мин)',
        'stress': 'Стресс-тест (200 пользователей, 10 мин)',
        'soak': 'Длительный тест (30 пользователей, 1 час)',
        'spike': 'Spike-тест (внезапная нагрузка)'
    };
    
    confirmCallback = () => {
        showProgress();
        addLog(`🚀 Запуск ${profiles[profile]}...`, 'info');
        
        fetch('../api/load_test_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'run', profile: profile })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                addLog(`✅ Тест завершен!`, 'success');
                addLog(`📊 Результат: ${data.result || 'Успешно'}`, 'info');
                showToast('Тест завершен', 'success');
                setTimeout(() => location.reload(), 2000);
            } else {
                addLog(`❌ Ошибка: ${data.error}`, 'error');
                showToast('Ошибка выполнения теста', 'error');
            }
            hideProgress();
            if (currentProgressInterval) clearInterval(currentProgressInterval);
        })
        .catch(error => {
            addLog(`❌ Ошибка: ${error}`, 'error');
            hideProgress();
            showToast('Ошибка выполнения теста', 'error');
        });
    };
    showConfirm('Запуск теста', `Запустить ${profiles[profile]}? Это может занять некоторое время.`);
}

// Просмотр результата
function viewResult(filename) {
    showToast('Загрузка отчета...', 'info');
    
    // Загружаем JSON данные
    fetch(`../selenium_load_tests/results/${filename}`)
        .then(response => response.json())
        .then(data => {
            // Показываем отчет в iframe
            const reportFrame = document.getElementById('reportFrame');
            
            // Генерируем HTML отчет
            const html = generateReportHTML(data);
            const blob = new Blob([html], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            reportFrame.src = url;
            reportFrame.style.display = 'block';
            
            // Скроллим к отчету
            reportFrame.scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            showToast('Отчет загружен', 'success');
        })
        .catch(error => {
            showToast('Ошибка загрузки отчета: ' + error, 'error');
        });
}

// Удаление результата
function deleteResult(filename) {
    confirmCallback = () => {
        showToast('Удаление...', 'info');
        
        fetch('../api/load_test_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete', filename: filename })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Результат удален', 'success');
                location.reload();
            } else {
                showToast('Ошибка: ' + data.error, 'error');
            }
        });
    };
    showConfirm('Удаление результата', 'Вы уверены, что хотите удалить этот результат?');
}

// Генерация HTML отчета
function generateReportHTML(data) {
    const stats = data.statistics;
    const statusColor = stats.error_rate <= 5 ? '#27ae60' : '#e74c3c';
    const statusText = stats.error_rate <= 5 ? 'ПРОЙДЕН' : 'НЕ ПРОЙДЕН';
    
    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Отчет нагрузочного тестирования</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; border-radius: 10px; padding: 20px; }
        h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }
        .status { display: inline-block; padding: 5px 15px; border-radius: 20px; background: ${statusColor}; color: white; font-weight: bold; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .stat-card { background: #f8f9fa; padding: 15px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 28px; font-weight: bold; color: #2c3e50; }
        .stat-label { color: #7f8c8d; font-size: 12px; margin-top: 5px; }
        .metric-good { color: #27ae60; }
        .metric-bad { color: #e74c3c; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #2c3e50; color: white; }
        .footer { margin-top: 30px; text-align: center; color: #95a5a6; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Отчет нагрузочного тестирования</h1>
        <p><strong>Тест:</strong> ${data.test_name}</p>
        <p><strong>Время запуска:</strong> ${data.start_time}</p>
        <p><strong>Длительность:</strong> ${data.duration_seconds} сек</p>
        <p><strong>Профиль:</strong> ${data.load_profile}</p>
        <p><strong>Статус:</strong> <span class="status">${statusText}</span></p>
        
        <h2>Статистика</h2>
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-value">${stats.total_requests}</div><div class="stat-label">Всего запросов</div></div>
            <div class="stat-card"><div class="stat-value">${stats.successful_requests}</div><div class="stat-label">Успешных</div></div>
            <div class="stat-card"><div class="stat-value">${stats.failed_requests}</div><div class="stat-label">Ошибок</div></div>
            <div class="stat-card"><div class="stat-value">${stats.error_rate}%</div><div class="stat-label">Процент ошибок</div></div>
            <div class="stat-card"><div class="stat-value">${stats.avg_response_time_ms} ms</div><div class="stat-label">Среднее время</div></div>
            <div class="stat-card"><div class="stat-value">${stats.max_response_time_ms} ms</div><div class="stat-label">Максимальное</div></div>
            <div class="stat-card"><div class="stat-value">${stats.min_response_time_ms} ms</div><div class="stat-label">Минимальное</div></div>
            <div class="stat-card"><div class="stat-value">${stats.p95_response_time_ms} ms</div><div class="stat-label">P95</div></div>
            <div class="stat-card"><div class="stat-value">${stats.p99_response_time_ms} ms</div><div class="stat-label">P99</div></div>
        </div>
        <div class="footer">Отчет сгенерирован системой нагрузочного тестирования</div>
    </div>
</body>
</html>`;
}

// Показать прогресс
function showProgress() {
    document.getElementById('progressContainer').style.display = 'block';
    document.getElementById('logContainer').style.display = 'block';
    
    let percent = 0;
    currentProgressInterval = setInterval(() => {
        if (percent < 90) {
            percent += Math.random() * 10;
            if (percent > 90) percent = 90;
            updateProgress(percent);
        }
    }, 500);
}

// Скрыть прогресс
function hideProgress() {
    if (currentProgressInterval) clearInterval(currentProgressInterval);
    updateProgress(100);
    setTimeout(() => {
        document.getElementById('progressContainer').style.display = 'none';
        document.getElementById('progressFill').style.width = '0%';
        document.getElementById('progressFill').textContent = '0%';
    }, 1000);
}

function updateProgress(percent) {
    const fill = document.getElementById('progressFill');
    fill.style.width = percent + '%';
    fill.textContent = Math.round(percent) + '%';
}

function addLog(message, type = 'info') {
    const logContent = document.getElementById('logContent');
    const time = new Date().toLocaleTimeString();
    const logLine = document.createElement('div');
    logLine.className = `log-line ${type}`;
    logLine.innerHTML = `<span style="color: #888;">[${time}]</span> ${message}`;
    logContent.appendChild(logLine);
    logContent.scrollTop = logContent.scrollHeight;
}

function showConfirm(title, message) {
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmMessage').innerHTML = message;
    document.getElementById('confirmModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('confirmModal').style.display = 'none';
    confirmCallback = null;
}

document.getElementById('confirmBtn').onclick = () => {
    if (confirmCallback) confirmCallback();
    closeModal();
};

function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.className = `toast ${type}`;
    document.getElementById('toastMessage').innerHTML = message;
    toast.style.display = 'block';
    setTimeout(() => { toast.style.display = 'none'; }, 3000);
}

function refreshPage() { location.reload(); }

// Расчет средних значений
<?php if (!empty($results)): 
    $avgTime = array_sum(array_column($results, 'avg_response_time')) / count($results);
    $avgError = array_sum(array_column($results, 'error_rate')) / count($results);
?>
document.getElementById('avgResponseTime').textContent = '<?php echo round($avgTime); ?> ms';
document.getElementById('avgErrorRate').textContent = '<?php echo round($avgError, 1); ?>%';
<?php endif; ?>

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) closeModal();
}
</script>

<?php require_once '../includes/footer.php'; ?> 
