<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

// Только администратор
checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'run':
                $testType = $input['test_type'] ?? 'all';
                $response = runSeleniumTests($testType);
                break;
                
            case 'clear_screenshots':
                $response = clearScreenshots();
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';
        
        switch ($action) {
            case 'list_screenshots':
                $response = listScreenshots();
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

// ============================================
// Функции
// ============================================

function runSeleniumTests($testType)
{
    $seleniumDir = __DIR__ . '/../selenium_tests/';
    $runScript = $seleniumDir . 'run_tests.php';
    
    if (!file_exists($runScript)) {
        return ['error' => 'Скрипт run_tests.php не найден'];
    }
    
    // Определение группы тестов
    $group = '';
    switch ($testType) {
        case 'functional':
            $group = '--group functional';
            break;
        case 'smoke':
            $group = '--group smoke';
            break;
        case 'auth':
            $group = '--group auth';
            break;
        case 'cars':
            $group = '--group cars';
            break;
        case 'orders':
            $group = '--group orders';
            break;
        default:
            $group = '';
    }
    
    // Запуск тестов
    $command = "cd " . escapeshellarg($seleniumDir) . " && php run_tests.php " . $group . " 2>&1";
    $output = shell_exec($command);
    
    // Поиск отчета
    $reportsDir = $seleniumDir . 'reports/';
    $reports = glob($reportsDir . 'test_report_*.html');
    
    if (!empty($reports)) {
        usort($reports, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        $reportUrl = 'selenium_tests/reports/' . basename($reports[0]);
        
        return [
            'success' => true,
            'result' => $output,
            'report_url' => $reportUrl
        ];
    }
    
    return [
        'success' => true,
        'result' => $output
    ];
}

function listScreenshots()
{
    $screenshotsDir = __DIR__ . '/../selenium_tests/screenshots/';
    $screenshots = [];
    
    if (is_dir($screenshotsDir)) {
        $files = glob($screenshotsDir . '*.png');
        foreach ($files as $file) {
            $screenshots[] = [
                'file' => basename($file),
                'name' => str_replace('_', ' ', pathinfo($file, PATHINFO_FILENAME)),
                'date' => date('Y-m-d H:i:s', filemtime($file)),
                'size' => round(filesize($file) / 1024, 2) . ' KB'
            ];
        }
        // Сортировка по дате (новые первые)
        usort($screenshots, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });
    }
    
    return ['success' => true, 'screenshots' => $screenshots];
}

function clearScreenshots()
{
    $screenshotsDir = __DIR__ . '/../selenium_tests/screenshots/';
    $count = 0;
    
    if (is_dir($screenshotsDir)) {
        $files = glob($screenshotsDir . '*.png');
        foreach ($files as $file) {
            if (unlink($file)) {
                $count++;
            }
        }
    }
    
    return ['success' => true, 'deleted' => $count];
}
?> 
