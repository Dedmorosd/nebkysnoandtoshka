<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../includes/auth.php';

checkAdmin();

$response = [];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'run':
                $profile = $input['profile'] ?? 'smoke';
                $response = runLoadTest($profile);
                break;
                
            case 'delete':
                $filename = $input['filename'] ?? '';
                $response = deleteResult($filename);
                break;
                
            default:
                $response = ['error' => 'Неизвестное действие'];
        }
    }
} catch (Exception $e) {
    $response = ['error' => $e->getMessage()];
}

echo json_encode($response);

function runLoadTest($profile)
{
    $loadTestDir = __DIR__ . '/../selenium_load_tests/';
    $runScript = $loadTestDir . 'run_load_tests.php';
    
    if (!file_exists($runScript)) {
        return ['error' => 'Скрипт run_load_tests.php не найден'];
    }
    
    putenv("LOAD_PROFILE=$profile");
    
    $command = "cd " . escapeshellarg($loadTestDir) . " && php run_load_tests.php --profile=$profile 2>&1";
    $output = shell_exec($command);
    
    return [
        'success' => true,
        'result' => $output,
        'profile' => $profile
    ];
}

function deleteResult($filename)
{
    $resultsDir = __DIR__ . '/../selenium_load_tests/results/';
    $filepath = $resultsDir . $filename;
    
    if (!file_exists($filepath)) {
        return ['error' => 'Файл не найден'];
    }
    
    unlink($filepath);
    
    // Удаляем соответствующий HTML отчет
    $reportFile = $resultsDir . 'report_' . pathinfo($filename, PATHINFO_FILENAME) . '.html';
    if (file_exists($reportFile)) {
        unlink($reportFile);
    }
    
    return ['success' => true];
}
?> 
