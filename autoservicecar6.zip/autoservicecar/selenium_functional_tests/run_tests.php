#!/usr/bin/env php
<?php
echo "\n";
echo "═══════════════════════════════════════════════════════════════════\n";
echo "        ФУНКЦИОНАЛЬНОЕ ТЕСТИРОВАНИЕ ВЕБ-СЕРВИСА\n";
echo "                   Selenium WebDriver\n";
echo "═══════════════════════════════════════════════════════════════════\n\n";

$config = require __DIR__ . '/config/config.php';

echo "📋 Конфигурация:\n";
echo "   • URL: {$config['app_url']}\n";
echo "   • Браузер: {$config['webdriver']['browser']}\n";
echo "   • Headless: " . ($config['webdriver']['headless'] ? 'Да' : 'Нет') . "\n";
echo "   • Таймаут: {$config['timeouts']['explicit']} сек\n\n";

// Проверка ChromeDriver
echo "🔍 Проверка ChromeDriver... ";
$context = stream_context_create(['http' => ['timeout' => 2]]);
$response = @file_get_contents($config['webdriver']['host'] . '/status', false, $context);

if ($response !== false) {
    echo "✅ Запущен\n\n";
} else {
    echo "❌ Не запущен!\n\n";
    echo "Пожалуйста, запустите ChromeDriver:\n";
    echo "   chromedriver --port=9515\n\n";
    exit(1);
}

// Проверка сайта
echo "🔍 Проверка сайта... ";
$response = @file_get_contents($config['app_url'] . '/login.php', false, $context);

if ($response !== false) {
    echo "✅ Доступен\n\n";
} else {
    echo "❌ Недоступен\n\n";
    exit(1);
}

// Создание директорий
foreach (['screenshots', 'reports', 'logs'] as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (!is_dir($path)) {
        mkdir($path, 0777, true);
        echo "📁 Создана директория: $dir\n";
    }
}
echo "\n";

// Выбор типа тестов
$testTypes = [
    'all' => 'Все тесты',
    'functional' => 'Функциональные тесты',
    'smoke' => 'Smoke-тесты',
    'auth' => 'Тесты авторизации',
    'cars' => 'Тесты автомобилей',
    'orders' => 'Тесты заказов'
];

echo "Выберите тип тестов:\n";
foreach ($testTypes as $key => $name) {
    echo "  [$key] $name\n";
}
echo "\n";

$input = readline("Ваш выбор [all]: ");
$type = empty($input) ? 'all' : $input;

echo "\n🚀 Запуск тестов...\n\n";

$phpunit = __DIR__ . '/vendor/bin/phpunit';
$reportFile = __DIR__ . '/reports/test_report_' . date('Y-m-d_H-i-s') . '.html';

switch ($type) {
    case 'functional':
        $command = sprintf('%s tests/functional/ --testdox-html %s', $phpunit, $reportFile);
        break;
    case 'smoke':
        $command = sprintf('%s tests/smoke/ --testdox-html %s', $phpunit, $reportFile);
        break;
    case 'auth':
        $command = sprintf('%s --group auth --testdox-html %s', $phpunit, $reportFile);
        break;
    case 'cars':
        $command = sprintf('%s --group cars --testdox-html %s', $phpunit, $reportFile);
        break;
    case 'orders':
        $command = sprintf('%s --group orders --testdox-html %s', $phpunit, $reportFile);
        break;
    default:
        $command = sprintf('%s --testdox-html %s', $phpunit, $reportFile);
}

echo "Выполнение: $command\n\n";

system($command, $returnCode);

echo "\n";
echo "═══════════════════════════════════════════════════════════════════\n";
echo "                     РЕЗУЛЬТАТЫ\n";
echo "═══════════════════════════════════════════════════════════════════\n\n";

if (file_exists($reportFile)) {
    echo "✅ Тесты завершены\n";
    echo "📁 HTML отчет: $reportFile\n";
    echo "📁 Скриншоты: " . __DIR__ . "/screenshots/\n";
    echo "📁 Логи: " . __DIR__ . "/logs/\n\n";
} else {
    echo "❌ Отчет не создан\n\n";
}

echo "═══════════════════════════════════════════════════════════════════\n";

exit($returnCode); 
