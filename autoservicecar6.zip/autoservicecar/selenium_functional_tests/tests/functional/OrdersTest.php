<?php
namespace Autoservice\Tests\Functional;

class OrdersTest extends BaseFunctionalTest
{
    // ==================== ПОЗИТИВНЫЕ ТЕСТЫ ====================
    
    /**
     * @test
     * @group functional
     * @group orders
     * @group critical
     */
    public function testCreateOrder()
    {
        $dashboard = $this->loginAsClient();
        $this->assertTrue($dashboard->isLoaded());
        
        $initialOrdersCount = $dashboard->getOrdersCount();
        
        if ($dashboard->getCarsCount() == 0) {
            $carsPage = $dashboard->goToAddCar();
            $carsPage->addCar([
                'brand' => 'Toyota',
                'model' => 'Camry',
                'year' => '2020',
                'license_plate' => $this->generateUniquePlate()
            ]);
            $dashboard->refresh();
        }
        
        $createOrderPage = $dashboard->goToCreateOrder();
        $this->assertTrue($createOrderPage->isOnPage());
        
        $orderData = [
            'car_id' => '1',
            'services' => ['1', '2'],
            'description' => 'Тестовый заказ через Selenium',
            'preferred_date' => date('Y-m-d', strtotime('+3 days'))
        ];
        
        $createOrderPage->createOrder($orderData);
        
        $this->assertTrue($createOrderPage->hasSuccess(), "Заказ не создан");
        
        $successMessage = $createOrderPage->getSuccessMessage();
        $this->assertStringContainsString('Заказ успешно создан', $successMessage);
        
        $dashboard->refresh();
        $newOrdersCount = $dashboard->getOrdersCount();
        $this->assertEquals($initialOrdersCount + 1, $newOrdersCount);
        
        $createOrderPage->takeScreenshot('order_created');
    }
    
    /**
     * @test
     * @group functional
     * @group orders
     * @group positive
     */
    public function testTotalPriceCalculation()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        $createOrderPage->selectCar('1');
        
        $initialTotal = $createOrderPage->getTotalAmount();
        
        $createOrderPage->selectServices(['1']);
        $totalWithOne = $createOrderPage->getTotalAmount();
        $this->assertGreaterThan($initialTotal, $totalWithOne);
        
        $createOrderPage->selectServices(['1', '2']);
        $totalWithTwo = $createOrderPage->getTotalAmount();
        $this->assertGreaterThan($totalWithOne, $totalWithTwo);
        
        $createOrderPage->selectServices(['2']);
        $totalWithOneAgain = $createOrderPage->getTotalAmount();
        $this->assertEquals($totalWithOne, $totalWithOneAgain);
        
        $createOrderPage->takeScreenshot('price_calculation');
    }
    
    // ==================== НЕГАТИВНЫЕ ТЕСТЫ ====================
    
    /**
     * @test
     * @group functional
     * @group orders
     * @group negative
     */
    public function testCreateOrderWithoutCar()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        $createOrderPage->selectServices(['1', '2'])
            ->setDescription('Тестовый заказ')
            ->setPreferredDate(date('Y-m-d', strtotime('+3 days')))
            ->submit();
        
        $this->assertTrue($createOrderPage->isOnPage(), "Форма отправилась без выбора автомобиля");
        
        $createOrderPage->takeScreenshot('order_without_car');
    }
    
    /**
     * @test
     * @group functional
     * @group orders
     * @group negative
     */
    public function testCreateOrderWithoutServices()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        $createOrderPage->selectCar('1')
            ->setDescription('Тестовый заказ')
            ->setPreferredDate(date('Y-m-d', strtotime('+3 days')))
            ->submit();
        
        $this->assertTrue($createOrderPage->hasError(), "Заказ создан без услуг");
        
        $errorMessage = $createOrderPage->getErrorMessage();
        $this->assertStringContainsString('услуг', $errorMessage);
        
        $createOrderPage->takeScreenshot('order_without_services');
    }
    
    /**
     * @test
     * @group functional
     * @group orders
     * @group negative
     */
    public function testCreateOrderWithPastDate()
    {
        $dashboard = $this->loginAsClient();
        $createOrderPage = $dashboard->goToCreateOrder();
        
        $createOrderPage->selectCar('1')
            ->selectServices(['1', '2'])
            ->setDescription('Тестовый заказ')
            ->setPreferredDate(date('Y-m-d', strtotime('-1 day')))
            ->submit();
        
        $this->assertTrue($createOrderPage->hasError(), "Заказ создан с прошедшей датой");
        
        $errorMessage = $createOrderPage->getErrorMessage();
        $this->assertStringContainsString('прошлом', $errorMessage);
        
        $createOrderPage->takeScreenshot('order_past_date');
    }
}