<?php
namespace Autoservice\Tests\Smoke;

use Autoservice\Tests\Functional\BaseFunctionalTest;

class SmokeTest extends BaseFunctionalTest
{
    /**
     * @test
     * @group smoke
     * @group critical
     */
    public function testHomePageLoads()
    {
        $this->driver->get($this->config['app_url']);
        $title = $this->driver->getTitle();
        
        $this->assertNotEmpty($title, "Заголовок страницы пуст");
        $this->assertStringContainsString('Автосервис', $title);
        
        $this->driver->takeScreenshot('homepage');
    }
    
    /**
     * @test
     * @group smoke
     * @group critical
     */
    public function testLoginPageLoads()
    {
        $this->loginPage->open();
        
        $this->assertTrue($this->loginPage->isOnPage(), "Страница входа не загрузилась");
        
        $this->loginPage->takeScreenshot('login_page');
    }
    
    /**
     * @test
     * @group smoke
     * @group critical
     */
    public function testAdminLogin()
    {
        $dashboard = $this->loginAsAdmin();
        
        $this->assertTrue($dashboard->isLoaded(), "Dashboard не загрузился после входа администратора");
        $this->assertTrue($dashboard->hasAdminPanel(), "Админ-панель недоступна");
        
        $dashboard->takeScreenshot('admin_smoke');
    }
    
    /**
     * @test
     * @group smoke
     * @group critical
     */
    public function testClientLogin()
    {
        $dashboard = $this->loginAsClient();
        
        $this->assertTrue($dashboard->isLoaded(), "Dashboard не загрузился после входа клиента");
        $this->assertFalse($dashboard->hasAdminPanel(), "Клиент видит админ-панель");
        
        $dashboard->takeScreenshot('client_smoke');
    }
    
    /**
     * @test
     * @group smoke
     * @group critical
     */
    public function testLogoutFunctionality()
    {
        $dashboard = $this->loginAsClient();
        $this->assertTrue($dashboard->isLoaded());
        
        $loginPage = $dashboard->logout();
        
        $this->assertTrue($loginPage->isOnPage(), "Не удалось выйти из системы");
        
        $loginPage->takeScreenshot('logout_smoke');
    }
    
    /**
     * @test
     * @group smoke
     * @group critical
     */
    public function testDatabaseConnection()
    {
        $this->driver->get($this->config['app_url'] . '/dashboard.php');
        
        $currentUrl = $this->driver->getCurrentURL();
        
        $this->assertTrue(
            strpos($currentUrl, 'login.php') !== false || 
            strpos($currentUrl, 'dashboard.php') !== false,
            "Проблема с подключением к базе данных"
        );
    }
} 
