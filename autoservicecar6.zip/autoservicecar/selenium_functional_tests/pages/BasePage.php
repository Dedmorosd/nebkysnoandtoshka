<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;
use Facebook\WebDriver\WebDriverWait;
use Facebook\WebDriver\Exception\TimeoutException;

abstract class BasePage
{
    protected $driver;
    protected $wait;
    protected $config;
    protected $url;
    
    public function __construct(RemoteWebDriver $driver, array $config)
    {
        $this->driver = $driver;
        $this->config = $config;
        
        $this->wait = new WebDriverWait($driver, $config['timeouts']['explicit']);
        $this->driver->manage()->timeouts()->implicitlyWait($config['timeouts']['implicit']);
        
        if (!$config['webdriver']['headless']) {
            $this->driver->manage()->window()->maximize();
        } else {
            $this->driver->manage()->window()->setSize(
                new \Facebook\WebDriver\WebDriverDimension(
                    $config['webdriver']['window_size']['width'],
                    $config['webdriver']['window_size']['height']
                )
            );
        }
    }
    
    public function open()
    {
        if ($this->url) {
            $this->driver->get($this->config['app_url'] . $this->url);
        }
        return $this;
    }
    
    protected function findElement($selector, $timeout = null)
    {
        $wait = $timeout ? new WebDriverWait($this->driver, $timeout) : $this->wait;
        
        try {
            return $wait->until(
                WebDriverExpectedCondition::presenceOfElementLocated($selector)
            );
        } catch (TimeoutException $e) {
            $this->takeScreenshot('element_not_found');
            throw $e;
        }
    }
    
    protected function click($selector)
    {
        $this->findElement($selector)->click();
        return $this;
    }
    
    protected function type($selector, $text)
    {
        $element = $this->findElement($selector);
        $element->clear();
        $element->sendKeys($text);
        return $this;
    }
    
    protected function getText($selector)
    {
        return $this->findElement($selector)->getText();
    }
    
    protected function isElementVisible($selector, $timeout = 3)
    {
        try {
            $wait = new WebDriverWait($this->driver, $timeout);
            $wait->until(
                WebDriverExpectedCondition::visibilityOfElementLocated($selector)
            );
            return true;
        } catch (TimeoutException $e) {
            return false;
        }
    }
    
    protected function waitForElement($selector, $timeout = null)
    {
        $wait = $timeout ? new WebDriverWait($this->driver, $timeout) : $this->wait;
        $wait->until(
            WebDriverExpectedCondition::presenceOfElementLocated($selector)
        );
        return $this;
    }
    
    protected function waitForUrl($partialUrl)
    {
        $this->wait->until(
            WebDriverExpectedCondition::urlContains($partialUrl)
        );
        return $this;
    }
    
    public function takeScreenshot($name)
    {
        $path = $this->config['paths']['screenshots'];
        if (!is_dir($path)) {
            mkdir($path, 0777, true);
        }
        
        $filename = $path . date('Y-m-d_H-i-s') . '_' . $name . '.png';
        $this->driver->takeScreenshot($filename);
        return $filename;
    }
    
    public function getCurrentUrl()
    {
        return $this->driver->getCurrentURL();
    }
    
    public function refresh()
    {
        $this->driver->navigate()->refresh();
        return $this;
    }
    
    abstract public function isOnPage();
} 
