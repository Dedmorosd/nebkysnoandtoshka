<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;

class DashboardPage extends BasePage
{
    protected $url = '/dashboard.php';
    
    private $pageTitle = WebDriverBy::xpath("//h1[contains(text(), 'Панель управления')]");
    private $userName = WebDriverBy::cssSelector('.navbar .user-name, .navbar .nav-link .fa-user + span');
    private $logoutLink = WebDriverBy::linkText('Выход');
    private $addCarButton = WebDriverBy::xpath("//a[contains(text(), 'Добавить автомобиль')]");
    private $createOrderButton = WebDriverBy::xpath("//a[contains(text(), 'Создать заказ')]");
    private $viewServicesButton = WebDriverBy::xpath("//a[contains(text(), 'Посмотреть услуги')]");
    private $myOrdersCard = WebDriverBy::xpath("//h6[contains(text(), 'Мои заказы')]/../h2");
    private $myCarsCard = WebDriverBy::xpath("//h6[contains(text(), 'Мои автомобили')]/../h2");
    private $adminPanelLink = WebDriverBy::xpath("//a[contains(text(), 'Админ панель')]");
    
    public function isLoaded()
    {
        return $this->isElementVisible($this->pageTitle);
    }
    
    public function getUserName()
    {
        return $this->getText($this->userName);
    }
    
    public function logout()
    {
        $this->click($this->logoutLink);
        return new LoginPage($this->driver, $this->config);
    }
    
    public function goToAddCar()
    {
        $this->click($this->addCarButton);
        return new CarsPage($this->driver, $this->config);
    }
    
    public function goToCreateOrder()
    {
        $this->click($this->createOrderButton);
        return new CreateOrderPage($this->driver, $this->config);
    }
    
    public function getOrdersCount()
    {
        if ($this->isElementVisible($this->myOrdersCard)) {
            return (int)$this->getText($this->myOrdersCard);
        }
        return 0;
    }
    
    public function getCarsCount()
    {
        if ($this->isElementVisible($this->myCarsCard)) {
            return (int)$this->getText($this->myCarsCard);
        }
        return 0;
    }
    
    public function hasAdminPanel()
    {
        return $this->isElementVisible($this->adminPanelLink);
    }
    
    public function isOnPage()
    {
        return $this->isElementVisible($this->pageTitle);
    }
} 
