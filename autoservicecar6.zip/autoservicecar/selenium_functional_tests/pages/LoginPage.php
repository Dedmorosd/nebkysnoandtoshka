<?php
namespace Autoservice\Pages;

use Facebook\WebDriver\WebDriverBy;

class LoginPage extends BasePage
{
    protected $url = '/login.php';
    
    private $usernameInput = WebDriverBy::name('username');
    private $passwordInput = WebDriverBy::name('password');
    private $loginButton = WebDriverBy::xpath("//button[@type='submit']");
    private $registerLink = WebDriverBy::linkText('Регистрация');
    private $errorMessage = WebDriverBy::className('alert-danger');
    private $successMessage = WebDriverBy::className('alert-success');
    
    public function login($username, $password)
    {
        $this->open()
             ->setUsername($username)
             ->setPassword($password)
             ->submit();
        
        return new DashboardPage($this->driver, $this->config);
    }
    
    public function setUsername($username)
    {
        $this->type($this->usernameInput, $username);
        return $this;
    }
    
    public function setPassword($password)
    {
        $this->type($this->passwordInput, $password);
        return $this;
    }
    
    public function submit()
    {
        $this->click($this->loginButton);
        return $this;
    }
    
    public function getErrorMessage()
    {
        if ($this->isElementVisible($this->errorMessage, 3)) {
            return $this->getText($this->errorMessage);
        }
        return null;
    }
    
    public function hasError()
    {
        return $this->isElementVisible($this->errorMessage);
    }
    
    public function isOnPage()
    {
        return $this->isElementVisible($this->loginButton);
    }
} 
