<?php
// index.php
session_start();

// 1. Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit;
}

// Подключаем базу данных
require 'db.php';

// Получаем данные из таблицы cars
$sql = "SELECT * FROM cars ORDER BY id DESC";
$result = $conn->query($sql);

// Проверяем роль пользователя
$isAdmin = (isset($_SESSION['role']) && $_SESSION['role'] === 'admin');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Автопарк КВН - Главная</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; }
        
        /* Красная полоса для админа */
        .admin-bar { background: #dc3545; color: white; text-align: center; padding: 8px; font-weight: bold; font-size: 14px; letter-spacing: 1px; }
        
        .navbar { background: #333; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .navbar a { color: white; text-decoration: none; margin-left: 15px; font-size: 14px; }
        .navbar a:hover { text-decoration: underline; }
        
        .container { padding: 20px; max-width: 1100px; margin: 0 auto; }
        
        .header-actions { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        
        .btn { padding: 10px 15px; background: #28a745; color: white; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; font-size: 14px; }
        .btn:hover { background: #218838; }
        .btn-admin { background: #007bff; }
        .btn-admin:hover { background: #0056b3; }
        
        table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background: #333; color: white; }
        
        /* Статусы машин */
        .status-available { color: #28a745; font-weight: bold; }
        .status-on_trip { color: #007bff; font-weight: bold; }
        .status-repair { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>

<!-- Если админ, показываем красную полосу -->
<?php if ($isAdmin): ?>
    <div class="admin-bar">РЕЖИМ АДМИНИСТРАТОРА (Полный доступ)</div>
<?php endif; ?>

<div class="navbar">
    <div><b>Автопарк КВН</b></div>
    <div>
        Привет, <b><?php echo htmlspecialchars($_SESSION['user_name']); ?></b>!
        <a href="auth.php?logout=1" style="color: #ff6b6b;">Выйти</a>
    </div>
</div>

<div class="container">
    <div class="header-actions">
        <h1 style="margin: 0;">Список автомобилей</h1>
        
        <div>
            <?php if ($isAdmin): ?>
                <!-- Кнопка доступна только админу -->
                <a href="dashboard.php" class="btn btn-admin">⚙️ Управление пользователями</a>
            <?php endif; ?>
            
            <a href="add_car.php" class="btn">+ Добавить авто</a>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Марка</th>
                <th>Модель</th>
                <th>Гос. номер</th>
                <th>Год</th>
                <th>Статус</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                // Выводим данные каждой машины
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td><b>" . htmlspecialchars($row['brand']) . "</b></td>";
                    echo "<td>" . htmlspecialchars($row['model']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['plate_number']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['year']) . "</td>";
                    
                    // Красиво выводим статус
                    $statusClass = 'status-' . htmlspecialchars($row['status']);
                    $statusText = htmlspecialchars($row['status']);
                    if ($statusText === 'available') $statusText = 'Свободен';
                    if ($statusText === 'on_trip') $statusText = 'В рейсе';
                    if ($statusText === 'repair') $statusText = 'На ремонте';
                    
                    echo "<td><span class='{$statusClass}'>{$statusText}</span></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6' style='text-align:center;'>В базе пока нет машин</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>