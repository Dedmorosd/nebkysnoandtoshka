<?php
// auth.php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'db.php';

// Обработка выхода
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: auth.php");
    exit;
}

// --- ИНИЦИАЛИЗАЦИЯ ПАЗЛА ---
if (!isset($_SESSION['puzzle_state']) || isset($_GET['refresh'])) {
    // Создаем эталонный массив (1, 2, 3, 4)
    $tiles = [1, 2, 3, 4];
    
    // Перемешиваем, чтобы изначально пазл был НЕ собран
    do {
        shuffle($tiles);
    } while ($tiles === [1, 2, 3, 4]);
    
    $_SESSION['puzzle_state'] = $tiles;
}

$message = '';
$msgType = 'error';

// --- ОБРАБОТКА ВХОДА ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signin'])) {
    $login = trim($_POST['login'] ?? '');
    $pass  = $_POST['pass'] ?? '';
    
    // Получаем состояние пазла, которое отправил браузер (например, "3,1,4,2")
    $submitted_puzzle = explode(',', $_POST['puzzle_state'] ?? '');
    $submitted_puzzle = array_map('intval', $submitted_puzzle);

    // Проверяем, собран ли пазл (должен быть строго 1, 2, 3, 4)
    $isPuzzleValid = ($submitted_puzzle === [1, 2, 3, 4]);
    
    // Ищем пользователя
    $stmt = $conn->prepare("SELECT id, full_name, password, role, failed_attempts, is_blocked FROM users WHERE email = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        $message = "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные";
    } elseif ($user['is_blocked'] == 1) {
        $message = "Вы заблокированы. Обратитесь к администратору";
    } else {
        // Проверяем пароль И пазл
        if (password_verify($pass, $user['password']) && $isPuzzleValid) {
            // УСПЕХ
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            
            // Сбрасываем счетчик ошибок
            $conn->query("UPDATE users SET failed_attempts = 0 WHERE id = {$user['id']}");
            
            $message = "Вы успешно авторизовались";
            $msgType = 'success';
            unset($_SESSION['puzzle_state']); // Очищаем пазл
        } else {
            // ОШИБКА (пароль или пазл)
            $attempts = $user['failed_attempts'] + 1;
            $conn->query("UPDATE users SET failed_attempts = $attempts WHERE id = {$user['id']}");
            
            if ($attempts >= 3) {
                $conn->query("UPDATE users SET is_blocked = 1 WHERE id = {$user['id']}");
                $message = "Вы заблокированы. Обратитесь к администратору";
            } else {
                if (!$isPuzzleValid) {
                    $message = "❌ Пазл собран неверно! Пожалуйста, соберите картинку. (Попытка $attempts из 3)";
                } else {
                    $message = "❌ Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные (Попытка $attempts из 3)";
                }
            }
            
            // Перемешиваем пазл заново при ошибке
            unset($_SESSION['puzzle_state']);
            // Не делаем редирект, чтобы пользователь видел ошибку
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Авторизация с пазлом</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #eef1f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 6px 24px rgba(0,0,0,.08); width: 380px; }
        
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 6px; font-size: 14px; }
        .alert-error { background: #fef2f2; border: 1px solid #f87171; color: #991b1b; }
        .alert-success { background: #f0fdf4; border: 1px solid #4ade80; color: #166534; }
        
        .field { margin-bottom: 15px; }
        .field input { width: 100%; padding: 11px; border: 1px solid #d1d5db; border-radius: 6px; box-sizing: border-box; }
        
        .puzzle-wrapper { margin: 20px 0; text-align: center; }
        .puzzle-title { font-weight: bold; margin-bottom: 10px; font-size: 14px; color: #333; }
        
        .puzzle-board { 
            display: grid; 
            grid-template-columns: 1fr 1fr; 
            gap: 2px; 
            width: 220px; 
            margin: 0 auto; 
            background: #333; 
            padding: 2px; 
            border-radius: 4px;
        }
        
        .tile { 
            width: 108px; 
            height: 108px; 
            cursor: pointer; 
            background-size: cover; 
            background-position: center;
            transition: transform 0.2s, outline 0.1s;
        }
        .tile:hover { transform: scale(1.02); }
        .tile.selected { outline: 3px solid #f59e0b; z-index: 10; }

        /* Индикатор сборки пазла */
        .puzzle-status { font-size: 13px; margin-top: 8px; font-weight: bold; }
        .status-fail { color: #dc3545; }
        .status-ok { color: #28a745; }
        
        .submit { width: 100%; padding: 12px; background: #2f7d4f; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; margin-top: 10px;}
        .submit:hover { background: #256640; }
    </style>
</head>
<body>
    <div class="card">
        <h1 style="text-align:center; font-size:20px;">Вход в систему</h1>
        
        <?php if ($message): ?>
            <div class="alert alert-<?= $msgType ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if ($msgType === 'success'): ?>
            <p style="text-align:center;"><a href="index.php" style="color:#2f7d4f; font-weight:bold; font-size: 16px;">Перейти на главную →</a></p>
        <?php else: ?>
            <form method="post" autocomplete="off" id="loginForm">
                <div class="field">
                    <input type="text" name="login" placeholder="Логин (Email)" required>
                </div>
                <div class="field">
                    <input type="password" name="pass" placeholder="Пароль" required>
                </div>
                
                <div class="puzzle-wrapper">
                    <div class="puzzle-title">Соберите картинку (кликните по двум плиткам, чтобы поменять их)</div>
                    
                    <input type="hidden" name="puzzle_state" id="puzzle_state_input" value="<?= implode(',', $_SESSION['puzzle_state']) ?>">
                    
                    <div class="puzzle-board" id="puzzleBoard">
                        <?php foreach ($_SESSION['puzzle_state'] as $index => $tileId): ?>
                            <div class="tile" 
                                 data-index="<?= $index ?>" 
                                 data-id="<?= $tileId ?>"
                                 style="background-image: url('captcha/<?= $tileId ?>.png');"
                                 onclick="selectTile(this)">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Индикатор -->
                    <div id="puzzleStatus" class="puzzle-status status-fail">Пазл не собран</div>

                    <a href="?refresh=1" style="font-size:12px; color:#666; margin-top:10px; display:inline-block;">🔄 Перемешать заново</a>
                </div>

                <button type="submit" name="signin" class="submit">Войти</button>
            </form>
            
            <p style="text-align:center; margin-top:20px; font-size:14px;">
                Нет аккаунта? <a href="register.php" style="color:#2f7d4f; font-weight:bold; text-decoration:none;">Зарегистрироваться</a>
            </p>
        <?php endif; ?>
    </div>

    <script>
        let selectedTile = null;
        let board = document.getElementById('puzzleBoard');
        
        // Функция проверки сборки пазла на клиенте (для подсказки)
        function checkClientPuzzle() {
            let tiles = board.querySelectorAll('.tile');
            let state = [];
            tiles.forEach(tile => {
                state.push(parseInt(tile.getAttribute('data-id')));
            });
            
            let statusDiv = document.getElementById('puzzleStatus');
            // Сравниваем с правильным порядком [1, 2, 3, 4]
            if (state[0] === 1 && state[1] === 2 && state[2] === 3 && state[3] === 4) {
                statusDiv.className = 'puzzle-status status-ok';
                statusDiv.innerText = '✅ Пазл собран!';
            } else {
                statusDiv.className = 'puzzle-status status-fail';
                statusDiv.innerText = '❌ Пазл не собран';
            }
        }

        function selectTile(tile) {
            if (!selectedTile) {
                selectedTile = tile;
                tile.classList.add('selected');
            } else {
                if (selectedTile !== tile) {
                    swapTiles(selectedTile, tile);
                }
                selectedTile.classList.remove('selected');
                selectedTile = null;
            }
        }

        function swapTiles(tile1, tile2) {
            let bg1 = tile1.style.backgroundImage;
            let bg2 = tile2.style.backgroundImage;
            
            tile1.style.backgroundImage = bg2;
            tile2.style.backgroundImage = bg1;
            
            let id1 = tile1.getAttribute('data-id');
            let id2 = tile2.getAttribute('data-id');
            
            tile1.setAttribute('data-id', id2);
            tile2.setAttribute('data-id', id1);
            
            updateStateInput();
            checkClientPuzzle(); // Проверяем, собрался ли пазл
        }

        function updateStateInput() {
            let tiles = board.querySelectorAll('.tile');
            let state = [];
            tiles.forEach(tile => {
                state.push(tile.getAttribute('data-id'));
            });
            document.getElementById('puzzle_state_input').value = state.join(',');
        }
        
        // Проверяем при загрузке страницы (вдруг уже собран)
        document.addEventListener('DOMContentLoaded', checkClientPuzzle);
    </script>
</body>
</html>