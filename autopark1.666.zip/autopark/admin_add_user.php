<?php
// admin_add_user.php
session_start();
require 'db.php';

// Проверка, что это админ
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$message = '';

if (isset($_POST['add_user'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'] ?? 'user';

    // Проверка существования
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $message = "<div style='color:red;'>Пользователь с таким Email уже существует!</div>";
    } else {
        // ХЕШИРОВАНИЕ
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $full_name, $email, $hashed_password, $role);
        
        if ($stmt->execute()) {
            $message = "<div style='color:green;'>✅ Пользователь $full_name успешно добавлен!</div>";
        } else {
            $message = "<div style='color:red;'>Ошибка: " . $stmt->error . "</div>";
        }
    }
}
?>
<!-- Простая HTML-форма для добавления -->
<!DOCTYPE html>
<html lang="ru">
<head><meta charset="UTF-8"><title>Добавить пользователя</title></head>
<body>
    <h2>Добавление нового пользователя</h2>
    <?= $message ?>
    <form method="POST">
        <input type="text" name="full_name" placeholder="ФИО" required><br><br>
        <input type="email" name="email" placeholder="Email" required><br><br>
        <input type="password" name="password" placeholder="Пароль" required><br><br>
        <select name="role">
            <option value="user">Пользователь</option>
            <option value="admin">Администратор</option>
        </select><br><br>
        <button type="submit" name="add_user">Добавить</button>
    </form>
    <a href="dashboard.php">← Назад в панель</a>
</body>
</html>