<?php
// api_notes.php
declare(strict_types=1);

// Устанавливаем заголовки для API
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // Разрешаем запросы с других доменов (если нужно)
header('Access-Control-Allow-Methods: GET');

// Функция для отправки JSON-ошибки
function sendError(int $code, string $message): void {
    http_response_code($code);
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

// ===== 1. ПРОВЕРКА ВХОДЯЩИХ ДАННЫХ =====
// Получаем параметр запроса, если он есть (например, ?id_user=1)
$id_user_filter = isset($_GET['id_user']) ? trim((string)$_GET['id_user']) : null;

// Проверка на корректность параметра (Bad Request 400)
if ($id_user_filter !== null && !ctype_digit($id_user_filter)) {
    sendError(400, 'Некорректный параметр id_user. Ожидается целое число.');
}

// ===== 2. ПОДКЛЮЧЕНИЕ К БАЗЕ ДАННЫХ =====
// Проверяем наличие файла
if (!file_exists('db.php')) {
    sendError(500, 'Внутренняя ошибка сервера: файл конфигурации БД не найден.');
}

try {
    // Подключаем БД
    require 'db.php';
    
    // ИСПРАВЛЕНО: Проверяем, что $conn вообще существует и является объектом
    if (!isset($conn) || !is_object($conn)) {
        throw new Exception('Переменная $conn не является объектом подключения.');
    }
    
    // Если нужно, проверяем на ошибку подключения (для старых версий PHP)
    if (property_exists($conn, 'connect_error') && $conn->connect_error) {
        throw new Exception('Ошибка подключения к базе данных');
    }
    
} catch (Throwable $e) {
    sendError(500, 'Ошибка подключения к базе данных');
}

try {
    // Подключаем БД
    require 'db.php';
    
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception('Ошибка подключения к базе данных');
    }
} catch (Throwable $e) {
    sendError(500, 'Ошибка подключения к базе данных');
}

// ===== 3. ВЫБОРКА ДАННЫХ ИЗ БД =====
try {
    // Формируем SQL-запрос с JOIN для получения логина пользователя
    $sql = "SELECT 
                n.id, 
                n.title, 
                n.content, 
                n.created_at, 
                u.full_name AS login 
            FROM notes n
            LEFT JOIN users u ON n.id_user = u.id"; // Предполагаем, что в users есть поле full_name (или login)

    // Если передан фильтр по пользователю, добавляем условие WHERE
    if ($id_user_filter !== null) {
        $sql .= " WHERE n.id_user = ?";
    }
    
    $sql .= " ORDER BY n.created_at DESC";

    // Подготовка запроса (защита от SQL-инъекций)
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        throw new Exception('Ошибка подготовки запроса: ' . $conn->error);
    }

    // Привязка параметров, если есть фильтр
    if ($id_user_filter !== null) {
        $stmt->bind_param('i', $id_user_filter);
    }

        // Выполнение запроса
        $stmt->execute();
    
        // ИСПРАВЛЕНО: Проверяем, что get_result() вернул объект, а не false
        $result = $stmt->get_result();
        
        if (!$result) {
            throw new Exception('Ошибка получения результата из базы данных');
        }
    
        $notes = [];
    
        // Обработка каждой записи согласно требованиям
        while ($row = $result->fetch_assoc()) {
        // 1. Формирование title_user: "{title} - {login}"
        $title = $row['title'] ?? 'Без заголовка';
        $login = $row['login'] ?? 'Неизвестный';
        $title_user = $title . ' - ' . $login;

        // 2. Форматирование даты из created_at в ДД.ММ.ГГГГ
        $date_raw = $row['created_at'] ?? '';
        $formatted_date = '';
        if (!empty($date_raw)) {
            $date_obj = DateTime::createFromFormat('Y-m-d', $date_raw);
            if ($date_obj) {
                $formatted_date = $date_obj->format('d.m.Y');
            } else {
                // Если дата в другом формате, пробуем просто создать объект
                $timestamp = strtotime($date_raw);
                $formatted_date = $timestamp ? date('d.m.Y', $timestamp) : $date_raw;
            }
        }

        // 3. Формируем объект ответа
        $notes[] = [
            'id'             => (int)$row['id'],
            'title_user'     => $title_user,
            'content'        => $row['content'],
            'formatted_date' => $formatted_date
        ];
    }

    $stmt->close();

    // ===== 4. ОТПРАВКА ОТВЕТА =====
    // Если данных нет, вернется пустой массив [], что соответствует статусу 200 OK
    http_response_code(200);
    echo json_encode($notes, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Throwable $e) {
    // Обработка любых внутренних ошибок (500 Internal Server Error)
    sendError(500, 'Внутренняя ошибка сервера: ' . $e->getMessage());
}

$conn->close(); 
