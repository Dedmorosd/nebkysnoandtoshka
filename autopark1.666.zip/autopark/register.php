<?php
// register.php
session_start();
require 'db.php';

$message = '';

if (isset($_POST['register_btn'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($password !== $confirm) {
        $message = "<div style='color:red; padding:10px; background:#ffe6e6; border-radius:5px; margin-bottom:15px;'>Пароли не совпадают!</div>";
    } else {
        // Проверка на существующий Email
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "<div style='color:red; padding:10px; background:#ffe6e6; border-radius:5px; margin-bottom:15px;'>Пользователь с таким Email уже существует.</div>";
        } else {
            // --- ГЛАВНОЕ: ХЕШИРОВАНИЕ ПАРОЛЯ ---
            // Функция password_hash создает безопасный хеш (например, $2y$10$...)
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Сохраняем в БД уже хешированный пароль!
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, 'user')");
            $stmt->bind_param("sss", $full_name, $email, $hashed_password);

            if ($stmt->execute()) {
                $message = "<div style='color:green; padding:10px; background:#e6ffe6; border-radius:5px; margin-bottom:15px;'>✅ Вы успешно зарегистрированы! Теперь можете <a href='auth.php'>войти</a>.</div>";
            } else {
                $message = "<div style='color:red; padding:10px; background:#ffe6e6; border-radius:5px;'>Ошибка при регистрации: " . $stmt->error . "</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <style>
        body { font-family: Arial; background: #eef1f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .box { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); width: 360px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #333; font-size: 14px; }
        input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; }
        button { width: 100%; padding: 11px; background: #007bff; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; font-weight: bold; }
        button:hover { background: #0056b3; }
        .back-link { display: block; text-align: center; margin-top: 15px; color: #666; font-size: 14px; text-decoration: none; }
    </style>
</head>
<body>
    <div class="box">
        <h2 style="text-align:center; margin-top:0;">Регистрация</h2>
        <?= $message ?>
        <form method="POST">
            <div class="form-group">
                <label>ФИО / Имя</label>
                <input type="text" name="full_name" placeholder="Иван Иванов" required>
            </div>
            <div class="form-group">
                <label>Email (будет логином)</label>
                <input type="email" name="email" placeholder="example@mail.ru" required>
            </div>
            <div class="form-group">
                <label>Пароль</label>
                <input type="password" name="password" placeholder="••••••" required>
            </div>
            <div class="form-group">
                <label>Повторите пароль</label>
                <input type="password" name="confirm_password" placeholder="••••••" required>
            </div>
            <button type="submit" name="register_btn">Зарегистрироваться</button>
        </form>
        <a href="auth.php" class="back-link">← Назад к входу</a>
    </div>
</body>
</html>