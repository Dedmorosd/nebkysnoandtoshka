<?php
// partners.php
session_start();

// Проверка авторизации (если нужно, чтобы видели только свои)
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php"); // Или login.php
    exit;
}

require 'db.php'; // Подключение к базе
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Контрагенты (Партнеры)</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f9; margin: 0; padding: 20px; }
        .container { max-width: 1100px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        h1 { margin-top: 0; color: #333; }
        .back-link { display: inline-block; margin-bottom: 15px; text-decoration: none; color: #007bff; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background: #333; color: white; }
        
        /* Окрашиваем строки в зависимости от типа */
        tr.type-supplier { background-color: #e8f4ec; } /* Зеленоватый для поставщиков */
        tr.type-buyer { background-color: #e8f0fe; }    /* Голубоватый для покупателей */
        
        /* Стили для бейджиков (бейджи типа контрагента) */
        .badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
        .badge-supplier { background: #2f7d4f; color: white; }
        .badge-buyer { background: #1a73e8; color: white; }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php" class="back-link">← Вернуться на главную</a>
    <h1>Справочник контрагентов</h1>

    <table>
        <thead>
            <tr>
                <th>ID (Код)</th>
                <th>Наименование</th>
                <th>ИНН</th>
                <th>Адрес</th>
                <th>Телефон</th>
                <th>Тип</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Делаем запрос к БД, сортируем так, чтобы Поставщики были сверху
            $sql = "SELECT * FROM partners ORDER BY type ASC, name ASC";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                // Перебираем все записи из базы
                while($row = $result->fetch_assoc()) {
                    // Определяем класс строки и бейджика в зависимости от типа
                    $isSupplier = ($row['type'] === 'Поставщик');
                    $rowClass = $isSupplier ? 'type-supplier' : 'type-buyer';
                    $badgeClass = $isSupplier ? 'badge-supplier' : 'badge-buyer';
                    
                    echo "<tr class='{$rowClass}'>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td><b>" . htmlspecialchars($row['name']) . "</b></td>";
                    // Если ИНН пустой, ставим прочерк
                    echo "<td>" . (!empty($row['inn']) ? htmlspecialchars($row['inn']) : '—') . "</td>";
                    echo "<td>" . htmlspecialchars($row['addres']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
                    echo "<td><span class='badge {$badgeClass}'>" . htmlspecialchars($row['type']) . "</span></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6' style='text-align:center;'>В базе пока нет контрагентов</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>